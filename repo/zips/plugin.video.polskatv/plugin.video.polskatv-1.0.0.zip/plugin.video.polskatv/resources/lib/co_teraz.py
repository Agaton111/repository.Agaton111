# -*- coding: utf-8 -*-
"""
co_teraz.py — scalony moduł 'Co teraz w TV' dla Kodi 21
"""

import os
import json
import traceback
import importlib
from datetime import datetime

import xbmc
import xbmcgui
import xbmcaddon
import xbmcvfs
import urllib
import re
import gc
import time
# -------------------------------------------------------------------------
# podstawowe ścieżki
# -------------------------------------------------------------------------
ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo("id") or "plugin.video.polskatv"
ADDON_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo("path") or "")
FOLDER = xbmcvfs.translatePath(f"special://profile/addon_data/{ADDON_ID}")

CACHE_TIME = 2 * 60 * 60  # 2 godziny w sekundach
if not os.path.exists(FOLDER):
    try:
        os.makedirs(FOLDER, exist_ok=True)
    except Exception:
        pass

EPG_JSON = os.path.join(FOLDER, "epg.json")
EPG_GROUPS_FILE = os.path.join(FOLDER, "epg_groups.json")
LISTY_RAZEM_FILE = os.path.join(FOLDER, "listy_razem.json")
WIZJA_CHANNELS = os.path.join(FOLDER, "wizja_channels.json")


DEFAULT_SKIN_FOLDER = "Default"
DEFAULT_SKIN_RES = "720p"

# -------------------------------------------------------------------------
# domyślna mapa grup
# -------------------------------------------------------------------------
DEFAULT_GROUPS = {
    "Filmy": ["thriller", "komedia", "horror", "dramat obyczajowy", "western","komedia romantyczna","film SF","film kryminalny","musical","film historyczny",
              "film przygodowy", "film obyczajowy", "film sensacyjny" ,"film sf","film familijny","dramat wojenny","film fantasy","dramat historyczny","dramat psychologiczny",
              "komediodramat", "dramat sensacyjny", "dramat biograficzny", "dramat społeczny", "dramat kryminalny", "telenowela", "melodramat","film biograficzny"],
    "Seriale": ["serial komediowy", "serial sf", "serial przygodowy", "serial kryminalny","serial historyczny","serial kostiumowy","serial religijny","serial fantasy",
                "kultowe seriale","TVN Telenowele","kryminalnie","Seriale o Kobietach","Momenty Prawdy","TVN Prawo i Życie","TVN Szpitalne Historie",
                "serial sensacyjny", "serial biograficzny", "serial akcji", "serial obyczajowy","serial fabularno-dokumentalny","serial wojenny","serial psychologiczny"],
    "Dokument Reportaże": ["film dokumentalny", "film krótkometrażowy", "serial dokumentalny","cykl reportaży","reportaż","cykl felietonów","felieton kulturalny","serial przyrodniczy",
                 "serial paradokumentalny", "program historyczny", "program publicystyczny","program edukacyjny","Edukacja","cykl dokumentalny","program popularnonukowy","felieton"],
    "Dla dzieci": ["serial anime", "serial dla dzieci", "program dla dzieci","film animowany","serial animowany","TVP ABC"],
    "Rozrywka": ["reality show", "Muzyka","program muzyczny", "program rozrywkowy", "rozrywka","teleturniej","koncert","TVN Talk Show","TVN Moto","TVN Rewolucje w Kuchni",
                "program kulinarno-rozrywkowy","widowisko","program kulturalny","talk-show","TVN Milionerzy","TVN Usterka","TVN Rajska Miłość","TVN Szkoła Życia"],
    "Sport": ["program sportowy", "sporty walki", "informacyjny serwis sportowy", "sport","magazyn siatkarski"],
    "Serwisy Magazyny": ["serwis informacyjny", "program informacyjny", "magazyn", "magazyn filmowy","news",
               "magazyn kulinarny", "magazyn komputerowy", "magazyn religijny"],
    "Inne": [""]
}

# -------------------------------------------------------------------------
# wczytaj/normalizuj mapę grup
# -------------------------------------------------------------------------
def _load_group_map():
    try:
        if not os.path.exists(EPG_GROUPS_FILE):
            with open(EPG_GROUPS_FILE, "w", encoding="utf-8") as f:
                json.dump(DEFAULT_GROUPS, f, ensure_ascii=False, indent=2)
        with open(EPG_GROUPS_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
        normalized = {}
        for grp, lst in data.items():
            if not isinstance(lst, list):
                lst = list(lst) if lst else []
            normalized[grp] = [s.strip().lower() for s in lst if isinstance(s, str)]
        return normalized
    except Exception as e:
        xbmc.log(f"[{ADDON_ID}:co_teraz] Błąd wczytania epg_groups.json: {e}", xbmc.LOGWARNING)
        return {k: [s.lower().strip() for s in v] for k, v in DEFAULT_GROUPS.items()}

GROUP_MAP = _load_group_map()

# -------------------------------------------------------------------------
# przypisz grupę
# -------------------------------------------------------------------------
def przypisz_grupe(program: dict):

    kat = (program.get("kategoria") or "").strip().lower()     ### z epg
    tyt = (program.get("tytul") or "").strip().lower()
##    opis = (program.get("opis") or "").strip().lower()
    stacja = (program.get("kanal") or "").strip().lower()

    if kat:
        for grupa, wzorce in GROUP_MAP.items():
            for wz in wzorce:
                if wz and (wz in kat or kat == wz):
                    return grupa

    combined = f"{stacja} "
    if combined.strip():

        for grupa, wzorce in GROUP_MAP.items():
            for wz in wzorce:
                if wz and wz in combined:

                    return grupa

    return "Inne"

# -------------------------------------------------------------------------
# stwórz listy_razem.json (jeśli nie istnieje)
# -------------------------------------------------------------------------

def normalize_channels(channels):
    """
    Normalizuje listę kanałów do postaci:
    { nazwa: najlepszy_url }
    """
    grouped = {}

    for ch in channels:
        if not isinstance(ch, dict):
            continue

        nazwa = (ch.get("name") or ch.get("nazwa") or "").strip()
        url = ch.get("url", "")

        if not nazwa or not isinstance(url, str):
            continue

        prev = grouped.get(nazwa)
        if not prev:
            grouped[nazwa] = url
        else:
            # preferuj m3u8/mpd
            if any(x in url for x in ("m3u8", "mpd")) and not any(x in prev for x in ("m3u8", "mpd")):
                grouped[nazwa] = url

    return grouped


def utworz_listy_razem(lists):
    # -------------------------------------------------
    # CACHE
    # -------------------------------------------------
    try:
        if os.path.exists(LISTY_RAZEM_FILE):
            age = time.time() - os.path.getmtime(LISTY_RAZEM_FILE)
            if age < CACHE_TIME:
                with open(LISTY_RAZEM_FILE, "r", encoding="utf-8") as f:
                    return json.load(f)
            else:
                os.remove(LISTY_RAZEM_FILE)
    except Exception as e:
        xbmc.log(f"[listy_razem] cache error: {e}", xbmc.LOGWARNING)

    if not lists:
        return []

    wszystkie_kanaly = []

    # -------------------------------------------------
    # tylko moduły TV
    # -------------------------------------------------
    dostepne = [
        l for l in lists
        if "tv" in (l.get("id", "") + l.get("name", "")).lower()
    ] or lists

    for modinfo in dostepne:
        module_id = modinfo.get("id")
        if not module_id:
            continue

        try:
            mod = importlib.import_module(f"resources.lib.{module_id}")

            # -----------------------------------------
            # ŹRÓDŁO KANAŁÓW
            # -----------------------------------------
            if mod.__name__ == "resources.lib.wizja_tv":
                WIZJA_CHANNELS = os.path.join(FOLDER, "wizja_channels.json")
                if not os.path.exists(WIZJA_CHANNELS):
                    xbmc.log("[listy_razem] brak wizja_channels.json", xbmc.LOGWARNING)
                    continue

                with open(WIZJA_CHANNELS, "r", encoding="utf-8") as f:
                    channels = json.load(f)
            else:
                channels = getattr(mod, "CHANNELS", [])

            # -----------------------------------------
            # NORMALIZACJA (WSPÓLNA LOGIKA)
            # -----------------------------------------
            grouped = normalize_channels(channels)

            for nazwa, url in grouped.items():
                wszystkie_kanaly.append({
                    "nazwa": nazwa,
                    "id_modulu": module_id,
                    "url": url
                })

        except Exception as e:
            xbmc.log(
                f"[utworz_listy_razem] ❌ moduł {module_id}: {e}",
                xbmc.LOGERROR
            )
            xbmc.log(traceback.format_exc(), xbmc.LOGERROR)
            continue

    # -------------------------------------------------
    # ZAPIS
    # -------------------------------------------------
    try:
        with open(LISTY_RAZEM_FILE, "w", encoding="utf-8") as f:
            json.dump(wszystkie_kanaly, f, ensure_ascii=False, indent=2)
    except Exception as e:
        xbmc.log(f"[listy_razem] zapis error: {e}", xbmc.LOGERROR)

    return wszystkie_kanaly

# -------------------------------------------------------------------------
# wejście — tworzy listy_razem i przechodzi do kategorii
# -------------------------------------------------------------------------
def pokaz_wybor_modulu(lists=None):
    try:
        if not lists:
            xbmcgui.Dialog().ok("Brak list", "Nie przekazano list modułów do połączenia.")
            return

        utworz_listy_razem(lists)
        pokaz_kategorie_epg("listy_razem")
    except Exception as e:
        xbmc.log(f"[{ADDON_ID}:co_teraz] ❌ Błąd pokaz_wybor_modulu: {e}\n{traceback.format_exc()}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("Błąd", str(e))

# -------------------------------------------------------------------------
# wybór kategorii
# -------------------------------------------------------------------------
def pokaz_kategorie_epg(module_id):
    try:
        kategorie = list(GROUP_MAP.keys())
        idx = xbmcgui.Dialog().select(f"📚 Wybierz kategorię", kategorie)
        if idx == -1:
            return
        kategoria = kategorie[idx]
        pokaz_programy_dla_kategorii(module_id, kategoria)
    except Exception as e:
        xbmc.log(f"[{ADDON_ID}:co_teraz] ❌ Błąd pokaz_kategorie_epg: {e}\n{traceback.format_exc()}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("Błąd kategorii", str(e))

# -------------------------------------------------------------------------
# zbierz programy trwające TERAZ i otwórz okno
# -------------------------------------------------------------------------
def pokaz_programy_dla_kategorii(module_id, kategoria):
    try:
        if not os.path.exists(EPG_JSON):
            xbmcgui.Dialog().ok("Brak EPG", "Najpierw pobierz EPG (wejdź w listę kanałów aby pobrać).")
            return

        with open(EPG_JSON, "r", encoding="utf-8") as f:
            dane = json.load(f)

        epg_data = dane.get("data", {})

    except Exception as e:
        xbmcgui.Dialog().ok("Błąd EPG", f"Nie można wczytać epg.json:\n{e}")
        return

    # Funkcja do normalizacji nazw kanałów
    def normalize_name(name):
        if not name:
            return ""
        name = name.lower()
        name = re.sub(r'[\s\-]+', '', name)
        name = re.sub(r'(hd|fhd|uhd|pl|tv)$', '', name)
        return name

    # --- Przygotowanie map kanał -> module/url z JSON ---
    channel_to_module_map = {}
    channel_to_url_map = {}
    module_channels = []

    try:
        if module_id == "listy_razem" and os.path.exists(LISTY_RAZEM_FILE):
            with open(LISTY_RAZEM_FILE, "r", encoding="utf-8") as f:
                lr = json.load(f)
            for c in lr:
                if isinstance(c, dict):
                    name_norm = normalize_name(c.get("nazwa", ""))
                    if name_norm:
                        module_channels.append(name_norm)
                        channel_to_module_map[name_norm] = c.get("id_modulu", "").strip().lower()
                        channel_to_url_map[name_norm] = c.get("url", "").strip()
        else:
            mod = importlib.import_module(f"resources.lib.{module_id}")
            for c in getattr(mod, "CHANNELS", []):
                ch_name_norm = normalize_name(c.get("name", ""))
                if ch_name_norm:
                    module_channels.append(ch_name_norm)
                    channel_to_module_map[ch_name_norm] = module_id
                    channel_to_url_map[ch_name_norm] = c.get("url", "").strip()
    except Exception:
        pass  # ignorujemy błędy

    # --- Przetwarzanie epg_data ---
    teraz = datetime.now()
    lista_programow = []

    for kanal, progs in epg_data.items():
        kanal_norm = normalize_name(kanal)
        if module_channels and kanal_norm not in module_channels:
            continue

        for p in progs:
            try:
                start_raw = p.get("start", "")
                stop_raw = p.get("stop", "")
                start_dt = datetime.fromisoformat(start_raw) if start_raw else None
                stop_dt = datetime.fromisoformat(stop_raw) if stop_raw else None
                if not start_dt or not stop_dt:
                    continue

                if start_dt <= teraz <= stop_dt:
                    p["kanal"] = kanal
                    p["module_id"] = channel_to_module_map.get(kanal_norm, "")
                    p["url"] = channel_to_url_map.get(kanal_norm, "")
                    grupa = przypisz_grupe(p)
                    if grupa == kategoria:
                        lista_programow.append(p)
            except Exception:
                continue

    if not lista_programow:
        xbmcgui.Dialog().notification(
            heading='INFO',
            message="Brak trwających teraz programów w tej kategorii",
            icon=xbmcgui.NOTIFICATION_WARNING,
            time=3500,
            sound=False
        )
        xbmc.sleep(600)
        pokaz_kategorie_epg(module_id)
        return

    lista_programow.sort(key=lambda x: x.get("start", ""))
    pokaz_okno(
        data={
            "kategoria": kategoria,
            "lista": lista_programow,
            "module_id": module_id
        },
        return_to_category=lambda: pokaz_kategorie_epg(module_id)
    )


# -------------------------------------------------------------------------
# OKNA GUI
# -------------------------------------------------------------------------
class CoTerazWindow(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        self.data = kwargs.get("data", {}) or {}
        self.return_to_category = kwargs.get("return_to_category", None)
        super().__init__(*args, **kwargs)
        self.selected_index = -1

    def onInit(self):
        try:
            lista = self.data.get("lista", []) or []
            xbmc.log(f"[{ADDON_ID}] onInit - lista length: {len(lista)}", xbmc.LOGINFO)

            addon = xbmcaddon.Addon()
            addon_path = xbmcvfs.translatePath(addon.getAddonInfo("path"))
            fallback_path = os.path.join(addon_path, "resources", "media", "plakat.jpg")
            fallback_path = xbmcvfs.translatePath(fallback_path)

            list_ctrl = None
            try:
                list_ctrl = self.getControl(9100)
                list_ctrl.reset()
            except Exception:
                xbmc.log(f"[{ADDON_ID}] Brak kontrolki listy 9100", xbmc.LOGERROR)

            kategoria = self.data.get("kategoria", "")

            try:
                if kategoria:
                    self.getControl(9002).setLabel(f"[B]Teraz nadawane[/B] w kategorii [I]{kategoria}[/I]")
                else:
                    self.getControl(9002).setLabel(f"[B]Teraz nadawane[/B]")
            except Exception:
                xbmc.log(f"[{ADDON_ID}] brak kontrolki 9002 (nagłówek)", xbmc.LOGDEBUG)
            try:
                self.getControl(9003).setLabel(f"[COLOR gray]Znaleziono pozycji: [B]{len(lista)}[/B][/COLOR]")
            except Exception:
                pass

            if list_ctrl:
                for prog in lista:
                    try:
                        start = (prog.get("start", "")[11:16]) if prog.get("start") else ""
                        stop = (prog.get("stop", "")[11:16]) if prog.get("stop") else ""
                        kanal = prog.get("kanal", "")
                        tytul = prog.get("tytul", "") or ""
                        opis = (prog.get("opis") or "").strip() or "Dla tej pozycji jeszcze niema opisu."
                        kategoria_prog = (prog.get("kategoria") or "Inne")
                        plakat = (prog.get("plakat") or "").strip() or fallback_path
                        module_id = prog.get("module_id", "")

                        li = xbmcgui.ListItem(label=f"[COLOR lime]{start}-{stop}[/COLOR]   [B]{kanal}[/B]   --  {tytul}")
                        li.setArt({"thumb": plakat, "icon": plakat, "poster": plakat, "fanart": plakat})
                        li.setInfo("video", {"title": tytul, "plot": opis, "genre": kategoria_prog})
                        li.setProperty("kategoria", kategoria_prog)
                        li.setProperty("start", start)
                        li.setProperty("stop", stop)
                        li.setProperty("Channel", kanal)
                        li.setProperty("module_id", module_id)
                        li.setProperty("url", prog.get("url", ""))
                        list_ctrl.addItem(li)
                    except Exception as e:
                        xbmc.log(f"[{ADDON_ID}] Błąd przy dodawaniu elementu do listy: {e}", xbmc.LOGERROR)
                        xbmc.log(traceback.format_exc(), xbmc.LOGERROR)

                try:
                    self.setFocus(list_ctrl)
                except Exception:
                    xbmc.log(f"[{ADDON_ID}] Nie udało się ustawić fokusu na 9100", xbmc.LOGDEBUG)

        except Exception as e:
            xbmc.log(f"[{ADDON_ID}] EXCEPTION w onInit: {e}", xbmc.LOGERROR)
            xbmc.log(traceback.format_exc(), xbmc.LOGERROR)

######## Okno dla Wielu pozycji

    def onClick(self, controlId):
        try:
            list_ctrl = None
            try:
                list_ctrl = self.getControl(9100)
            except Exception:
                pass

            # --- PRZYCISK ZAMKNIJ ---dla Wielu pozycji
            if controlId == 9006:
                self.close()
                return

            # --- PRZYCISK KATEGORIE ---dla Wielu pozycji
            if controlId == 9007:
                self.close()
                if callable(self.return_to_category):
                    self.return_to_category()
                return

            # --- PRZYCISK OTWÓRZ ---dla Wielu pozycji
            if controlId == 9008:
                if not list_ctrl or list_ctrl.size() == 0:
                    xbmcgui.Dialog().notification("Brak pozycji", "Lista kanałów jest pusta", xbmcgui.NOTIFICATION_ERROR, 2500)
                    return

                # zawsze bierz pozycję z self.selected_index (ostatni klik)
                li = None
                if hasattr(self, "selected_index") and self.selected_index >= 0:
                    try:
                        li = list_ctrl.getListItem(self.selected_index)
                    except Exception:
                        li = None

                # jeśli nadal brak, dopiero wtedy getSelectedItem()
                if not li:
                    try:
                        li = list_ctrl.getSelectedItem()
                    except Exception:
                        li = None

                if not li:
                    xbmcgui.Dialog().notification("Błąd", "Nie można odczytać wybranej pozycji", xbmcgui.NOTIFICATION_ERROR, 2000)
                    return
                CHANNELS = []
                # odczyt właściwości
                module_id = (li.getProperty("module_id") or "").strip()

                url = (li.getProperty("url") or "").strip()
                channel_label = li.getLabel() or li.getProperty("Channel") or "Nieznany"


                # Usuń tagi BBCode ([COLOR], [B], [/COLOR], [/B], itp.)
                channel_label = re.sub(r'\[/?[A-Z]+\s*.*?\]', '', channel_label)

                # Usuń nadmiarowe spacje
                channel_label = re.sub(r'\s{2,}', '   ', channel_label)
                # Jeśli występuje wzorzec "godzina - godzina", usuń to i wszystko przed nazwą
                channel_label = re.sub(r'^\d{1,2}:\d{2}\s*-\s*\d{1,2}:\d{2}\s*', '', channel_label)
                channel_label = channel_label.split('--')
                channel_label = channel_label[0]

                CHANNELS.append({"name": channel_label, "url": url, "icon": ''})
                li = xbmcgui.ListItem(path=url)
                li.setInfo("video", {"title": channel_label or url})
                li.setLabel(channel_label or url)


##                if module_id == "co_teraz":
##                    module_id = ""

                if not module_id:
                    xbmcgui.Dialog().notification(
                        "Brak module_id",
                        f"Tego kanału niema w modułach: {channel_label}",
                        xbmcgui.NOTIFICATION_INFO,
                        2500
                    )
                    return

                plugin_uri = (
                    f'plugin://plugin.video.polskatv/?action=uni_player'
                    f'&url={urllib.parse.quote_plus(url)}'
                    f'&name={urllib.parse.quote_plus(channel_label)}'
                    f'&module={urllib.parse.quote_plus(module_id)}'
                )

                xbmc.log(f"[{ADDON_ID}] RunPlugin -> {plugin_uri}", xbmc.LOGINFO)
                xbmc.executebuiltin(f'RunPlugin("{plugin_uri}")')

##                xbmc.log(f"[{ADDON_ID}] Container.Update -> {plugin_uri}", xbmc.LOGINFO)
##                xbmc.executebuiltin(f'Container.Update("{plugin_uri}")')


                xbmcgui.Dialog().notification("Pobieram dane z", module_id, xbmcgui.NOTIFICATION_INFO, 2000, sound=False)

                self.close()
##                return CHANNELS

            # --- KLIKNIĘCIE NA LIŚCIE ---
            if controlId == 9100 and list_ctrl:

                try:
                    pos = list_ctrl.getSelectedPosition()

                    if pos >= 0:
                        self.selected_index = pos
                        # pokaż prosty komunikat "Zaznaczono"
                        lb = None
                        try:
                            li = list_ctrl.getListItem(pos)
                            lb = li.getLabel()
                        except Exception:
                            lb = ""
                        xbmcgui.Dialog().notification("Zaznaczono do odtwarzania", lb or "pozycja", xbmcgui.NOTIFICATION_INFO, 800)
                except Exception:
                    pass


                return

        except Exception as e:
            xbmc.log(f"[{ADDON_ID}] CoTerazWindow onClick exception: {e}", xbmc.LOGERROR)
            xbmc.log(traceback.format_exc(), xbmc.LOGERROR)

# -------------------------------------------------------------------------
# Okno dla jednej pozycji — CoTerazWindow1Pos.xml
# -------------------------------------------------------------------------
class CoTerazWindow1Pos(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        self.data = kwargs.get("data", {}) or {}
        self.return_to_category = kwargs.get("return_to_category", None)
        super().__init__(*args, **kwargs)

    def onInit(self):
        try:
            prog = self.data.get("lista", [{}])[0]
            addon = xbmcaddon.Addon()
            addon_path = xbmcvfs.translatePath(addon.getAddonInfo("path"))
            fallback_path = os.path.join(addon_path, "resources", "media", "plakat.jpg")
            fallback_path = xbmcvfs.translatePath(fallback_path)
##            kategmoia = self.data.get("kategoria", "")
            kategoria = self.data.get("kategoria", "")

            try:
                if kategoria:
                    self.getControl(9002).setLabel(f"[B]Teraz nadawane[/B] w kategorii [I]{kategoria}[/I]")
                else:
                    self.getControl(9002).setLabel(f"[B]Teraz nadawane[/B]")
            except Exception:
                xbmc.log(f"[{ADDON_ID}] brak kontrolki 9002 (nagłówek)", xbmc.LOGDEBUG)

            try:
                self.getControl(9104).setImage(prog.get("plakat", fallback_path))
                self.getControl(9105).setText(prog.get("opis", "Brak opisu"))


                self.getControl(9106).setLabel(f"{prog.get('start','')[11:16]} - {prog.get('stop','')[11:16]}   {prog.get('kanal','')} -- ")

                self.getControl(9107).setLabel(prog.get("kategoria",""))
                self.getControl(9108).setLabel(prog.get("tytul",""))
            except Exception as e:
                xbmc.log(f"[{ADDON_ID}] CoTerazWindow1Pos onInit: {e}", xbmc.LOGERROR)
        except Exception as e:
            xbmc.log(f"[{ADDON_ID}] CoTerazWindow1Pos onInit EXCEPTION: {e}", xbmc.LOGERROR)

    def onClick(self, controlId):    ####  Okno dla jednej pozycji
        try:
            # --- PRZYCISK ZAMKNIJ ---
            if controlId == 9006:
                self.close()
                return

            # --- PRZYCISK KATEGORIE ---
            if controlId == 9007:
                self.close()
                if callable(self.return_to_category):
                    self.return_to_category()
                return

            # --- PRZYCISK OTWÓRZ MODUŁ / ODTWÓRZ ---
            if controlId == 9008:
                lista = self.data.get("lista", [{}])

                prog = lista[0] if lista else {}
                module_id = (prog.get("module_id") or "").strip()
                url = (prog.get("url") or "").strip()
                channel_name = prog.get("kanal") or prog.get("tytul") or "Nieznany kanał"


                channel_label=channel_name
                # Usuń tagi BBCode ([COLOR], [B], [/COLOR], [/B], itp.)
                channel_label = re.sub(r'\[/?[A-Z]+\s*.*?\]', '', channel_label)
                # Usuń nadmiarowe spacje
                channel_label = re.sub(r'\s{2,}', '   ', channel_label)
                # Jeśli występuje wzorzec "godzina - godzina", usuń to i wszystko przed nazwą
                channel_label = re.sub(r'^\d{1,2}:\d{2}\s*-\s*\d{1,2}:\d{2}\s*', '', channel_label)
                channel_label = channel_label.split('--')
                channel_label = channel_label[0]



                if not module_id:
                    xbmcgui.Dialog().notification(
                        heading="Brak module_id",
                        message=f"Tego kanału niema w modułach: {channel_name}",
                        icon=xbmcgui.NOTIFICATION_INFO,
                        time=2500
                    )
                    return

                # zbuduj URI i uruchom player testowy
                plugin_uri = (
                    f'plugin://plugin.video.polskatv/?action=uni_player'
                    f'&url={urllib.parse.quote_plus(url)}'
                    f'&name={urllib.parse.quote_plus(channel_name)}'
                    f'&module={urllib.parse.quote_plus(module_id)}'
                )
                xbmc.log(f"[{ADDON_ID}] RunPlugin -> {plugin_uri}", xbmc.LOGINFO)
                xbmc.executebuiltin(f'RunPlugin("{plugin_uri}")')
##                xbmc.log(f"[{ADDON_ID}] Container.Update -> {plugin_uri}", xbmc.LOGINFO)
##                xbmc.executebuiltin(f'Container.Update("{plugin_uri}")')


                xbmcgui.Dialog().notification(
                    heading="Pobieram dane z",
                    message=f"{module_id}",
                    icon=xbmcgui.NOTIFICATION_INFO,
                    time=2500,
                    sound=False
                )
                self.close()
        except Exception as e:
            xbmc.log(f"[{ADDON_ID}] CoTerazWindow1Pos onClick exception: {e}", xbmc.LOGERROR)
            xbmc.log(traceback.format_exc(), xbmc.LOGERROR)

# -------------------------------------------------------------------------
# funkcja wywołująca odpowiednie okno
# -------------------------------------------------------------------------
def pokaz_okno(data, return_to_category=None):
    try:
        lista = data.get("lista", []) if data else []

        xbmc.log(f"[{ADDON_ID}] pokaz_okno - lista_len = {len(lista)}", xbmc.LOGINFO)

        if not lista:
            xbmcgui.Dialog().ok("Brak programów", "Nie znaleziono żadnych programów do wyświetlenia")
            return

        addon_path = xbmcvfs.translatePath(ADDON.getAddonInfo("path"))
        skin_folder = DEFAULT_SKIN_FOLDER

        if len(lista) == 1:
            xml_name = "CoTerazWindow1Pos.xml"
            WindowClass = CoTerazWindow1Pos
            xbmc.log(f"[{ADDON_ID}] Używam wersji okna dla jednej pozycji: {xml_name}", xbmc.LOGINFO)
        else:
            xml_name = "CoTerazWindow.xml"
            WindowClass = CoTerazWindow
            xbmc.log(f"[{ADDON_ID}] Używam wersji okna dla wielu pozycji: {xml_name}", xbmc.LOGINFO)

        candidate = os.path.join(addon_path, "resources", "skins", skin_folder, DEFAULT_SKIN_RES, xml_name)
        xbmc.log(f"[{ADDON_ID}] Sprawdzanie pliku XML: {candidate}", xbmc.LOGINFO)
        found = os.path.exists(candidate)
        used_res = DEFAULT_SKIN_RES

        if not found:
            skins_dir = os.path.join(addon_path, "resources", "skins", skin_folder)
            if os.path.isdir(skins_dir):
                for entry in os.listdir(skins_dir):
                    candidate2 = os.path.join(skins_dir, entry, xml_name)
                    if os.path.exists(candidate2):
                        candidate = candidate2
                        used_res = entry
                        found = True
                        break

        if not found:
            xbmc.log(f"[{ADDON_ID}] Nie znaleziono {xml_name}", xbmc.LOGERROR)
            xbmcgui.Dialog().ok("Błąd", f"Nie znaleziono pliku {xml_name} w folderze skins/{skin_folder}")
            return

        window = WindowClass(xml_name, addon_path, skin_folder, used_res, data=data, return_to_category=return_to_category)
        window.doModal()
        del window

    except Exception as e:
        xbmc.log(f"[{ADDON_ID}] Błąd w pokaz_okno: {e}", xbmc.LOGERROR)
        xbmc.log(traceback.format_exc(), xbmc.LOGERROR)
        xbmcgui.Dialog().ok("Błąd", f"Nie udało się otworzyć okna:\n{e}")