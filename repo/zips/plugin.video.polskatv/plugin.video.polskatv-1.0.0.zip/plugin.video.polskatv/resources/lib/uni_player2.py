# -*- coding: utf-8 -*-
"""
uni_player2.py — uniwersalny odtwarzacz dla PolskaTV
obsługuje różne moduły i protokoły: mpd / m3u8 / mp4
"""

from __future__ import annotations
import sys
import xbmc
import xbmcgui
import xbmcplugin
import importlib
import inputstreamhelper


ADDON_TAG = "[UNI_PLAYER 2 PolskaTV]"


def log(msg: str, level=xbmc.LOGINFO) -> None:
    xbmc.log(f"{ADDON_TAG} {msg}", level)


def play_uni(url: str, name: str | None = None, from_module: str | None = None,
             headers: dict | None = None, close_xml: bool = False) -> None:
    """
    Uniwersalne odtwarzanie — automatycznie wybiera metodę:
    - polskie_tvn: DRM Widevine
    - polskie_tv: HLS z nagłówkami
    - inne: fallback
    """

    try:
        log(f"▶ Start play_uni2: name={name}, from_module={from_module}, url={url}")

        if not url or not from_module:
            xbmcgui.Dialog().ok("Błąd", "Brak URL lub modułu.")
            return

        # --- Import modułu źródłowego ---
        try:
            matka_mod = importlib.import_module(f"resources.lib.{from_module}")
        except Exception as e:
            log(f"❌ Nie można zaimportować modułu '{from_module}': {e}", xbmc.LOGERROR)
            xbmcgui.Dialog().ok("Błąd", f"Nie można zaimportować modułu: {from_module}")
            return

        # --- Próbujemy uzyskać przetworzony URL ---
        final_url = None
        try:
            final_url = getattr(matka_mod, "build_stream_url")(url)
            log(f"✅ build_stream_url zwrócił: {final_url}")
        except Exception:
            pass

        if not final_url:
            try:
                final_url = getattr(matka_mod, "play_channel")(url, name)
                log(f"✅ play_channel zwrócił: {final_url}")
            except Exception as e:
                log(f"⚠️ play_channel nie zwrócił nic: {e}")

        # Jeśli nadal brak — użyj oryginału
        if not final_url:
            final_url = url
            log(f"⚠️ Używam oryginalnego URL: {url}")

        # -----------------------------------------------------
        # 🟢 Sekcja 1: polskie_tvn — DRM Widevine DASH (.mpd)
        # -----------------------------------------------------
        if from_module == 'polskie_tvn':
            handle = int(sys.argv[1])
            try:
                lic_data = getattr(matka_mod, "build_stream_url")(url)
                if isinstance(lic_data, (list, tuple)):
                    stream_url = lic_data[0]
                    license_url = lic_data[1]
                else:
                    stream_url = final_url
                    license_url = ""

                PROTOCOL = "mpd"
                DRM = "com.widevine.alpha"
                UA = "okhttp/3.3.1 Android"

                is_helper = inputstreamhelper.Helper(PROTOCOL, drm=DRM)
                if not is_helper.check_inputstream():
                    xbmcgui.Dialog().ok("Błąd", "Brak wsparcia dla InputStream Adaptive (Widevine).")
                    return

                li = xbmcgui.ListItem(path=stream_url)
                li.setInfo("video", {"title": name or stream_url})
                li.setProperty("IsPlayable", "true")
                li.setMimeType("application/dash+xml")
                li.setContentLookup(False)

                li.setProperty("inputstream", is_helper.inputstream_addon)
                li.setProperty("inputstream.adaptive.manifest_type", PROTOCOL)
                li.setProperty("inputstream.adaptive.license_type", DRM)
                li.setProperty("inputstream.adaptive.license_key", license_url + "|Content-Type=|R{SSM}|")
                li.setProperty("inputstream.adaptive.stream_headers", f"User-Agent={UA}")

                xbmcplugin.setResolvedUrl(handle, True, li)
                return
            except Exception as e:
                log(f"❌ Błąd polskie_tvn: {e}")
                xbmcgui.Dialog().ok("Błąd DRM", str(e))
                return

        # -----------------------------------------------------
        # 🟢 Sekcja 2: polskie_tv — HLS/MPD z nagłówkami
        # -----------------------------------------------------
        elif from_module == 'polskie_tv':
            try:
                UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
                headers = headers or {
                    "User-Agent": UA,
                    "Referer": "https://megogo.net/",
                    "Origin": "https://megogo.net"
                }

                headers_str = "&".join([f"{k}={v}" for k, v in headers.items()])
                url_with_headers = final_url + "|" + headers_str

                li = xbmcgui.ListItem(path=url_with_headers)
                li.setInfo("video", {"title": name or final_url})
                li.setLabel(name or final_url)
                li.setProperty("IsPlayable", "true")
                li.setContentLookup(False)

                proto = "hls" if ".m3u8" in final_url else "mpd"
                helper = inputstreamhelper.Helper(proto)
                if helper.check_inputstream():
                    li.setProperty("inputstream", helper.inputstream_addon)
                    li.setProperty("inputstream.adaptive.manifest_type", proto)
                    log(f"InputStream Adaptive aktywny ({proto})")

                xbmc.Player().play(item=url_with_headers, listitem=li)
                log(f"▶️ Uruchomiono HLS/MPD stream: {url_with_headers}")
                return

            except Exception as e:
                log(f"❌ Błąd w sekcji polskie_tv: {e}")
                xbmcgui.Dialog().ok("Błąd odtwarzania", str(e))
                return

        elif from_module == 'wizja_tv':
            try:
                li = xbmcgui.ListItem(path=final_url)
                li.setInfo("video", {"title": name or final_url})
                li.setProperty("IsPlayable", "true")
                li.setContentLookup(False)

                # Automatycznie rozpoznaj HLS/MPD
                if any(ext in final_url for ext in [".m3u8", ".mpd", ".ism/manifest"]):
                    proto = "hls" if ".m3u8" in final_url else "mpd"
                    helper = inputstreamhelper.Helper(proto)
                    if helper.check_inputstream():
                        li.setProperty("inputstream", helper.inputstream_addon)
                        li.setProperty("inputstream.adaptive.manifest_type", proto)
                        log(f"InputStream Adaptive ({proto}) aktywny")

                xbmc.Player().play(item=final_url, listitem=li)
                log(f"▶️ Fallback: odtwarzanie {final_url}")
                return

            except Exception as e:
                log(f"❌ Błąd fallback: {e}")
                xbmcgui.Dialog().ok("Błąd odtwarzania", str(e))
                return


        # -----------------------------------------------------
        # 🟢 Sekcja 3: inne moduły (fallback)
        # -----------------------------------------------------
        else:
            try:
                li = xbmcgui.ListItem(path=final_url)
                li.setInfo("video", {"title": name or final_url})
                li.setProperty("IsPlayable", "true")
                li.setContentLookup(False)

                # Automatycznie rozpoznaj HLS/MPD
                if any(ext in final_url for ext in [".m3u8", ".mpd", ".ism/manifest"]):
                    proto = "hls" if ".m3u8" in final_url else "mpd"
                    helper = inputstreamhelper.Helper(proto)
                    if helper.check_inputstream():
                        li.setProperty("inputstream", helper.inputstream_addon)
                        li.setProperty("inputstream.adaptive.manifest_type", proto)
                        log(f"InputStream Adaptive ({proto}) aktywny")

                xbmc.Player().play(item=final_url, listitem=li)
                log(f"▶️ Fallback: odtwarzanie {final_url}")
                return

            except Exception as e:
                log(f"❌ Błąd fallback: {e}")
                xbmcgui.Dialog().ok("Błąd odtwarzania", str(e))
                return

    except Exception as e:
        log(f"❌ Błąd krytyczny play_uni: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("Błąd play_uni", str(e))

