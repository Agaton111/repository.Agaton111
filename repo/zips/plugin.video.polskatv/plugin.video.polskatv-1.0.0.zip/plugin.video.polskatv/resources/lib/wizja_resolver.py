# -*- coding: utf-8 -*-
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import sys
import os
import json
import re
import requests
import html
import urllib.parse
import time
from urllib.parse import urlparse


UA = "Mozilla/5.0"
HEADERS = {
    "User-Agent": UA,
    "Referer": "https://wizja.cc/"
}



def normalize_stream_url(url):
    if not url:
        return None

    url = url.replace("\\/", "/")

    # =========================================
    # 1. TS → M3U8 (najważniejsze u Ciebie)
    # =========================================
    if "/tracks-" in url and ".ts" in url:
        base = url.split("/tracks-")[0]
        if "?" in url:
            query = url.split("?", 1)[1]
            return f"{base}/index.fmp4.m3u8?{query}"
        return f"{base}/index.fmp4.m3u8"

    # =========================================
    # 2. goły endpoint → M3U8
    # =========================================
    if re.search(r'/\d+/\?token=', url):
        return url.replace("/?token=", "/index.fmp4.m3u8?token=")

    # =========================================
    # 3. embed → M3U8
    # =========================================
    if "embed.html" in url:
        return url.replace("embed.html", "index.fmp4.m3u8")

    # =========================================
    # 4. MPD zostaw (fallback)
    # =========================================
    if ".mpd" in url:
        return url

    # =========================================
    # 5. M3U8 OK
    # =========================================
    if ".m3u8" in url:
        return url

    return url

def prefer_hls(stream, headers=None):
    if not stream or ".mpd" not in stream:
        return stream

    hls = stream.replace(".mpd", ".m3u8")

    try:
        r = requests.get(hls, headers=headers, timeout=3)
        if r.status_code == 200 and "#EXTM3U" in r.text:
            return hls
    except:
        pass

    return stream

# =====================================================
# EXTRACT STREAMS (MULTI SOURCE)
# =====================================================
def extract_stream(page_url):
    try:
        session = requests.Session()
        session.headers.update({
            "User-Agent": UA,
            "Referer": "https://wizja.cc/",
            "Origin": "https://wizja.cc"
        })

        session.cookies.clear()


        url = page_url + f"&_={int(time.time())}"
        r = session.get(url, timeout=10)
        r.raise_for_status()

        html_txt = r.text


        patterns0 = [
            r"onclick\s*.+?(https.+?)'",
            r'<iframe[^>]+src=["\']([^"\']+)',
            r'changeSource[^>]+.(https?://.+).,'
        ]

        for pat in patterns0:
            links = re.findall(pat, html_txt)
            if links:
                link = None

                # 1. najlepsze – "kanal"
                for l in links:
                    if "kanal" in l:
                        link = l
                        break

                # 2. drugi wybór – "serwer"
                if not link:
                    for l in links:
                        if "serwer" in l:
                            link = l
                            break

                # 3. fallback – ostatni jak wcześniej
                if not link and links:
                    link = links[-1]


                    break

        if link:
            link = link.replace("\\/", "/")
            r = session.get(link, headers=HEADERS, timeout=10)

            html_txt = r.text
        patterns = [
            r'const\s+hlsUrl\s*=\s*"([^"]+)"',
            r'source:\s*"([^"]+\.m3u8[^"]*)"',
            r'(https?://[^"\']+\.m3u8[^"\']*)',
            r'(https?://.+?token.+)\"',
            r'(https:.+raw.mpd)\"'
        ]



        for pat in patterns:
            m = re.findall(pat, html_txt)

##            xbmcgui.('Dialog().textviewerlinki m', str(m))

            if m:
                stream = normalize_stream_url(m[0])
                stream = prefer_hls(stream, headers=HEADERS)
                # cookies z tej samej sesji
                cookie_str = "; ".join([f"{k}={v}" for k, v in session.cookies.items()])

                return stream

    except Exception as e:
        xbmc.log(f"[wizja] extract error: {e}", xbmc.LOGERROR)

    return None