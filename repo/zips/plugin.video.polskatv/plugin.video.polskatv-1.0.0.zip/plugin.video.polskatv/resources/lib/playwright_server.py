# -*- coding: utf-8 -*-
# playwright_server.py — Sweet.TV Free-only z ręcznym cookies_sweettv.json
# Autor: [Twoje imię], 2025

from flask import Flask, request, jsonify
from playwright.sync_api import sync_playwright
import json
import re
import os

app = Flask(__name__)

COOKIE_FILE = "cookies_sweettv.json"


def load_manual_cookies():
    """Wczytuje ciasteczka z pliku cookies_sweettv.json."""
    if not os.path.exists(COOKIE_FILE):
        print(f"[cookies] Brak pliku {COOKIE_FILE} — utworzono pusty szablon.")
        example = [
            {"name": "session", "value": "TU_WKLEJ_COOKIE", "domain": "sweet.tv", "path": "/"}
        ]
        with open(COOKIE_FILE, "w", encoding="utf-8") as f:
            json.dump(example, f, indent=2, ensure_ascii=False)
        return []
    try:
        with open(COOKIE_FILE, "r", encoding="utf-8") as f:
            cookies = json.load(f)
            if isinstance(cookies, list):
                print(f"[cookies] Załadowano {len(cookies)} ciasteczek z pliku.")
                return cookies
    except Exception as e:
        print(f"[cookies] Błąd odczytu pliku: {e}")
    return []


def sniff_manifest(url, wait=30):
    found = []

    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)

        context = browser.new_context()
        # załaduj ręczne cookies
        cookies = load_manual_cookies()
        if cookies:
            context.add_cookies(cookies)
            print("[cookies] Cookies dodane do kontekstu przeglądarki.")
        else:
            print("[cookies] Brak cookies (tryb pusty).")

        page = context.new_page()

        def on_request(req):
            u = req.url
            print("[request]", req.method, u)
            if re.search(r'cdn\.sweet\.tv/.+\.m3u8', u):
                print(f"[sniff] 🎯 {u}")
                if u not in found:
                    found.append(u)
        page.on("request", on_request)

        print(f"[goto] {url}")
        page.goto(url, wait_until="domcontentloaded")

        # czekamy nawet do 60s
        total_wait = 60000
        step = 1000
        waited = 0
        while waited < total_wait:
            page.wait_for_timeout(step)
            waited += step
            if any("session=" in u for u in found):
                break

        html = page.content()
        # zapisz aktualne cookies (odświeżenie sesji)
        context.storage_state(path=COOKIE_FILE)
        browser.close()

    first = found[0] if found else None
    return {"ok": True, "html": html, "found": found, "first": first}


@app.route("/fetch", methods=["POST"])
@app.route("/render", methods=["POST"])  # kompatybilność z sweet_tv.py
def render_page():
    data = request.get_json(force=True)
    url = data.get("url")
    wait = int(data.get("wait", 10))
    if not url:
        return jsonify({"ok": False, "error": "Brak URL"}), 400

    try:
        result = sniff_manifest(url, wait)
        snippet = result.get("html", "")
        print("----- HTML SNIPPET START -----")
        print(snippet[:800])
        print("----- HTML SNIPPET END -----")
        return jsonify(result)
    except Exception as e:
        print("[error]", e)
        return jsonify({"ok": False, "error": str(e)}), 500


if __name__ == "__main__":
    print("=== Playwright Server (Sweet.TV Free-only) ===")
    print("Nasłuchiwanie na http://127.0.0.1:9999")
    app.run(host="127.0.0.1", port=9999)
