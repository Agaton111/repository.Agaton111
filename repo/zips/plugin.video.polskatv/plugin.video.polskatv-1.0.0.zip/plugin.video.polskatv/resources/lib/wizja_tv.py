# -*- coding: utf-8 -*-
##### wizja_tv.py
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import sys
import os
import json
import re
import requests
import html
import urllib.parse
import time
from urllib.parse import urlparse

# =====================================================
# KONFIGURACJA
# =====================================================

ADDON = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo('path')

BASE_SITE = "https://wizja.cc/"

UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"
HEADERS = {
    "User-Agent": UA,
    "Referer": BASE_SITE
}
CACHE_TTL = 24 * 3600

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo("id")
PROFILE = xbmcvfs.translatePath(f"special://profile/addon_data/{ADDON_ID}")
CACHE_FILE = os.path.join(PROFILE, "wizja_channels.json")

params = dict(
    urllib.parse.parse_qsl(sys.argv[2][1:])
)



if not xbmcvfs.exists(PROFILE):
    xbmcvfs.mkdirs(PROFILE)

HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]

# GLOBAL SESSION (KLUCZOWE)
session = requests.Session()
session.headers.update(HEADERS)

# =====================================================
# KATEGORIE
# =====================================================
CATEGORIES = [
    "OGÓLNOTEMATYCZNE",
    "INFORMACYJNE",
    "SPORTOWE",
    "FILMOWE",
    "TVN Online",
    "NAUKOWE",
    "ROZRYWKA",
    "MUZYCZNE",
    "DLA DZIECI",
]

def get_epg_func():
    main = sys.modules.get("__main__")
    if main and hasattr(main, "epg_lista"):
        return main.epg_lista
    return None

# =====================================================
# CACHE
# =====================================================
def load_cache():
    if not os.path.exists(CACHE_FILE):
        return None
    if time.time() - os.path.getmtime(CACHE_FILE) > CACHE_TTL:
        return None
    try:
        with open(CACHE_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except:
        return None

def save_cache(data):
    try:
        with open(CACHE_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    except:
        pass

# =====================================================
# PARSOWANIE KANAŁÓW
# =====================================================
def fetch_channels():
    r = session.get(BASE_SITE, timeout=10)
    r.raise_for_status()
    html_txt = r.text

    sections = html_txt.split('<div class="section-header">')[1:]

    channels = []

    for idx, section in enumerate(sections):

        if idx >= len(CATEGORIES):
            category = "INNE"
        else:
            category = CATEGORIES[idx]

        for m in re.finditer(
            r'<a[^>]+href="([^"]+/livetv/details/[^"]+)"[^>]*>.*?'
            r'<img[^>]+src="([^"]+)".*?>.*?'
            r'<div class="channel-name">\s*([^<]+)\s*</div>',
            section,
            re.S
        ):
            url, icon, name = m.groups()

            channels.append({
                "name": html.unescape(name.strip()),
                "url": url.strip(),
                "icon": icon.strip(),
                "category": category
            })

    return channels

def get_channels():
    cached = load_cache()
    if cached:
        return cached

    data = fetch_channels()
    save_cache(data)
    return data

# =====================================================
# KATEGORIE MENU
# =====================================================
def list_categories():

    for cat in CATEGORIES:
        li = xbmcgui.ListItem(label=cat)
        icon_path = os.path.join(ADDON_PATH, "resources", "media", "wizja1.png")
        li.setArt({'icon': icon_path, 'thumb': icon_path})


        url = f"{BASE_URL}?action=wizja_category&cat={urllib.parse.quote(cat)}"

        xbmcplugin.addDirectoryItem(HANDLE, url, li, True)

    xbmcplugin.endOfDirectory(HANDLE)

# =====================================================
# LISTA KANAŁÓW
# =====================================================
def list_channels_by_category(category):
    channels = get_channels()

    epg_lista = get_epg_func()
    if not epg_lista:
        epg_lista = lambda x: []

    filtered = [c for c in channels if c.get("category") == category]

    epg_map = {
        e["nazwa"]: e
        for e in epg_lista([c["name"] for c in filtered])
    }

    for ch in filtered:
        epg = epg_map.get(ch["name"], {})
        opis = epg.get("opis") or ch["name"]
##        plakat = epg.get("plakat") or ch["icon"]
        plakat = epg.get("plakat")

        if not plakat or "image.tmdb.org" in plakat:
            plakat = ch["icon"]


        li = xbmcgui.ListItem(label=ch["name"], label2=opis)
        li.setInfo("video", {"title": ch["name"], "plot": opis})
        li.setArt({
            "thumb": plakat,
            "icon": plakat,
            "fanart": plakat
        })

        li.setProperty("IsPlayable", "true")

        play_url = (
            f"{BASE_URL}?action=wizja_play"
            f"&url={urllib.parse.quote(ch['url'])}"
            f"&name={urllib.parse.quote(ch['name'])}"
        )

        xbmcplugin.addDirectoryItem(HANDLE, play_url, li, False)

    xbmcplugin.endOfDirectory(HANDLE)
def normalize_stream_url(url):
    if not url:
        return None

    url = url.replace("\\/", "/")

    # =========================================
    # 1. TS → M3U8 (najważniejsze u Ciebie)
    # =========================================
    if "/tracks-" in url and ".ts" in url:
        base = url.split("/tracks-")[0]
        if "?" in url:
            query = url.split("?", 1)[1]
            return f"{base}/index.fmp4.m3u8?{query}"
        return f"{base}/index.fmp4.m3u8"

    # =========================================
    # 2. goły endpoint → M3U8
    # =========================================
    if re.search(r'/\d+/\?token=', url):
        return url.replace("/?token=", "/index.fmp4.m3u8?token=")

    # =========================================
    # 3. embed → M3U8
    # =========================================
    if "embed.html" in url:
        return url.replace("embed.html", "index.fmp4.m3u8")

    # =========================================
    # 4. MPD zostaw (fallback)
    # =========================================
    if ".mpd" in url:
        return url

    # =========================================
    # 5. M3U8 OK
    # =========================================
    if ".m3u8" in url:
        return url

    return url


def fix_url(u):
    if not u:
        return u

    u = u.replace("\\/", "/")

    parsed = urlparse(u)

    path = parsed.path.replace("/", "//")

    fixed = f"{parsed.scheme}://{parsed.netloc}{path}"

    if parsed.query:
        fixed += "?" + parsed.query

    return fixed

def prefer_hls(stream, headers=None):
    if not stream or ".mpd" not in stream:
        return stream

    hls = stream.replace(".mpd", ".m3u8")

    try:
        r = requests.get(hls, headers=headers, timeout=3)
        if r.status_code == 200 and "#EXTM3U" in r.text:
            return hls
    except:
        pass

    return stream


# =====================================================
# EXTRACT STREAMS (MULTI SOURCE)
# =====================================================
def extract_stream(page_url):
    try:
        session = requests.Session()

        session.headers.update({
            "User-Agent": UA,
######            "Referer": urllib.parse.quote(page_url, safe=":/?=&"),
            "Referer": "https://wizja.cc/",
            "Origin": "https://wizja.cc",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Accept-Language": "pl-PL,pl;q=0.9",
            "Connection": "keep-alive"
        })

        session.cookies.clear()

        url = urllib.parse.quote(page_url, safe=":/?=&") + f"&_={int(time.time())}"

        r1 = session.get(url, timeout=10)
        r1.raise_for_status()

        html_txt = r1.text

        patterns0 = [
            r"onclick\s*.+?(https.+?)'",
            r'<iframe[^>]+src=["\']([^"\']+)',
            r'changeSource[^>]+.(https?://.+).,',
            r'file:\s*"(https?://[^"]+)"'
        ]

        all_links = []

        for pat in patterns0:
            found = re.findall(pat, html_txt)
            if found:
                all_links.extend(found)

        all_links = list(dict.fromkeys(all_links))

        link = None

        if all_links:
##            labels = all_links  # 🔥 BEZ ZMIAN
            labels = []

            for i, l in enumerate(all_links):
                if "serwer" in l:
                    name = f"[SERWER] {l}"
                elif "kanal" in l:
                    name = f"[KANAL] {l}"
                else:
                    name = f"[LINK {i+1}] {l}"

                labels.append(name)



            dialog = xbmcgui.Dialog()
            choice = dialog.select("Wybierz źródło", labels)

            if choice == -1:
                return

            link = all_links[choice]
        if link:
            link = link.replace("\\/", "/")

            r = session.get(link, headers=HEADERS, timeout=10)

            html_txt = r.text

        patterns = [
            r'const\s+hlsUrl\s*=\s*"([^"]+)"',
            r'const.PlayS.+\s*.(http.+?)\"',
            r'source:\s*"([^"]+\.m3u8[^"]*)"',
            r'(https?://[^"\']+\.m3u8[^"\']*)',
            r'(https?://.+?token.+)\"',
            r'(https:.+raw.mpd)\"'
        ]


 #      with open(CACHE_FILE2, "w", encoding="utf-8") as f:
 #            f.write(str(html_txt))

        namezz1 = link.split("=")
        namezz = namezz1[-1]

        for pat in patterns:
            m = re.findall(pat, html_txt)

            if m:
                stream = normalize_stream_url(m[0])


                if "hdraw" in stream:
                    parts = stream.split("/")

                    m = re.search(r'enc=\d+', link)
                    if not m:
                        xbmcgui.Dialog().textviewer("ERROR", "Brak enc w link")
                        return
                    enc_val1 = m.group(0)
                    enc_val=enc_val1.replace("=","")

                    # 🔥 usuń enc130 i 003
                    i = 0
                    while i < len(parts):
                        if parts[i].startswith("enc"):
                            break
                        i += 1

                    base = "/".join(parts[:i])

                    stream = f"{base}/{enc_val}/{namezz}/{namezz}.mpd"

                if ".mpd" not in stream:
                    stream = prefer_hls(stream, headers=HEADERS)

                return stream

    except Exception as e:
        xbmc.log(f"[wizja] extract error: {e}", xbmc.LOGERROR)


##
##def get_sources(page_url, session):
##    r = session.get(page_url, timeout=10)
##    r.raise_for_status()
##
##    html = r.text
##
##    patterns = [
##        r"onclick\s*.+?(https.+?)'",
##        r'<iframe[^>]+src=["\']([^"\']+)',
##        r'changeSource[^>]+.(https?://.+).,',
##    ]
##
##    links = []
##
##    for pat in patterns:
##        found = re.findall(pat, html)
##        links.extend(found)
##
##    # 🔥 czyszczenie
##    links = [l.replace("\\/", "/") for l in links]
##
##    # 🔥 deduplikacja
##    links = list(dict.fromkeys(links))
##
##    return links
##
##def resolve_stream(url, session):
##    r = session.get(url, headers=HEADERS, timeout=10)
##    html = r.text
##
##    patterns = [
##        r'source:\s*"([^"]+\.m3u8[^"]*)"',
##        r'(https?://[^"\']+\.m3u8[^"\']*)',
##        r'(https:.+raw.mpd)"'
##    ]
##
##    for pat in patterns:
##        m = re.findall(pat, html)
##        if m:
##            return normalize_stream_url(m[0])
##
##    return None
##
##def extract_stream(page_url):
##    session = requests.Session()
##
##    session.headers.update({
##        "User-Agent": UA,
##        "Referer": "https://wizja.cc/",
##        "Origin": "https://wizja.cc"
##    })
##
##    # 🔹 krok 1 – zbierz źródła
##    sources = get_sources(page_url, session)
##
##    if not sources:
##        xbmcgui.Dialog().notification("Błąd", "Brak źródeł")
##        return
##
##    # 🔹 krok 2 – wybór tylko RAZ
##    if len(sources) == 1:
##        chosen = sources[0]
##    else:
##        labels = [f"Źródło {i+1}" for i in range(len(sources))]
##
##        dialog = xbmcgui.Dialog()
##        choice = dialog.select("Wybierz źródło", labels)
##
##        if choice == -1:
##            return
##
##        chosen = sources[choice]
##
##    # 🔹 krok 3 – resolve (BEZ żadnych dialogów)
##    stream = resolve_stream(chosen, session)
##
##    if not stream:
##        xbmcgui.Dialog().notification("Błąd", "Nie znaleziono streama")
##        return
##
##    return stream
##
##

# =====================================================
# PLAY
# =====================================================

def play_channel(url, name=None):
    """Uniwersalne odtwarzanie (MP4 / HLS / DASH)."""
    name   = params.get("name")

    if any(ext in url.lower() for ext in [".mp4", ".m3u8", ".mpd"]):
       url = url
    else:
       url = extract_stream(url)

    try:
        handle = int(sys.argv[1])
        li = xbmcgui.ListItem(path=url)
        li.setInfo("video", {"title": name or url})

        # --- MP4 ---
        if ".mp4" in url:
            li.setMimeType("video/mp4")
            li.setContentLookup(False)
        # --- HLS ---
        elif ".m3u8" in url:
            li.setMimeType("application/vnd.apple.mpegurl")
            li.setContentLookup(False)
            try:
                from inputstreamhelper import Helper
                hls = Helper("hls")
                if hls.check_inputstream():
                    li.setProperty("inputstream", hls.inputstream_addon)
                    li.setProperty("inputstream.adaptive.manifest_type", "hls")

                    # 🔥 tuning bufora
                    li.setProperty("inputstream.adaptive.stream_selection_type", "adaptive")
                    li.setProperty("inputstream.adaptive.live_delay", "3")
                    li.setProperty("inputstream.adaptive.min_buffer_time", "2")
                    li.setProperty("inputstream.adaptive.max_buffer_time", "10")

            except Exception as e:
                xbmcgui.Dialog().ok("Błąd odtwarzania", str(e))

        # --- DASH ---
        elif ".mpd" in url:
            xbmcgui.Dialog().notification(
                "MPD ",
                f"{name}",
                xbmcgui.NOTIFICATION_INFO,
                3500
            )

            li.setMimeType("application/dash+xml")
            li.setContentLookup(False)
            try:
                from inputstreamhelper import Helper
                dash = Helper("mpd")
                if dash.check_inputstream():
                    li.setProperty("inputstream", dash.inputstream_addon)
                    li.setProperty("inputstream.adaptive.manifest_type", "mpd")

            except Exception as e:
                xbmcgui.Dialog().ok("Błąd odtwarzania", str(e))

        xbmcplugin.setResolvedUrl(handle, True, li)
        return url   # <── DO co teraz
    except Exception as e:
        xbmcgui.Dialog().ok("Błąd odtwarzania", str(e))