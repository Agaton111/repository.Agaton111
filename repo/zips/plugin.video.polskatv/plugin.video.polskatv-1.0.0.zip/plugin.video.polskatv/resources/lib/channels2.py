# -*- coding: utf-8 -*-
"""
channels2.py
Automatyczne ładowanie listy M3U z zapisanego pliku JSON (m3u_path.json).
Nie wywołuje okien dialogowych. Zawsze udostępnia CHANNELS.
Jeśli plik m3u_path.json zostanie zmieniony — lista przeładuje się automatycznie.
"""

import os
import re
import urllib
import json
import xbmc
import xbmcgui
import xbmcvfs
import requests
import xbmcplugin
import sys
import time

ADDON_ID = "plugin.video.polskatv"
PROFILE_PATH = xbmcvfs.translatePath(f"special://profile/addon_data/{ADDON_ID}")
M3U_PATH_FILE = os.path.join(PROFILE_PATH, "m3u_path.json")
CACHE_FILE = os.path.join(PROFILE_PATH, "channels2_cache.json")

LOG_PREFIX = "[PolskaTV:channels2]"


def log(msg):
    xbmc.log(f"{LOG_PREFIX} {msg}", xbmc.LOGINFO)


# === 🔹 pomocnicze ===
def get_saved_m3u_path():
    """Zwraca ścieżkę M3U zapisaną w JSON lub None."""
    try:
        if not xbmcvfs.exists(M3U_PATH_FILE):
            return None
        with xbmcvfs.File(M3U_PATH_FILE, "r") as f:
            data = json.loads(f.read())
        return data.get("path")
    except Exception as e:
        log(f"Błąd get_saved_m3u_path: {e}")
        return None


def parse_m3u_text(text):
    """Parsuje M3U do listy kanałów."""
    channels = []
    if not text:
        return channels

    name = None
    logo = ""
    for raw in text.splitlines():
        line = raw.strip()
        if not line:
            continue
        if line.startswith("#EXTINF"):
            m_name = re.search(r'tvg-name="([^"]+)"', line)
            m_logo = re.search(r'tvg-logo="([^"]+)"', line)
            if m_name:
                name = m_name.group(1).strip()
                name = name.replace("FHD","")
                name = name.replace("POLSKA","")
                name = name.replace("PL:","")
                name = name.replace("HD","")
                name = name.replace("(480p)","")
                name = name.replace("(720p)","")
                name = name.replace("(1080p)","")



            else:
                parts = line.split(",", 1)
                name = parts[1].strip() if len(parts) > 1 else "Nieznany kanał"
                name = name.replace("FHD","")
                name = name.replace("POLSKA","")
                name = name.replace("PL:","")
                name = name.replace("HD","")

                name = name.replace("(288p)","")
                name = name.replace("(480p)","")
                name = name.replace("(576p)","")
                name = name.replace("(576i)","")

                name = name.replace("(720p)","")
                name = name.replace("(1080p)","")



            logo = m_logo.group(1).strip() if m_logo else ""
        elif line.startswith("http://") or line.startswith("https://"):
            channels.append({"name": name or url, "url": line, "icon": logo})
            name = None
            logo = ""
    return channels


def load_m3u(path):
    """Ładuje M3U (lokalnie lub HTTP)."""
    try:
        if path.startswith("http://") or path.startswith("https://"):
            r = requests.get(path, timeout=10, headers={"User-Agent": "Mozilla/5.0"})
            r.raise_for_status()
            return parse_m3u_text(r.text)
        else:
            if xbmcvfs.exists(path):
                with xbmcvfs.File(path, "r") as f:
                    return parse_m3u_text(f.read())
            else:
                with open(path, "r", encoding="utf-8", errors="ignore") as f:
                    return parse_m3u_text(f.read())
    except Exception as e:
        log(f"Błąd load_m3u: {e}")
        return []


def save_cache(channels):
    """Zapisz listę do lokalnego cache (JSON)."""
    try:
        with xbmcvfs.File(CACHE_FILE, "w") as f:
            f.write(json.dumps(channels, ensure_ascii=False))
    except Exception as e:
        log(f"Błąd zapisu cache: {e}")


def load_cache():
    """Odczytaj cache jeśli istnieje."""
    try:
        if xbmcvfs.exists(CACHE_FILE):
            with xbmcvfs.File(CACHE_FILE, "r") as f:
                data = json.loads(f.read())
            return data
    except Exception as e:
        log(f"Błąd odczytu cache: {e}")
    return []


def get_m3u_mtime(path):
    """Zwraca czas modyfikacji pliku lub 0 dla URL."""
    try:
        if path.startswith("http"):
            return 0
        if os.path.exists(path):
            return os.path.getmtime(path)
    except Exception:
        pass
    return 0


# === 📦 globalny stan ===
CHANNELS = []
_last_path = None
_last_mtime = 0
params = dict(
    urllib.parse.parse_qsl(sys.argv[2][1:])
)

def ensure_channels_loaded():
    """Wczytuje kanały jeśli lista jest pusta lub plik się zmienił."""
    global CHANNELS, _last_path, _last_mtime

    current_path = get_saved_m3u_path()
    if not current_path:
        log("Brak zapisanej ścieżki M3U – lista pusta.")
        CHANNELS = []
        return

    current_mtime = get_m3u_mtime(current_path)

    if (
        current_path != _last_path
        or current_mtime != _last_mtime
        or not CHANNELS
    ):
        CHANNELS = load_m3u(current_path)
        _last_path = current_path
        _last_mtime = current_mtime
        save_cache(CHANNELS)
        log(f"Wczytano {len(CHANNELS)} kanałów z {current_path}")
    else:
        log("Użyto buforowanej listy kanałów.")


# ---------------- play helper ----------------
def play_channel(url, name=None):
    """Odtwarzanie w Kodi z obsługą inputstreamhelper."""
    name   = params.get("name")

    try:

        handle = int(sys.argv[1])
       # ===== DIRECT FILES (mp4, mkv, itp.) ====

##        clean = url.lower().split("?")[0]

        if url.endswith((".mp4", ".mkv", ".avi", ".mov")):
            li.setMimeType("video/mp2t")
            li.setContentLookup(False)
            li.setProperty("inputstream", "inputstream.ffmpegdirect")
            li.setProperty("inputstream.ffmpegdirect.is_realtime_stream", "true")
            li.setProperty("inputstream.ffmpegdirect.stream_mode", "timeshift")
            li.setProperty("inputstream.ffmpegdirect.open_mode", "ffmpeg")
        if ":80" in url:

            li = xbmcgui.ListItem(path=url)
            li.setInfo("video", {"title": name})
            li.setProperty("IsPlayable", "true")

            # traktuj jako TS
            li.setMimeType("video/mp2t")
            li.setContentLookup(False)

            # 👉 pozwól Kodi chwilę „posłuchać” zanim zacznie dekodować
            li.setMimeType("video/mp2t")
            li.setContentLookup(False)

            li.setProperty("inputstream", "inputstream.ffmpeg")

            # analiza streamu
            li.setProperty("inputstream.ffmpeg.analyzeduration", "8000000")
            li.setProperty("inputstream.ffmpeg.probesize", "8000000")

            # 🔥 KLUCZOWE dla buforowania
            li.setProperty("inputstream.ffmpeg.fflags", "nobuffer")
            li.setProperty("inputstream.ffmpeg.flush_packets", "1")
            li.setProperty("inputstream.ffmpeg.reorder_queue_size", "1024")

            # reconnect (ważne przy dropach)
            li.setProperty("inputstream.ffmpeg.reconnect", "1")




            # 👉 małe opóźnienie startu (KLUCZ dla :80)
            xbmc.sleep(700 if ":80" in url else 200)

            xbmcplugin.setResolvedUrl(handle, True, li)
            return

        else :
            # ustawienia listitem
            li = xbmcgui.ListItem(path=final)
            li.setInfo("video", {"title": name or final})
            li.setProperty("IsPlayable", "true")

            # HLS
            if ".m3u8" in final:
                li.setMimeType("application/vnd.apple.mpegurl")
                li.setContentLookup(False)
                try:
                    from inputstreamhelper import Helper
                    hls = Helper("hls")
                    if hls.check_inputstream():
                        li.setProperty("inputstream", hls.inputstream_addon)
                        li.setProperty("inputstream.adaptive.manifest_type", "hls")
                except Exception as e:
                    log(f"⚠️ inputstream HLS: {e}")
            elif ".mpd" in final:
                li.setMimeType("application/dash+xml")
                li.setContentLookup(False)
                try:
                    from inputstreamhelper import Helper
                    dash = Helper("mpd")
                    if dash.check_inputstream():
                        li.setProperty("inputstream", dash.inputstream_addon)
                        li.setProperty("inputstream.adaptive.manifest_type", "mpd")
                except Exception as e:
                    log(f"⚠️ inputstream MPD: {e}")

            xbmcplugin.setResolvedUrl(handle, True, li)
    except :
        xbmcgui.Dialog().ok("Błąd odtwarzania", str(e))


# === 📢 automatyczne ładowanie przy imporcie ===
ensure_channels_loaded()
