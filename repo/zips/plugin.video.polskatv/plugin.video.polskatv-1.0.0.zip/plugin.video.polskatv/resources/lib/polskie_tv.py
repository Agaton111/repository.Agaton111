# -*- coding: utf-8 -*-
import os
import json
import time
import requests
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs
import urllib.parse
import sys
import urllib

# ------------------------------------------------------------
# KONFIGURACJA
# ------------------------------------------------------------
ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_PATH = xbmcvfs.translatePath(f"special://home/addons/{ADDON_ID}")
CACHE_PATH = xbmcvfs.translatePath(
    f"special://profile/addon_data/{ADDON_ID}/cache_tvp.json"
)

URL_API = "https://krainaabc.tvp.pl/sess/TVPlayer2/api.php"
UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"
HEADERS = {"User-Agent": UA}
CACHE_MAX_AGE = 2 * 3600

params = dict(
    urllib.parse.parse_qsl(sys.argv[2][1:])
)

# ------------------------------------------------------------
def log(msg, level=xbmc.LOGINFO):
    xbmc.log(f"[PolskaTV:TVP] {msg}", level)

# ------------------------------------------------------------
# MAPA NAZW → EPG.OVH
# ------------------------------------------------------------
LOGO_MAP = {
    "tvp1": "TVP 1",
    "tvp2": "TVP 2 HD",
    "tvpinfo": "TVP Info",
    "tvpabc": "TVP ABC",
    "tvpnauka": "TVP Nauka",
    "tvpsport": "TVP Sport",
    "tvpkultura": "TVP Kultura",
    "tvphistoria": "TVP Historia",
    "tvpdokument": "TVP Dokument",
    "tvpkobieta": "TVP Kobieta",
    "tvpolonia": "TVP Polonia",
    "tvpworld": "TVP World",
}

def beautify_name(key):
    return key.replace("-", " ").replace("_", " ").upper()

# ------------------------------------------------------------
def parse_jsonp_safe(text):
    try:
        start = text.find("{")
        end = text.rfind("}") + 1
        if start >= 0 and end > start:
            return json.loads(text[start:end])
    except Exception as e:
        log(f"JSONP error: {e}")
    return None

# ------------------------------------------------------------
def get_tvp_link(key, code_map, id_map):
    try:
        params = {
            "@method": "getTvpConfig",
            "@callback": "__cb__",
            "corsHost": "krainaabc.tvp.pl",
            "id": id_map[key],
        }
        r = requests.get(URL_API, params=params, headers=HEADERS, timeout=10)
        r.raise_for_status()
        data = parse_jsonp_safe(r.text)
        for f in data.get("content", {}).get("files", []):
            if f.get("type") == "hls":
                return f.get("url")
    except Exception as e:
        log(f"TVP API error {key}: {e}")
    return None

# ------------------------------------------------------------
def fetch_channels():
    channel_code = {
        "tvp1": "T1D",
        "tvp2": "T2D",
        "tvpinfo": "INF",
        "tvpabc": "442",
        "tvpsport": "KSP",
        "tvpkultura": "T5D",
        "tvphistoria": "TKH",
        "tvpdokument": "DOK",
        "tvpkobieta": "KBT",
        "tvpolonia": "T4D",
        "tvpworld": "PIE",
    }

    channel_identity = {
        "tvp1": "51689486",
        "tvp2": "51696811",
        "tvpinfo": "51696820",
        "tvpabc": "51696812",
        "tvpsport": "51696827",
        "tvpkultura": "51696822",
        "tvphistoria": "51696819",
        "tvpdokument": "53795159",
        "tvpkobieta": "53795158",
        "tvpolonia": "51696824",
        "tvpworld": "57181932",
    }

    fallback = {
        k: f"https://stream.tvp.pl/srv/live/{k}.stream/playlist.m3u8"
        for k in channel_code
    }

    channels = []

    for key in channel_code:
        url = get_tvp_link(key, channel_code, channel_identity)
        if not url:
            url = fallback.get(key)

        if not url:
            log(f"Brak streamu: {key}")
            continue

        name = LOGO_MAP.get(key, beautify_name(key))
        icon = f"https://epg.ovh/logo/{name.replace(' ', '+')}.png"

        channels.append(
            {
                "name": name,
                "url": url,
                "icon": icon,
            }
        )
        log(f"OK: {name}")

    return channels

# ------------------------------------------------------------
def load_cache():
    if not xbmcvfs.exists(CACHE_PATH):
        return None
    try:
        with xbmcvfs.File(CACHE_PATH) as f:
            data = json.loads(f.read())
        if time.time() - data["timestamp"] < CACHE_MAX_AGE:
            log("Używam cache TVP")
            return data["channels"]
    except Exception:
        pass
    return None

def save_cache(channels):
    xbmcvfs.mkdirs(os.path.dirname(CACHE_PATH))
    with xbmcvfs.File(CACHE_PATH, "w") as f:
        f.write(json.dumps(
            {"timestamp": time.time(), "channels": channels},
            ensure_ascii=False,
            indent=2
        ))

# ------------------------------------------------------------
def get_channels():
    cached = load_cache()
    if cached:
        return cached
    ch = fetch_channels()
    if ch:
        save_cache(ch)
    return ch

# ------------------------------------------------------------
CHANNELS = get_channels()

params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))

# ------------------------------------------------------------
def play_channel(url, name=None):
    name   = params.get("name")
    handle = int(sys.argv[1])
    li = xbmcgui.ListItem(path=url)
    li.setLabel(name or url)
    li.setInfo("video", {"title": name or url})

    li.setMimeType("application/vnd.apple.mpegurl")
    li.setContentLookup(False)

    try:
        from inputstreamhelper import Helper
        hls = Helper("hls")
        if hls.check_inputstream():
            li.setProperty("inputstream", hls.inputstream_addon)
            li.setProperty("inputstream.adaptive.manifest_type", "hls")
    except Exception as e:
        log(f"inputstream error: {e}")

    xbmcplugin.setResolvedUrl(handle, True, li)
    return url   # <── DO co teraz