# -*- coding: utf-8 -*-
import xbmc
import xbmcgui
import xbmcvfs
import inputstreamhelper
import os
import sys
import json
import time
import xbmcplugin
import urllib

# --- KONFIGURACJA ---
ADDON_ID = "plugin.video.polskatv"
PROFILE = xbmcvfs.translatePath(f"special://profile/addon_data/{ADDON_ID}")
LOG_FILE = os.path.join(PROFILE, "polskie_tvn_log.txt")

lic_url = "https://player.pl/playerapi/product/drm/widevine/"
lic_url2 = "?platform=ANDROID_TV&type=LIVE"
s_url1 = "https://r.dcs.redcdn.pl/livedash/o2/tvnplayer/live/"
##s_url2 = "/dai.isml/manifest.mpd"
s_url2 = "dai.isml.mpd"
UA = "okhttp/3.3.1 Android"

params = dict(
    urllib.parse.parse_qsl(sys.argv[2][1:])
)


# --- LOG ---
def log(msg):
    xbmc.log(f"[PolskaTV:polskie_tvn] {msg}", xbmc.LOGINFO)
    try:
        if not xbmcvfs.exists(PROFILE):
            xbmcvfs.mkdirs(PROFILE)
        # automatyczne czyszczenie loga > 500 KB
        if xbmcvfs.exists(LOG_FILE) and xbmcvfs.Stat(LOG_FILE).st_size() > 512000:
            xbmcvfs.delete(LOG_FILE)
        with open(LOG_FILE, "a", encoding="utf-8") as f:
            f.write(f"{time.strftime('%Y-%m-%d %H:%M:%S')} {msg}\n")
    except Exception:
        pass



# --- LISTA KANAŁÓW ---
CHANNELS = [
    {"name": "TVN", "url": "https://player.pl/playerplus/live/tvn-hd,1908473", "icon": "https://epg.ovh/logo/TVN+HD.png"},
    {"name": "TVN 7", "url": "https://player.pl/playerplus/live/tvn-7-hd,1908474", "icon": "https://epg.ovh/logo/TVN+7.png"},
    {"name": "TTV", "url": "https://player.pl/playerplus/live/ttv-hd,1908475", "icon": "https://epg.ovh/logo/TTV.png"},
    {"name": "TV 4 ", "url":"https://player.pl/live/tv-4,11046757", "icon": "https://epg.ovh/logo/TV+4.png"},

    {"name": "Metro", "url": "https://player.pl/playerplus/live/metro,2930752", "icon": "https://epg.ovh/logo/METRO.png"},
    {"name": "TVN Rewolucje w Kuchni Online", "url":"https://player.pl/playerplus/live/TVN-rewolucje-w-kuchni-online,8759890", "icon": "https://epg.ovh/logo/TVN+Rewolucje+w+Kuchni+Online.png"},
    {"name": "TVN Milionerzy Online", "url":"https://player.pl/playerplus/live/TVN-milionerzy-online,9083862", "icon": "https://epg.ovh/logo/TVN+Milionerzy+Online.png"},
    {"name": "TVN Kultowe Seriale Online", "url":"https://player.pl/playerplus/live/TVN-kultowe-seriale-online,8759882", "icon": "https://epg.ovh/logo/TVN+Kultowe+Seriale+Online.png"},
    {"name": "TVN Rajska Miłość Online", "url":"https://player.pl/playerplus/live/TVN-rajska-milosc-online,8759881", "icon": "https://epg.ovh/logo/TVN+Rajska+Mi%c5%82o%c5%9b%c4%87+Online.png"},
    {"name": "TVN Telenowele Online", "url":"https://player.pl/playerplus/live/TVN-telenowele-online,8759887", "icon": "https://epg.ovh/logo/TVN+Telenowele+Online.png"},
    {"name": "TVN Kryminalnie Online", "url":"https://player.pl/playerplus/live/TVN-kryminalnie-online,8759884", "icon": "https://epg.ovh/logo/TVN+Kryminalnie+Online.png"},
    {"name": "TVN Momenty Prawdy Online", "url":"https://player.pl/playerplus/live/TVN-momenty-prawdy-online,8759880", "icon": "https://epg.ovh/logo/TVN+Momenty+Prawdy+Online.png"},
    {"name": "TVN Życie Jak w Bajce Online", "url":"https://player.pl/playerplus/live/TVN-zycie-jak-w-bajce-online,8759891", "icon": "https://epg.ovh/logo/TVN+%c5%bbyci+%20Jak+w+Bajce+Online.png"},
    {"name": "TVN Szpitalne Historie Online", "url":"https://player.pl/playerplus/live/TVN-szpitalne-historie-online,8759892", "icon": "https://epg.ovh/logo/TVN+Szpitalne+Historie+Online.png"},
    {"name": "TVN Talk Show Online", "url":"https://player.pl/playerplus/live/TVN-talk-show-online,8759886", "icon": "https://epg.ovh/logo/TVN+Talk+Show+Online.png"},
    {"name": "TVN Szkoła Życia Online", "url":"https://player.pl/playerplus/live/TVN-szkola-zycia-online,8759893", "icon": "https://epg.ovh/logo/TVN+Szko%c5%82a+%c5%bbycia+Online.png"},
    {"name": "TVN W Domu Online", "url":"https://player.pl/playerplus/live/TVN-w-domu-online,8759889", "icon": "https://epg.ovh/logo/TVN+W+Domu+Online.png"},
    {"name": "TVN Seriale o Kobietach Online", "url":"https://player.pl/playerplus/live/TVN-seriale-o-kobietach-online,8759888", "icon":"https://epg.ovh/logo/TVN+Seriale+o+Kobietach+Online.png"},
    {"name": "TVN Moto Online", "url":"https://player.pl/playerplus/live/TVN-moto-online,8759883", "icon": "https://epg.ovh/logo/TVN+Moto+Online.png"},
    {"name": "TVN Usterka Online", "url":"https://player.pl/playerplus/live/TVN-usterka-online,8759885", "icon": "https://epg.ovh/logo/TVN+Usterka+Online.png"},
    {"name": "TVN Prawo i Życie Online", "url":"https://player.pl/playerplus/live/TVN-prawo-i-zycie-online,8759879", "icon": "https://epg.ovh/logo/TVN+Prawo+i+%c5%bbycie+Online.png"},



]




# --- GENERATOR STRUMIENIA ---
def build_stream_url(f_stream_url):
    """Zwraca (stream_url, license_url)"""
    try:
        idpp = f_stream_url.split(",", 1)
        idp = idpp[1]
        license_url = lic_url + idp + lic_url2

        name = idpp[0].strip()
        if name.startswith("https://") or name.startswith("http://"):
            slug = name.rstrip("/").split("/")[-1]
            slug = slug.replace("-online", "").replace("_hd", "").strip()
        else:
            slug = name
        slug = slug.replace("https://player.pl/playerplus/live/", "").replace("TVN-", "").replace("-","_").replace(" ", "_").lower()
        # dodaj prefix fast_ jeśli brak
##        if not slug.startswith("fast_"):
##            slug = "fast_" + slug
##        if slug == "fast_tvn_hd":
##            slug = "tvn"
##        if slug == "fast_tvn_7_hd":
##            slug = "tvn_7"
##        if slug == "fast_tv_4":
##            slug = "tv_4"
##        if slug == "fast_ttv_hd":
##            slug = "ttv"
##        if slug == "fast_metro":
##            slug = "metro"

##        stream_url = (
##            "https://r.dcs.redcdn.pl/livedash/o2/tvnplayer/live/"
##            + slug +
##            "dai.isml/manifest"
##        )

##        stream_url = "https://n-22-3.dcs.redcdn.pl/livedash/o2/tvnplayer/live/tvn/dai.isml/manifest.mpd"
        stream_url = s_url1 + s_url2

        log(f"🔗 Zbudowano URL: {stream_url}")
        log(f"🔑 Licencja: {license_url}")
        return stream_url, license_url
    except Exception as e:
        log(f"build_stream_url error: {e}")
        return None, None


# --- PLAY CHANNEL ---
def play_channel(url, name=None):
    """Odtwarza kanały TVN z DRM Widevine"""
    name   = params.get("name")
    try:
        handle = int(sys.argv[1])
        log(f"▶️ Odtwarzanie: {name} ({url})")

        stream_url, license_url = build_stream_url(url)
        if not stream_url:
            xbmcgui.Dialog().ok("Błąd", "Nie udało się utworzyć linku.")
            return

        PROTOCOL = "mpd"
        DRM = "com.widevine.alpha"

        is_helper = inputstreamhelper.Helper(PROTOCOL, drm=DRM)
        if not is_helper.check_inputstream():
            xbmcgui.Dialog().ok("Błąd", "Brak wsparcia dla InputStream Adaptive")
            return

        li = xbmcgui.ListItem(path=stream_url)
##        li.setInfo("video", {"title": name or url})
        info = li.getVideoInfoTag()
        info.setTitle(name)
        li.setProperty("IsPlayable", "true")
        li.setProperty("inputstream", is_helper.inputstream_addon)
        li.setMimeType("application/dash+xml")
        li.setContentLookup(False)

##        li.setProperty("inputstream.adaptive.manifest_type", PROTOCOL)
        li.setProperty("inputstream.adaptive.license_type", DRM)
        li.setProperty("inputstream.adaptive.license_key", license_url + "|Content-Type=|R{SSM}|")
        li.setProperty("inputstream.adaptive.license_flags", "persistent_storage")
        li.setProperty("inputstream.adaptive.stream_headers", f"User-Agent={UA}")

        xbmcplugin.setResolvedUrl(handle, True, li)

        return stream_url   # <── DO co teraz
    except Exception as e:
        log(f"❌ Błąd odtwarzania: {e}")
        xbmcgui.Dialog().ok("Błąd odtwarzania", str(e))
