## -*- coding: utf-8 -*-
"""
utils_stream.py
Uniwersalny pomocnik do wydobywania linków strumieni (m3u8/mpd/mp4).
Funkcja eksportowana: get_stream_link(page_url, use_yt_dlp=True)
Zwraca: bezpośredni URL do manifestu (string) lub None.
"""

import re
import requests
import subprocess
import shutil
import json
import xbmc

# yt_dlp może (ale nie musi) być dostępny jako moduł
try:
    from yt_dlp import YoutubeDL
except Exception:
    YoutubeDL = None

# Nagłówki domyślne
HEADERS = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Gecko/20100101 Firefox/119.0'}

# Krótkie logowanie do kodi
def log(msg):
    xbmc.log(f"[utils_stream] {msg}", xbmc.LOGINFO)


# -------------------
# Narzędzia pomocnicze
# -------------------
import re

def _normalize_url(url):
    """
    Normalizacja URL:
    - zamienia escape'owane ukośniki "\/" na "/"
    - zamienia "https:////cdn..." -> "https://cdn..."
    - scala wielokrotne '/' w ścieżce do pojedynczego '/' (ale **nie** usuwa '//' po schemacie)
    """
    if not url or not isinstance(url, str):
        return url

    # usuń backslash-escape
    url = url.replace('\\/', '/').strip().strip('"').strip("'")

    # 1) naprawiamy schemat: https:////... -> https://...
    url = re.sub(r'^(https?:)/*', r'\1//', url, flags=re.IGNORECASE)

    # 2) rozdzielamy schemat od reszty, żeby nie zniszczyć 'https://'
    m = re.match(r'^(https?://)(.*)$', url, flags=re.IGNORECASE)
    if m:
        scheme = m.group(1)
        rest = m.group(2)
        # zredukuj powtórzone // w reszcie do pojedynczego '/'
        rest = re.sub(r'/+', '/', rest)
        url = scheme + rest
    else:
        # brak schematu — i tak skalujemy powtórzenia
        url = re.sub(r'/+', '/', url)

    return url

def _find_candidates_in_html(html):
    """Zwraca listę kandydatów (możliwych URLi manifestów) znalezionych w HTML."""
    if not html:
        return []

    candidates = []

    # 1) elastyczny wariant na https:////cdn-... itp.
    pat1 = re.findall(r'https?:[\/\\]+[^\s\'"<>]*\.(?:m3u8|mpd|mp4)[^\s\'"<>]*', html, flags=re.IGNORECASE)
    candidates.extend(pat1)

    # 2) common JS patterns: src:"...m3u8" , file:"...m3u8", "hls":"...m3u8" etc.
    pat2 = re.findall(r'src\s*[:=]\s*"([^"]+\.(?:m3u8|mpd|mp4)[^"]*)"', html, flags=re.IGNORECASE)
    candidates.extend(pat2)
    pat3 = re.findall(r'file\s*[:=]\s*"([^"]+\.(?:m3u8|mpd|mp4)[^"]*)"', html, flags=re.IGNORECASE)
    candidates.extend(pat3)
    pat4 = re.findall(r'"(https?://[^"]+?\.m3u8[^"]*)"', html, flags=re.IGNORECASE)
    candidates.extend(pat4)

    # 3) window.__INITIAL_STATE__ (megogo-style) - spróbuj znaleźć JSON i w nim m3u8
    m = re.search(r'window\.__INITIAL_STATE__\s*=\s*(\{.*?\});', html, flags=re.DOTALL)
    if m:
        try:
            data = m.group(1)
            dump = data  # nie parsujemy zawsze, szukamy m3u8 w tekście JSON
            found = re.findall(r'https?://[^\s\'"<>]+?\.m3u8[^\s\'"<>]*', dump, flags=re.IGNORECASE)
            candidates.extend(found)
        except Exception:
            pass

    # deduplikacja, utrzymujemy kolejność
    seen = set()
    out = []
    for c in candidates:
        c = c.strip()
        if c and c not in seen:
            seen.add(c)
            out.append(c)
    return out


# -------------------
# yt_dlp helpers
# -------------------
def _try_yt_dlp_module(url, ydl_opts=None):
    """Spróbuj użyć modułu yt_dlp (jeśli dostępny). Zwraca URL lub None."""
    if not YoutubeDL:
        log("yt_dlp module unavailable")
        return None
    try:
        opts = {'quiet': True, 'no_warnings': True, 'skip_download': True, 'noplaylist': True}
        if isinstance(ydl_opts, dict):
            opts.update(ydl_opts)
        with YoutubeDL(opts) as ydl:
            info = ydl.extract_info(url, download=False)
            # jeśli entries (playlist) => weź pierwszy
            if isinstance(info, dict) and 'entries' in info and info['entries']:
                info = info['entries'][0]
            # spróbuj znaleźć m3u8 w formats (najpierw)
            if isinstance(info, dict) and 'formats' in info:
                # preferuj formaty, które maja protokół m3u8 lub ext m3u8/mp4
                for f in reversed(info['formats']):
                    furl = f.get('url')
                    if furl and ('.m3u8' in furl or f.get('protocol', '').lower().startswith('m3u8') or (f.get('ext') and f.get('ext').lower() in ('m3u8','mpd'))):
                        log(f"yt_dlp module: wybrano format {furl}")
                        return _normalize_url(furl)
                # fallback: najlepszy bitrate/mp4
                try:
                    best = max(info['formats'], key=lambda x: (x.get('tbr') or 0, x.get('height') or 0))
                    if best and best.get('url'):
                        log(f"yt_dlp module: fallback best {best.get('url')}")
                        return _normalize_url(best.get('url'))
                except Exception:
                    pass
            # czasem info['url'] jest bez formats
            if isinstance(info, dict) and info.get('url'):
                return _normalize_url(info.get('url'))
    except Exception as e:
        log(f"yt_dlp module error: {e}")
    return None


def _try_yt_dlp_cli(url, extra_args=None):
    """Spróbuj uruchomić binarny yt-dlp (yt-dlp -J url)."""
    binary = shutil.which("yt-dlp")
    if not binary:
        log("yt-dlp binary not found in PATH")
        return None
    cmd = [binary, "-J", url]
    if extra_args and isinstance(extra_args, list):
        cmd[1:1] = extra_args
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
        if p.returncode != 0:
            log(f"yt-dlp CLI returned {p.returncode}: {p.stderr.strip()}")
            return None
        info = json.loads(p.stdout)
        if isinstance(info, dict) and info.get('entries'):
            info = info['entries'][0]
        if isinstance(info, dict) and info.get('formats'):
            for f in reversed(info['formats']):
                if f.get('url') and ('.m3u8' in f.get('url') or (f.get('ext') and f.get('ext').lower() in ('m3u8','mp4'))):
                    return _normalize_url(f.get('url'))
            try:
                best = max(info['formats'], key=lambda x: (x.get('tbr') or 0, x.get('height') or 0))
                return _normalize_url(best.get('url'))
            except Exception:
                pass
        if isinstance(info, dict) and info.get('url'):
            return _normalize_url(info.get('url'))
    except Exception as e:
        log(f"yt-dlp CLI error: {e}")
    return None


# -------------------
# GŁÓWNA FUNKCJA
# -------------------
def get_stream_link(page_url, use_yt_dlp=True, timeout=10):
    """
    Główne API — spróbuj zwrócić bezpośredni link do manifestu (m3u8/mpd/mp4).
    Parametry:
      - page_url (str)
      - use_yt_dlp (bool) - czy używać yt_dlp jako fallback
      - timeout (int)
    Zwraca URL (string) lub None.
    """
    log(f"get_stream_link: start dla {page_url}")

    # 0) jeśli już jest manifest
    if isinstance(page_url, str) and re.search(r'\.(m3u8|mpd|mp4)(\?|$)', page_url, flags=re.IGNORECASE):
        fixed = _normalize_url(page_url)
        log(f"get_stream_link: podano bezpośredni manifest -> {fixed}")
        return fixed

    # 1) pobierz HTML
    html = None
    try:
        log(f"get_stream_link: pobieram HTML z {page_url}")
        resp = requests.get(page_url, headers=HEADERS, timeout=timeout)
        html = resp.text or ""
        log(f"get_stream_link: HTML pobrany, długość {len(html)}")
    except Exception as e:
        log(f"get_stream_link: błąd pobierania HTML: {e}")
        html = ""

    # 2) regexy / parsowanie HTML (szukamy kandydatów)
    try:
        candidates = _find_candidates_in_html(html)
        if candidates:
            log(f"get_stream_link: znaleziono {len(candidates)} kandydat(ów) w HTML")
            for cand in candidates:
                fixed = _normalize_url(cand)
                log(f"get_stream_link: kandydat -> {fixed}")
                # opcjonalnie można sprawdzić czy URL odpowiada HEAD requestem, ale to zwalnia
                return fixed
        else:
            log("get_stream_link: brak kandydatów w HTML (regex)")
    except Exception as e:
        log(f"get_stream_link: wyjątek przy parsowaniu HTML: {e}")

    # 3) spróbuj yt_dlp (moduł)
    if use_yt_dlp:
        url_from_ydl = _try_yt_dlp_module(page_url)
        if url_from_ydl:
            log(f"get_stream_link: yt_dlp module zwrócił {url_from_ydl}")
            return url_from_ydl
        # fallback na CLI
        url_from_cli = _try_yt_dlp_cli(page_url)
        if url_from_cli:
            log(f"get_stream_link: yt-dlp CLI zwrócił {url_from_cli}")
            return url_from_cli

    # 4) brak wyniku
    log("get_stream_link: ❌ nie udało się znaleźć strumienia")
    return None


# pokaż, skąd ładowany (przy debugu)
try:
    log(f"utils_stream loaded")
except Exception:
    pass


# -------------------
# Eksport
# -------------------
__all__ = ["get_stream_link"]
