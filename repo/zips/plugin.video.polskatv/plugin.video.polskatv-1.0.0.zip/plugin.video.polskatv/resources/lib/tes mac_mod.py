# -*- coding: utf-8 -*-
# mac_mod.py — prosty moduł TV/VOD, zapis kategorii do plików JSON

import os
import json
import time
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
from resources.lib import mac_api_li
import sys
import xbmcvfs
import re



HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]
ADDON = xbmcaddon.Addon()
PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))

SLOTS_FILE = os.path.join(PROFILE, "slots.json")
TV_JSON = os.path.join(PROFILE, "tv_categories.json")
VOD_JSON = os.path.join(PROFILE, "vod_categories.json")


def load_slots():
    if os.path.exists(SLOTS_FILE):
        try:
            with open(SLOTS_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except:
            return []
    return []


def add_slot():
    portal = xbmcgui.Dialog().input("Podaj adres portalu")
    if not portal:
        return

    raw_mac = xbmcgui.Dialog().input(
        "Podaj adres MAC (można wkleić wiele, oddziel przecinkiem lub enterem)"
    )

    mac_list = normalize_mac_list(raw_mac)

    if not mac_list:
        xbmcgui.Dialog().notification("MAC", "Niepoprawny format MAC")
        return

    slots = load_slots()
    slots.append({
        "portal": portal,
        "mac": "\n".join(mac_list)
    })

    save_slots(slots)

    xbmc.executebuiltin("Container.Refresh")

def normalize_mac_list(raw_input):
    if not raw_input:
        return []
    parts = re.split(r"[,\n;\s]+", raw_input)
    macs = []
    for part in parts:
        clean = part.strip().upper()
        clean = re.sub(r"[^0-9A-F]", "", clean)
        if len(clean) != 12:
            continue
        formatted = ":".join(clean[i:i+2] for i in range(0, 12, 2))
        macs.append(formatted)
    macs = list(dict.fromkeys(macs))
    return macs

def save_slots(slots):
    os.makedirs(os.path.dirname(SLOTS_FILE), exist_ok=True)
    with open(SLOTS_FILE, "w", encoding="utf-8") as f:
        json.dump(slots, f, ensure_ascii=False, indent=2)


        return
    mac = xbmcgui.Dialog().input("Podaj MAC")
    if not mac:
        return
    slots = load_slots()
    slots.append({"portal": portal.rstrip("/") + "/", "mac": mac.strip()})
    save_slots(slots)
    xbmcgui.Dialog().notification("Slot", "Dodano slot", xbmcgui.NOTIFICATION_INFO, 3000)


def show_menu():
    slots = load_slots()
    if not slots:
        xbmcgui.Dialog().notification("Brak slotów", "Dodaj przynajmniej jeden slot", xbmcgui.NOTIFICATION_ERROR, 5000)
        add_slot()
        slots = load_slots()
        if not slots:
            return

    # wybierz slot jeśli więcej niż 1
    slot_index = 0
    if len(slots) > 1:
        items = [s["portal"] for s in slots]
        choice = xbmcgui.Dialog().select("Wybierz slot", items)
        if choice == -1:
            return
        slot_index = choice

    slot = slots[slot_index]

    menu = ["TV", "VOD"]
    choice = xbmcgui.Dialog().select("Wybierz kategorię", menu)
    if choice == -1:
        return


    if choice == 0:
        xbmc.log("TV START", xbmc.LOGERROR)

        portal = slot["portal"].rstrip("/") + "/"
        mac = slot["mac"]

        token = mac_api_li.do_handshake(portal, mac, force=True)
        if not token:
            xbmcgui.Dialog().notification("TV", "Handshake fail", xbmcgui.NOTIFICATION_ERROR, 4000)
            return

        categories = []

        def try_request(url):
            try:
                raw = mac_api_li.mag_request(url, mac, portal, token)
                xbmc.log(f"[TV RAW STRUCTURE] {str(json.loads(raw))[:1000]}", xbmc.LOGERROR)
                if not raw:
                    return None
                return json.loads(raw)

            except:
                return None

        # 1️⃣ get_genre_id_map (najlepsze – najmniejszy plik)
        url = portal + "portal.php?type=itv&action=get_genre_id_map&JsHttpRequest=1-xml"
        data = try_request(url)

        if data and isinstance(data.get("js"), dict):
            genres = data.get("js", {})
            categories = [{"id": k, "title": v} for k, v in genres.items()]
            xbmc.log("[TV] get_genre_id_map OK", xbmc.LOGINFO)

        # 2️⃣ get_categories
        if not categories:
            url = portal + "portal.php?type=itv&action=get_categories&JsHttpRequest=1-xml"
            data = try_request(url)

            if data and isinstance(data.get("js"), list):
                categories = data.get("js", [])
                xbmc.log("[TV] get_categories OK", xbmc.LOGINFO)

        # 3️⃣ get_genres
        if not categories:
            url = portal + "portal.php?type=itv&action=get_genres&JsHttpRequest=1-xml"
            data = try_request(url)

            if data and isinstance(data.get("js"), list):
                categories = data.get("js", [])
                xbmc.log("[TV] get_genres OK", xbmc.LOGINFO)

        # 4️⃣ Fallback → get_all_channels (ciężki)
        if not categories:
            xbmc.log("[TV] FALLBACK get_all_channels", xbmc.LOGWARNING)

            url = portal + "portal.php?type=itv&action=get_all_channels&JsHttpRequest=1-xml"
            data = try_request(url)

            if data:
                if isinstance(data.get("js"), dict):
                    channels = data.get("js", {}).get("data", [])
                elif isinstance(data.get("js"), list):
                    channels = data.get("js")
                else:
                    channels = []

                # wyciągamy unikalne genre_id
                genre_map = {}
                for ch in channels:
                    gid = str(ch.get("genre_id"))
                    title = ch.get("genre_title", gid)
                    if gid not in genre_map:
                        genre_map[gid] = title

                categories = [{"id": k, "title": v} for k, v in genre_map.items()]

        if not categories:
            xbmc.log("[TV] categories EMPTY", xbmc.LOGERROR)
            categories = []  # wymuś zapis nawet pustego

        save_file(categories, TV_JSON)

        xbmc.log(f"[TV] Zapisano plik: {TV_JSON}", xbmc.LOGERROR)

        xbmcgui.Dialog().notification(
            "TV",
            f"Zapisano {len(categories)} kategorii",
            xbmcgui.NOTIFICATION_INFO,
            4000
        )



##        if not categories:
##            xbmcgui.Dialog().notification("TV", "Brak kategorii", xbmcgui.NOTIFICATION_ERROR, 4000)
##            return
##
##        save_file(categories, TV_JSON)
##
##        xbmcgui.Dialog().notification(
##            "TV",
##            f"Zapisano {len(categories)} kategorii",
##            xbmcgui.NOTIFICATION_INFO,
##            4000
##        )
##        save_file(categories, TV_JSON)
##        xbmcgui.Dialog().notification("TV", f"Zapisano {len(categories)} kategorii", xbmcgui.NOTIFICATION_INFO, 3000)

    if choice == 1:
        categories = mac_api_li.get_categories(slot_index, "vod") or []
        save_file(categories, VOD_JSON)
        xbmcgui.Dialog().notification("VOD", f"Zapisano {len(categories)} kategorii", xbmcgui.NOTIFICATION_INFO, 3000)


def save_file(data, path):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


if __name__ == "__main__":
    show_menu()