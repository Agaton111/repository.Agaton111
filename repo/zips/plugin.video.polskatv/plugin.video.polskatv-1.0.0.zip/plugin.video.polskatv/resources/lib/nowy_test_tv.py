# -*- coding: utf-8 -*-
"""
nowy_test.py
Uniwersalny ekstraktor linków HLS/DASH/MP4 dla różnych stron (bez Playwright).
Funkcje:
 - extract_hls_from_page(page_url) -> zwraca link (m3u8/mpd/mp4) lub None
 - play_channel(url, name=None) -> odtwarza w Kodi
 - CHANNELS -> lista testowa (na końcu)
- gdy brak linku -> próba cmf3.run_dynamic_parse(page_url)
- MPD-ASK: gdy znaleziono .mpd i nie widać clearkey/license w kontekście -> pyta użytkownika czy odtwarzać
"""
import os
import re
import sys
import json
import time
import requests
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs
import importlib
import urllib
import urllib.parse



import inputstreamhelper
from bs4 import BeautifulSoup
from urllib.parse import urljoin, urlparse
from resources.lib import jsunpack
from resources.lib import wizja_resolver

# ------------------------------------------------------------
# KONFIG
# ------------------------------------------------------------
ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_PATH = xbmcvfs.translatePath(f"special://home/addons/{ADDON_ID}")
ADDON_PROFILE = xbmcvfs.translatePath(f"special://profile/addon_data/{ADDON_ID}")
LOG_FILE = os.path.join(ADDON_PROFILE, "nowy_test_log.txt")
CACHE_FILE = os.path.join(ADDON_PROFILE, "nowy_test_cache.json")
LOG_MAX_SIZE = 500 * 1024
CACHE_MAX_AGE = 3600       #3 * 3600  # 3 godziny
UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"
HEADERS = {"User-Agent": UA}
# ------------------------------------------------------------
params = dict(
    urllib.parse.parse_qsl(sys.argv[2][1:])
)

def _ensure_profile():
    try:
        if not xbmcvfs.exists(ADDON_PROFILE):
            xbmcvfs.mkdirs(ADDON_PROFILE)
    except Exception:
        pass

def log(msg, level=xbmc.LOGINFO):
    """Zapis do logfile w userdata i do loga Kodi."""
    try:
        _ensure_profile()
        # rotate
        if os.path.exists(LOG_FILE) and os.path.getsize(LOG_FILE) > LOG_MAX_SIZE:
            try:
                os.remove(LOG_FILE)
            except Exception:
                pass
        with open(LOG_FILE, "a", encoding="utf-8") as f:
            f.write(f"{time.strftime('%Y-%m-%d %H:%M:%S')} {msg}\n")
    except Exception:
        pass
    xbmc.log(f"[PolskaTV:nowy_test] {msg}", level)

# ---------------- utilities ----------------
def normalize_url(u, base=None):
    """Poprawia URL:
       - łączy relatywne odniesienia z base
       - usuwa nadmiarowe slashe (https://// -> https://)
       - dodaje https: jeśli url zaczyna się od //embed...
    """
    if not u:
        return None
    u = u.strip()
    # if relative and base provided
    try:
        if base and not bool(urlparse(u).scheme):
            u = urljoin(base, u)
    except Exception:
        pass
    # normalize slashes after scheme
    u = re.sub(r'^(https?:)/+', r'\1//', u)
    # //something -> https://something
    if u.startswith("//"):
        u = "https:" + u
    return u

def looks_like_manifest(u):
    if not u:
        return False
    return bool(re.search(r'\.(m3u8|mpd|mp4)(?:[\?#].*)?$', u, re.IGNORECASE)) or \
           "playlist" in u or "masterlist" in u or "/live" in u

def page_has_drm(text):
    if not text:
        return False
    return bool(re.search(r'clearkey|clearKeys|license|drm|keyId|widevine|playready', text, re.IGNORECASE))

# ---------------- cache ----------------
def load_cache():
    _ensure_profile()
    if not xbmcvfs.exists(CACHE_FILE):
        return {}
    try:
        with xbmcvfs.File(CACHE_FILE) as f:
            data = json.loads(f.read())
        now = time.time()
        valid = {k: v for k, v in data.items() if now - v.get("time", 0) < CACHE_MAX_AGE}
        return valid
    except Exception as e:
        log(f"⚠️ load_cache error: {e}")
        return {}

def save_cache(data):
    try:
        _ensure_profile()
        dirp = os.path.dirname(CACHE_FILE)
        if not xbmcvfs.exists(dirp):
            xbmcvfs.mkdirs(dirp)
        with xbmcvfs.File(CACHE_FILE, "w") as f:
            f.write(json.dumps(data, ensure_ascii=False, indent=2))
        log(f"💾 Zapisano cache ({len(data)} pozycji)")
    except Exception as e:
        log(f"⚠️ save_cache error: {e}")

CACHE = load_cache()

# ---------------- helper: MPD decision ----------------
def handle_mpd_candidate(candidate, context_text, page_url):
    """
    Jeśli .mpd i brak DRM w kontekście -> pytamy użytkownika (MPD-ASK).
    Jeżeli user zgadza się odtwarzać -> zwróć True (akceptuj).
    W przeciwnym wypadku -> spróbuj cmf3 fallback i zwróć False.
    """
    if not candidate or not candidate.lower().endswith(".mpd"):
        return True
    has = page_has_drm(context_text)
    if has:
        log(f"🟢 MPD z DRM widoczny w kontekście -> akceptuję: {candidate}")
        return True
    # brak DRM w tekście - pytamy użytkownika
    try:
        choice = xbmcgui.Dialog().yesno("MPD wykryto", f"Znaleziono manifest MPD:\n{candidate}\n\nBrak widocznych kluczy/DRM w stronie.\nSpróbować odtworzyć?", yeslabel="Tak", nolabel="Nie (analiza)")
    except Exception:
        choice = False
    if choice:
        log(f"👤 Użytkownik: próbujemy odtworzyć MPD: {candidate}")
        return True
    # user declined -> call cmf3 fallback
    log(f"👤 Użytkownik odmówił odtwarzania MPD -> uruchamiam cmf3 dla: {page_url}")
    try:
        import cmf3

        if hasattr(cmf3, "run_dynamic_parse"):
            res = cmf3.run_dynamic_parse(page_url)
            log(f"cmf3 zwrócił {len(res) if res else 0} linków")
            # jeśli cmf3 zwrócił jakieś, wybierz pierwszy manifest-like
            if res:
                for r in res:
                    rr = normalize_url(r, page_url)
                    if rr and looks_like_manifest(rr):
                        CACHE[page_url] = {"url": rr, "time": time.time()}
                        save_cache(CACHE)
                        return False  # main extractor will pick from cache on next call (or we can return rr)
    except Exception as e:
        log(f"⚠️ cmf3 error: {e}")
    return False

# ---------------- main extraction ----------------
def extract_hls_from_page(page_url, timeout=10):

    # wizja resolver
    if "wizja.cc" in page_url:
        stream = wizja_resolver.extract_stream(page_url)
        return stream

    # cache short-circuit
    try:
        if page_url in CACHE and time.time() - CACHE[page_url].get("time", 0) < CACHE_MAX_AGE:
            cached_url = CACHE[page_url]["url"]
            if 'token' in cached_url:
                pass
            else:
                log(f"📦 Używam cache dla {page_url} → {cached_url}")
                return cached_url
    except Exception:
        pass

    # cache short-circuit
    try:
        if page_url in CACHE and time.time() - CACHE[page_url].get("time", 0) < CACHE_MAX_AGE:
            cached_url = CACHE[page_url]["url"]
            if 'token' in cached_url:
               pass
            else :
                log(f"📦 Używam cache dla {page_url} → {cached_url}")
                return cached_url
    except Exception:
        pass

    log(f"📡 Pobieram stronę: {page_url}")
    try:
        resp = requests.get(page_url, headers=HEADERS, timeout=timeout)
        resp.raise_for_status()
        html = resp.text

    except Exception as e:
        log(f"❌ Błąd pobierania: {e}")
        return None

    base = page_url
    soup = BeautifulSoup(html, "html.parser")
##    xbmcgui.Dialog().textviewer('info', str(soup))


    # --- 1) MEDIA_ID + playerDataUrl pattern ---
    try:
        m_params = re.search(r'var\s+params\s*=\s*\{(.+?)\};', html, re.DOTALL)
        block = m_params.group(1)
        if m_params:

##            xbmcgui.Dialog().textviewer('m_params block', str(block))
            mid = re.search(r'mediaId\s*:\s*[\'\"]?(\d+)[\'\"]?', block)
            pdu = re.search(r'playerDataUrl\s*:\s*[\'\"]([^\'\"]+)[\'\"]', block)

            if mid and pdu:
                media_id = mid.group(1)
                player_template = pdu.group(1)
                player_url = normalize_url(player_template.replace("MEDIA_ID", media_id), base)
                log(f"🧩 MEDIA_ID/playerDataUrl → {player_url}")
                try:
                    j = requests.get(player_url, headers=HEADERS, timeout=timeout).json()
                    for src in j.get("mediaItem", {}).get("playback", {}).get("mediaSources", []):
                        url_candidate = normalize_url(src.get("url"), player_url)

                        # PATCH: tvpuls -> tvpulsraw
                        if url_candidate and "tvpuls/tvpuls.mpd" in url_candidate:
                            url_candidate = url_candidate.replace("/tvpuls/tvpuls.mpd", "/tvpulsraw/tvpulsraw.mpd")
                            log(f"🔧 TVPULS PATCH -> {url_candidate}")
                        if looks_like_manifest(url_candidate):
                            # MPD decision
                            if handle_mpd_candidate(url_candidate, json.dumps(j), page_url):

                                CACHE[page_url] = {"url": url_candidate, "time": time.time()}
                                save_cache(CACHE)
                                return url_candidate
                            else:
                                return None
                except Exception as e:
                    log(f"⚠️ JSON playerDataUrl error: {e}")

        if "mediaId:" in block :
             pat = r'mediaId:\s*"(\d+)"'
             pat2 = r'playerDataUrl:*\s\"(https.+?)\"'
             mediald = re.search(pat, block)
             mediald = mediald.group(1)

             newurl =re.search(pat2, block)
             newurl = newurl.group(1)
             if "MEDIA_ID" in newurl:
                 newurl= newurl.replace("MEDIA_ID",mediald)

                 resp = requests.get(newurl, headers=HEADERS, timeout=10)
                 resp.raise_for_status()
                 html = resp.text
                 match = re.search(r'(.*masterlist.m3u8)', html)




    except Exception as e:
        log(f"⚠️ MEDIA_ID handling error: {e}")

    # --- 2) manifestUri w script lub skryptowe linki ---
    try:
        for s in soup.find_all("script"):
            text = s.string or s.get_text() or ""
            # manifestUri pattern
            m = re.search(r'manifestUri\s*[:=]\s*[\'\"]([^\'\"]+)[\'\"]"gm', text)
            if m:
                candidate = normalize_url(m.group(1), base)
                # PATCH: tvpuls -> tvpulsraw
                if candidate and "tvpuls/tvpuls.mpd" in candidate:
                    candidate = candidate.replace("/tvpuls/tvpuls.mpd", "/tvpulsraw/tvpulsraw.mpd")
                    log(f"🔧 TVPULS PATCH -> {candidate}")
                log(f"🔎 manifestUri → {candidate}")
                if handle_mpd_candidate(candidate, text, page_url):
                    CACHE[page_url] = {"url": candidate, "time": time.time()}
                    save_cache(CACHE)
                    return candidate
                else:
                    return None
            # inline manifest urls inside script

            found = re.findall(r'"https?://[^\s\'\"<>]+?\.(?:m3u8|mpd|mp4)[^\s\'\"<>]*"gm', text)

            for f in found:
                f2 = normalize_url(f, base)
                if f2 and "tvpuls/tvpuls.mpd" in f2:
                    f2 = f2.replace("/tvpuls/tvpuls.mpd", "/tvpulsraw/tvpulsraw.mpd")
                    log(f"🔧 TVPULS PATCH -> {f2}")
                log(f"🔎 skrypt found 22 → {f2}")
                if looks_like_manifest(f2):
                    if handle_mpd_candidate(f2, text, page_url):
                        CACHE[page_url] = {"url": f2, "time": time.time()}
                        save_cache(CACHE)
                        return f2
                    else:
                        return None
    except Exception as e:
        log(f"⚠️ manifestUri search error: {e}")

    # --- 3) bezpośredni regex w HTML ---
    try:
        m = re.search(r'"https?://[^\s\'\"<>]+?\.(?:m3u8|mpd|mp4)[^\s\'\"<>]*"gm', html)

        if m:
            candidate = normalize_url(m.group(0), base)
            if candidate and "tvpuls/tvpuls.mpd" in candidate:
                candidate = candidate.replace("/tvpuls/tvpuls.mpd", "/tvpulsraw/tvpulsraw.mpd")
                log(f"🔧 TVPULS PATCH -> {candidate}")
            log(f"🔗 Bezpośredni link → {candidate}")


            if handle_mpd_candidate(candidate, html, page_url):
                CACHE[page_url] = {"url": candidate, "time": time.time()}
                save_cache(CACHE)
                return candidate



            else:
                return None
    except Exception as e:
        log(f"⚠️ HTML regex error: {e}")

    # --- 4) IFRAME: pobierz stronę iframe i analizuj (rekurencyjnie bardzo ostrożnie) ---
    try:
        for ifr in soup.find_all("iframe"):
            src = ifr.get("src") or ifr.get("data-src") or ""
            srcn = normalize_url(src, base)

            if 'play.html?name=' in srcn:
                srcn=srcn.replace('play.html?name=','streams/')+'.m3u8'


            if '.m3u8' in srcn:
                return srcn

            if not srcn:
                continue
            log(f"🔎 iframe w nowy test 1a: {srcn}")
            # pobierz iframe HTML bez rekurencji w pętli (ale spróbujemy rekurencyjne wywołanie jeśli fetch fails)
            try:
                r = requests.get(srcn, headers=HEADERS, timeout=timeout)
                r.raise_for_status()
                iframe_html = r.text

                # uruchamiamy mini-analizę na iframe_html
                # 1) playerDataUrl / mediaId w iframe
                m_params = re.search(r'var\s+params\s*=\s*\{(.+?)\};', iframe_html, re.DOTALL)
                if m_params:
                    block = m_params.group(1)
                    mid = re.search(r'mediaId\s*:\s*[\'"]?(\d+)[\'"]?', block)
                    pdu = re.search(r'playerDataUrl\s*:\s*[\'"]([^\'"]+)[\'"]', block)
                    if mid and pdu:
                        media_id = mid.group(1)
                        player_template = pdu.group(1)
                        player_url = normalize_url(player_template.replace("MEDIA_ID", media_id), srcn)
                        log(f"🧩 (iframe 2A m_params) MEDIA_ID/playerDataUrl → {player_url}")

                        try:
                            j = requests.get(player_url, headers=HEADERS, timeout=timeout).json()
                            for srcj in j.get("mediaItem", {}).get("playback", {}).get("mediaSources", []):
                                url_candidate = normalize_url(srcj.get("url"), player_url)
                                if url_candidate and "tvpuls/tvpuls.mpd" in url_candidate:
                                    url_candidate = url_candidate.replace("/tvpuls/tvpuls.mpd", "/tvpulsraw/tvpulsraw.mpd")
                                    log(f"🔧 TVPULS PATCH -> {url_candidate}")
                                if looks_like_manifest(url_candidate):
                                    if handle_mpd_candidate(url_candidate, json.dumps(j), page_url):
                                        CACHE[page_url] = {"url": url_candidate, "time": time.time()}
                                        save_cache(CACHE)
                                        return url_candidate
                                    else:
                                        return None
                        except Exception as e:
                            log(f"⚠️ (iframe) JSON playerDataUrl error: {e}")
                # 2) manifestUri / script scanning inside iframe
                soup_if = BeautifulSoup(iframe_html, "html.parser")
                # search scripts
                for s_if in soup_if.find_all("script"):
                    txt = s_if.string or s_if.get_text() or ""
                    m = re.search(r'manifestUri\s*[:=]\s*[\'"]([^\'"]+)[\'"]', txt)
                    if m:
                        cand = normalize_url(m.group(1), srcn)
                        if cand and "tvpuls/tvpuls.mpd" in cand:
                            cand = cand.replace("/tvpuls/tvpuls.mpd", "/tvpulsraw/tvpulsraw.mpd")
                            log(f"🔧 TVPULS PATCH -> {cand}")
                        log(f"🔎 (iframe) manifestUri → {cand}")
                        if handle_mpd_candidate(cand, txt, page_url):
                            CACHE[page_url] = {"url": cand, "time": time.time()}
                            save_cache(CACHE)
                            return cand
                        else:
                            return None
                    found = re.findall(r'https?://[^\s\'"<>]+?\.(?:m3u8|mpd|mp4)[^\s\'"<>]*', txt)
                    for f in found:
                        f2 = normalize_url(f, srcn)
                        log(f"🔎 (iframe) skrypt found → {f2}")
                        if looks_like_manifest(f2):
                            if handle_mpd_candidate(f2, txt, page_url):
                                CACHE[page_url] = {"url": f2, "time": time.time()}
                                save_cache(CACHE)
                                return f2
                            else:
                                return None
                # 3) regex in iframe_html
                m2 = re.search(r'https?://[^\s\'"<>]+?\.(?:m3u8|mpd|mp4)[^\s\'"<>]*', iframe_html)
                if m2:
                    cand2 = normalize_url(m2.group(0), srcn)
                    if cand2 and "tvpuls/tvpuls.mpd" in cand2:
                        cand2 = cand2.replace("/tvpuls/tvpuls.mpd", "/tvpulsraw/tvpulsraw.mpd")
                        log(f"🔧 TVPULS PATCH -> {cand2}")
                    log(f"🔗 (iframe) Bezpośredni link → {cand2}")
                    if handle_mpd_candidate(cand2, iframe_html, page_url):
                        CACHE[page_url] = {"url": cand2, "time": time.time()}
                        save_cache(CACHE)
                        return cand2
                    else:
                        return None
            except Exception as ie:
                log(f"⚠️ Błąd pobierania iframe: {ie} -- spróbuję rekurencyjnie")
                # próbujemy rekurencyjnie (może iframe wymaga innego user agentitp.)
                try:
                    result = extract_hls_from_page(srcn, timeout=timeout)
                    if result:
                        CACHE[page_url] = {"url": result, "time": time.time()}
                        save_cache(CACHE)
                        return result
                except Exception:
                    pass
                continue
    except Exception as e:
        log(f"⚠️ iframe error: {e}")

    # --- fallback: cmf3 dynamic parse if available ---
    log("❌ Nie znaleziono działającego linku - uruchamiam cmf3 fallback (jeśli jest).")
    try:
        import cmf3
        if hasattr(cmf3, "run_dynamic_parse"):
            res = cmf3.run_dynamic_parse(page_url)

            if res:
                # wybierz pierwszy manifest-like
                for r in res:
                    rr = normalize_url(r, page_url)
                    if rr and looks_like_manifest(rr):
                        log(f" Z modułu cmf3 -> wybrano: {rr}")
                        CACHE[page_url] = {"url": rr, "time": time.time()}
                        save_cache(CACHE)
                        return rr
            log("Moduł cmf3 nic nie zwrócił.")
    except Exception as e:
        log(f"⚠️ cmf3.py error: {e}")

    return None

# ---------------- play helper ----------------
def play_channel(url, name=None):
    name = params.get("name")

    try:

        handle = int(sys.argv[1])

        if any(ext in url.lower() for ext in [".mp4", ".m3u8", ".mpd"]):
           final = url
        else:
           final = extract_hls_from_page(url)

        # 🔥 KLUCZOWE
        if not final:
            final = url

        if not final:
            xbmcgui.Dialog().ok("Błąd", f"Nie znaleziono linku dla {name or url}")
            return

        li = xbmcgui.ListItem()
        li.setPath(final)

        li.setInfo("video", {"title": name or final})
        li.setProperty("IsPlayable", "true")

        # --- MP4 ---
        if ".mp4" in final:
            li.setMimeType("video/mp4")
            li.setContentLookup(False)

        # --- HLS ---
        elif ".m3u8" in final:
            li.setMimeType("application/vnd.apple.mpegurl")
            li.setContentLookup(False)

            from inputstreamhelper import Helper
            hls = Helper("hls")
            if hls.check_inputstream():
                li.setProperty("inputstream", hls.inputstream_addon)
                li.setProperty("inputstream.adaptive.manifest_type", "hls")

        # --- DASH ---
        elif ".mpd" in final:
            li.setMimeType("application/dash+xml")
            li.setContentLookup(False)

            from inputstreamhelper import Helper
            dash = Helper("mpd")
            if dash.check_inputstream():
                li.setProperty("inputstream", dash.inputstream_addon)
                li.setProperty("inputstream.adaptive.manifest_type", "mpd")

        xbmcplugin.setResolvedUrl(handle, True, li)

    except Exception as e:
        xbmcgui.Dialog().ok("Błąd odtwarzania", str(e))
# ---------------- quick test runner (when module run directly) ----------------
if __name__ == "__main__":
    xbmcgui.Dialog().notification("nowy_test", "Test uruchomiony (log w userdata)", xbmcgui.NOTIFICATION_INFO, 2000)
    # prosty test: iteruj kanały i spróbuj wyciągnąć link
    for ch in CHANNELS:
        log(f"=== TEST: {ch['name']} -> {ch['url']}")
        try:
            found = extract_hls_from_page(ch['url'])
            log(f"TEST RESULT dla {ch['name']}: {found}")
        except Exception as e:
            log(f"TEST ERROR dla {ch['name']}: {e}")
    xbmcgui.Dialog().notification("nowy_test", "Test zakończony (sprawdź log)", xbmcgui.NOTIFICATION_INFO, 2000)

CHANNELS = [

    {"name": "********  Strona megawypas  *********", "url": "https://static.videezy.com/system/protected/files/000/040/581/Poland_Flag_Loop.mp4", "icon": "https://megawypas.com/images/favicons/apple-touch-icon.png"},
    {"name": "Toya", "url": "https://megawypas.com/articles.php?article_id=12", "icon": "https://epg.ovh/logo/TOYA+TV.png"},
    {"name": "TV Puls", "url": "https://megawypas.com/articles.php?article_id=425", "icon": "https://epg.ovh/logo/TV+Puls.png"},
    {"name": "Polsat News Polityka", "url": "https://megawypas.com/articles.php?article_id=620", "icon": "https://epg.ovh/logo/Polsat+News+Polityka.png"},
    {"name": "Polsat News", "url": "https://megawypas.com/articles.php?article_id=598", "icon": "https://epg.ovh/logo/Polsat+News.png"},
    {"name": "4Fun Kids", "url": "https://megawypas.com/articles.php?article_id=631", "icon": "https://epg.ovh/logo/4FUN+KIDS.png"},
    {"name": "Car City Adventures PL", "url": "https://megawypas.com/articles.php?article_id=630", "icon": "https://epg.ovh/logo/Car+City+Adventures.png"},
    {"name": "Grjngo Westerny", "url": "https://megawypas.com/articles.php?article_id=626", "icon": "https://epg.ovh/logo/Grjngo+Westerny.png"},
    {"name": "Top Barca live", "url": "https://megawypas.com/articles.php?article_id=629", "icon": "https://www.fcbarcelona.com/resources/v3.4.5-7905/i/icons/apple-touch-icon-152x152.png"},
    {"name": "TV Asta ", "url": "https://megawypas.com/articles.php?article_id=3", "icon": ""},


    {"name": "********  Strona listatv  *********", "url": "https://static.videezy.com/system/protected/files/000/040/581/Poland_Flag_Loop.mp4", "icon": "https://listatv.pl/images/favicons/apple-touch-icon.png"},
    {"name": "Red Carpet TV", "url": "https://listatv.pl/online.php?article_id=160", "icon": "https://epg.ovh/logo/Red+Carpet+TV+HD.png"},
    {"name": "TVT", "url": "https://listatv.pl/online.php?article_id=80", "icon": ""},
    {"name": "Puls 2", "url": "https://listatv.pl/online.php?article_id=120", "icon": "https://epg.ovh/logo/Puls+2.png"},
    {"name": "Bigtime TV", "url": "https://listatv.pl/online.php?article_id=151", "icon": "https://static.wixstatic.com/media/0e69b2_179ea94dc9964fd4985e32d09bba7bd6%7Emv2.png"},
    {"name": "Rakuten TV", "url": "https://listatv.pl/online.php?article_id=153", "icon": "https://epg.ovh/logo/Rakuten+TV.png"},
    {"name": "TVS", "url": "https://listatv.pl/online.php?article_id=141", "icon": "https://epg.ovh/logo/TVS.png"},
    {"name": "TV Kujawy", "url": "https://listatv.pl/online.php?article_id=103", "icon": "https://epg.ovh/logo/TV+KUJAWY.png"},
    {"name": "TV Toruń", "url": "https://listatv.pl/online.php?article_id=79", "icon": "https://epg.ovh/logo/TV+TORUN.png"},
    {"name": "wPolsce24", "url": "https://listatv.pl/online.php?article_id=56", "icon": "https://epg.ovh/logo/WPolsce.pl.png"},
    {"name": "dlaCiebietv", "url": "https://listatv.pl/online.php?article_id=78", "icon": "https://epg.ovh/logo/dlaCiebietv.png"},
    {"name": "Music Box", "url": "https://listatv.pl/online.php?article_id=40", "icon": ""},
    {"name": "Retro TV", "url": "https://listatv.pl/online.php?article_id=71", "icon": "https://epg.ovh/logo/RETRO.png"},



    {"name": "********  Strona turbotv wolno wczytuje  *********", "url": "https://static.videezy.com/system/protected/files/000/040/581/Poland_Flag_Loop.mp4", "icon": "https://turbotv.cc/build/assets/logo-b70595ef.png"},
    {"name": "TVN 24", "url": "https://turbotv.cc/pl/live/tvn24-fhd---b7cf84c6-42e8-4867-b4cb-3d9edf6ccdb8", "icon": "http://turbotv.tv/logo/tvn24-pl.png"},
    {"name": "TVP Rozrywka", "url": "https://turbotv.cc/pl/live/tvp-rozrywka---9fa40d4c-2056-435b-9cfd-a3f8a6557776", "icon": ""},
    {"name": "TVP Sport ", "url": "https://turbotv.cc/pl/live/tvp-sport-fhd---c28f5f5d-8830-4768-9452-733a1d80646f", "icon": ""},
    {"name": "TVP Seriale ", "url": "https://turbotv.cc/pl/live/tvp-seriale-fhd---f1314272-bb13-4b53-bdee-d265a3627a8e", "icon": ""},
    {"name": "TVP Kultura ", "url": "https://turbotv.cc/pl/live/tvp-kultura---ae7f1e16-67d2-4a35-9067-cf93c5ff2b31", "icon": ""},
    {"name": "TVP abc", "url": "https://turbotv.cc/pl/live/tvp-abc---c2521c12-78db-4a08-9452-f560c4356e62", "icon": ""},
    {"name": "4FUN TV", "url": "https://turbotv.cc/pl/live/4funtv---142af590-c747-4b0c-9fd8-5776092cb6af", "icon": ""},




    {"name": "********  Inne  *********", "url": "https://static.videezy.com/system/protected/files/000/040/581/Poland_Flag_Loop.mp4", "icon": os.path.join(ADDON_PATH, "resources", "media", "tvblu.png")},
    {"name": "Echo 24", "url": "https://echo24.tv/pl/770_na-zywo", "icon": ""},
    {"name": "Toya", "url": "https://tvtoya.pl/player/live", "icon": "https://epg.ovh/logo/TOYA+TV.png"},
    {"name": "Polsat News partner", "url": "https://partner.ipla.tv/embed/XNgSz8/media/1517830/live", "icon": ""},
    {"name": "TV Biznesowa", "url": "https://telewizjabiznesowa.pl/", "icon": ""},
    {"name": "Puls 2","url": "https://edge07.cdn.emitel.pl/bpk-tv/Puls2_HD/hbbtv-dash/index.mpd","icon": "",},
    {"name": "TV Puls","url": "https://edge07.cdn.emitel.pl/bpk-tv/Puls_HD/hbbtv-dash/index.mpd","icon": "",},
    {"name": "wizja amc", "url": "https://wizja.cc/livetv/details/amc/53", "icon": ""},
##    {"name": "kanal", "url": "https://dlhd.link/stream/stream-984.php", "icon": ""},
    {"name": "wizja Eu sp 2", "url": "https://wizja.cc/livetv/details/eurosport-2/118", "icon": ""},
    {"name": "wizja", "url": "https://wizja.cc/embed/main/embed.php?kanal=62", "icon": ""},
    {"name": "wizja eurosport", "url": "https://wizja.cc/livetv/details/eurosport-1/117", "icon": ""},
    {"name": "AXN wizja", "url": "https://wizja.cc/livetv/details/axn-white/137", "icon": ""},

    {"name": "wizja AXN BLACK", "url": "https://wizja.cc/livetv/details/axn-black/136", "icon": ""},
    {"name": "wizja ", "url": "https://wizja.cc/livetv/details/tvp-abc/283", "icon": ""},


]

