# -*- coding: utf-8 -*-
"""
Prosty wrapper do wykrywania / rozpakowywania niektórych packerów JavaScript.
Jeśli masz zainstalowany zewnętrzny pakiet 'jsunpack' (lub podobny),
to zostanie wykorzystany automatycznie.
"""

import re

# próbujemy importu bardziej zaawansowanego packera, jeśli dostępny
try:
    import jsunpack as _jsunpack_impl  # jeżeli masz moduł o tej nazwie
except Exception:
    _jsunpack_impl = None

def detect_packed(text):
    """Wykrywa podstawowe patterny packera (eval(function(p,a,c,k,e,...))."""
    if not text:
        return False
    # klasyczny Dean Edwards / Eval Packer
    if re.search(r"eval\(function\(p,a,c,k,e,d\)", text):
        return True
    # inne proste markery
    if re.search(r"while\s*\(p\.replace", text):
        return True
    # fallback: użyj impl, jeśli dostępny
    try:
        if _jsunpack_impl and hasattr(_jsunpack_impl, "detect_packed"):
            return _jsunpack_impl.detect_packed(text)
    except Exception:
        pass
    return False

def unpack(text):
    """Próbuje rozpakować. Zwraca rozpakowany tekst lub oryginalny jeśli nie uda się."""
    if not text:
        return text
    # użyj implementacji, jeśli dostępna
    try:
        if _jsunpack_impl and hasattr(_jsunpack_impl, "unpack"):
            return _jsunpack_impl.unpack(text)
    except Exception:
        pass

    # prosty (ograniczony) unpack dla klasycznego eval-packer (very simple)
    # uwaga: to nie rozwiąże wszystkich przypadków, ale czasami pomaga
    m = re.search(r"(eval\(function\(p,a,c,k,e,d\).+?\)\))", text, re.DOTALL)
    if m:
        candidate = m.group(1)
        # nie wykonujemy JS w Pythonie — niebezpieczne — więc zwracamy oryginalny
        # ale pozostawiamy rozszerzalne miejsce na bardziej zaawansowane JS-unpackery
        return text  # fallback: zwracamy cały HTML, żeby pozostałe regexy dalej działały
    return text
