import xbmcgui
import xbmcplugin
import xbmc
import sys
import xbmcaddon
import xbmcvfs
import os

ADDON = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo('path')

# ===========================================
# 📺 LISTA KANAŁÓW TESTOWYCH
# ===========================================
CHANNELS = [
    {
        "name": "Big Buck Bunny (MP4)",
        "url": "https://video.blender.org/static/web-videos/6402b77c-b61f-4a06-96ca-c8420a2becf4-480.mp4",
        "icon": os.path.join(ADDON_PATH, "resources", "media", "TVP Info.png")
    },
    {
        "name": "Puls 2",
        "url": "https://edge07.cdn.emitel.pl/bpk-tv/Puls2_HD/hbbtv-dash/index.mpd",
        "icon": "",
    },
    {
        "name": "Puls (DASH)",
        "url": "https://edge07.cdn.emitel.pl/bpk-tv/Puls_HD/hbbtv-dash/index.mpd",
        "icon": "",
    },
    {
        "name": "TBN",
        "url": "https://s-pl-01.mediatool.tv/playout/tbn-abr/tracks-v2a1/mono.ts.m3u8",
        "icon": "",
    },
    {
        "name": "Polsat News Polityka TEST",
        "url": "https://cdn-s-lb2.pluscdn.pl/lv/1511888/322/dash/52a9b70b/live.mpd",
        "icon": "",
    },
    {
        "name": "Eska",
        "url": "https://s-pl-01.mediatool.tv/playout/espl-abr/tracks-v2a1/mono.ts.m3u8",
        "icon": "https://musicboxtv.pl/logo_music_box_classic.png",
    },
    {
        "name": "Eska Rock",
        "url": "https://s-pl-01.mediatool.tv/playout/erpl-abr/tracks-v2a1/mono.ts.m3u8",
        "icon": "",
    },
    {
        "name": "HiMusic",
        "url": "https://s-pl-01.mediatool.tv/playout/hmpl-abr/tracks-v1a1/mono.ts.m3u8",
        "icon": "",
    },
    {
        "name": "HiDance",
        "url": "https://s-pl-01.mediatool.tv/playout/hdpl-abr/tracks-v2a1/mono.ts.m3u8",
        "icon": "",
    },
    {
        "name": "Music Box",
        "url": "https://vs2131.vcdn.biz/435df4aef639a6650094b9123d601cf0_megogo/live/hls/b/4000/u_sid/0/o/156751011/rsid/7a90ede2-66e7-4cca-8288-a7092d16f42b/u_uid/0/u_vod/1/u_device/embed_all/u_devicekey/_embed_web/lip/31.182.189.113*asn/type.live/chunklist-sid2668540418746367916-b4000000.m3u8",
        "icon": "https://musicboxtv.pl/logo_music_box_classic.png",
    },
    {
        "name": "panorama-kina",
        "url": "https://sweet.tv/pl/free_tv/3350-panorama-kina-hd?fps=s&id=GTM-5PXXFXX",
        "icon": "",
    },
    {
        "name": "TVT",
        "url": "https://live.streamtvt.pl/LiveAppStreamTVT/streams/853271271313930867905724.m3u8",
        "icon": "",
    },

    {
        "name": "SAYHi",
        "url": "https://s-pl-01.mediatool.tv/playout/shpl-abr/tracks-v2a1/mono.ts.m3u8",
        "icon": "",
    },
    {
        "name": "Polsat News partner",
        "url": "https://partner.ipla.tv/embed/XNgSz8/media/1517830/live",
        "icon": "",
    },
    {
        "name": "imperium",
        "url": "https://91-193-208-10.eimperium.pl/TVIMPERIUM/index.m3u8",
        "icon": "",
    },

    {
        "name": "Canal",
        "url": "https://lb5-prod.purplecdn.xyz/9861-4756-5122-5754/preview.mp4",
        "icon": "",
    },
    {
        "name": "Puls",
        "url": "https://edge07.cdn.emitel.pl/bpk-tv/Puls_HD/hbbtv-dash/index.mpd",
        "icon": "",
    },
    {"name": "link", "url": "https://liveovh011.cda.pl/enc103/puls2/puls2.mpd?uid=2253542221", "icon": "https://epg.ovh/logo/TOYA+TV.png"},
    {"name": "TV 4", "url": "https://cdn-s-lb2.pluscdn.pl/ch/1502601/309/dash/e25c2c93/live.mpd?uid=2253542221", "icon": ""},
    {"name": "Polsat HD", "url" : "https://lb2-e2-19.pluscdn.pl/ch/1502600/308/dash/20a18c30/live.mpd?uid=2253542221","icon": ""},
    {"name": "Polsat Romans", "url": "http://portal.geniptv.com:8080/Besim_Redzepi2/xCW7nvIEPK/10446", "icon": ""},
    {"name": "13a", "url": "http://fr.magtr.cc:8080/4408928693025290/4408928693025290/395857", "icon": ""},

]




# ===========================================
# ▶️ FUNKCJA ODTWARZANIA
# ===========================================
def play_channel(url):
    """Uniwersalne odtwarzanie (MP4 / HLS / DASH)."""
    try:
        handle = int(sys.argv[1])
        li = xbmcgui.ListItem(path=url)
        li.setInfo("video", {"title": url})

        # --- MP4 ---
        if url.endswith(".mp4"):
            li.setMimeType("video/mp4")
            li.setContentLookup(True)

        # --- HLS ---
        elif ".m3u8" in url:
            li.setMimeType("application/vnd.apple.mpegurl")
            li.setContentLookup(False)
            try:
                from inputstreamhelper import Helper
                hls = Helper("hls")
                if hls.check_inputstream():
                    li.setProperty("inputstream", hls.inputstream_addon)
                    li.setProperty("inputstream.adaptive.manifest_type", "hls")
                    xbmc.log("[PolskieTV:channels] InputStream Adaptive (HLS) aktywny", xbmc.LOGINFO)
            except Exception as e:
                xbmc.log(f"[PolskieTV:channels] HLS error: {e}", xbmc.LOGWARNING)

        # --- DASH ---
        elif ".mpd" in url:
            li.setMimeType("application/dash+xml")
            li.setContentLookup(False)
            try:
                from inputstreamhelper import Helper
                dash = Helper("mpd")
                if dash.check_inputstream():
                    li.setProperty("inputstream", dash.inputstream_addon)
                    li.setProperty("inputstream.adaptive.manifest_type", "mpd")
                    xbmc.log("[PolskieTV:channels] InputStream Adaptive (MPD) aktywny", xbmc.LOGINFO)
            except Exception as e:
                xbmc.log(f"[PolskieTV:channels] DASH error: {e}", xbmc.LOGWARNING)

        xbmcplugin.setResolvedUrl(handle, True, li)

    except Exception as e:
        xbmc.log(f"[PolskieTV:channels] ❌ Błąd play_channel(): {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("Błąd odtwarzania", str(e))



