# -*- coding: utf-8 -*-
# mac_api_li.py

import re
import json
import time
import random
import base64
import urllib.request
import urllib.parse
import http.cookiejar
import xbmc
import xbmcaddon
import xbmcvfs
import os
import xbmcgui

import zlib
import gzip
import io
from datetime import datetime
import unicodedata

# ===============================
# KONFIGURACJA CACHE
# ===============================
VOD_CACHE_TTL = 60 * 60 * 24  # 24h
VOD_PAGE_CACHE_TTL = 60 * 60 * 2  # 2h

# =========================
# GLOBALNE SŁOWNIKI
# =========================

_sessions = {}      # portal|mac → (opener, cookiejar)
_tokens = {}        # portal|mac → token
_token_time = {}    # portal|mac → timestamp

_active_macs = {}
_active_sessions = {}
# katalog użytkownika dodatku
ADDON = xbmcaddon.Addon()
PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))

CACHE_DIR = PROFILE

VOD_CACHE_DIR = os.path.join(PROFILE, "_vod_cache")
TV_CACHE_DIR = os.path.join(PROFILE, "_tv_cache")

ADDON_ID = "plugin.video.polskatv"
SLOTS_FILE = xbmcvfs.translatePath(
    f"special://userdata/addon_data/{ADDON_ID}/slots.json"
)


ADDON_PROFILE = xbmcvfs.translatePath(
    f"special://profile/addon_data/{ADDON_ID}/"
)
_active_sessions = {}

def get_session(portal, mac, slot_index=None):
    global _active_sessions

    if slot_index is not None and slot_index in _active_sessions:
        return _active_sessions[slot_index]

    # tu tworzysz opener + handshake
    opener = ...
    token = ...

    if slot_index is not None:
        _active_sessions[slot_index] = (opener, token)

    return opener, token


def is_polish(name):
    if not name: return False
    n = name.upper().strip()
    m = re.match(r"^([A-Z]{2,3})\s*[\|\-]", n)
    if m and m.group(1) != "PL": return False
    blocked_words = ["PREMIER LEAGUE","CHELSEA","LIVE","MATCH","EVENT","STUDIO","NO SIGNAL","NO STREAM","OFFLINE","TEST","4K|" ,"VIAPLAY" ]
    if any(w in n for w in blocked_words): return False
    if re.search(r"\bPL[A-Z0-9]+", n): return False
    patterns = [r"\( *PL *\)", r"\[ *PL *\]", r"\| *PL *\|", r"\bPL\b", r"\bPOLSKI\b",
                r"\bLEKTOR *PL\b", r"\bPL *LEKTOR\b", r"\bDUB *PL\b", r"\bPL *DUB\b" ,r"POLAND",]
    return any(re.search(p, n) for p in patterns)


def save_tv_channel_cache(slot_index, genre_id, channels):
    path = _tv_channel_cache_file(slot_index, genre_id)
    if not path:
        return

    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)

        data = {
            "time": time.time(),
            "channels": channels
        }

        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)

        xbmc.log(f"[TV] Zapisano cache kanałów → {path}", xbmc.LOGINFO)

    except Exception as e:
        xbmc.log(f"[TV CACHE SAVE ERROR] {e}", xbmc.LOGERROR)

def load_tv_channel_cache(slot_index, genre_id, max_age=7200):
    path = _tv_channel_cache_file(slot_index, genre_id)
    if not path or not os.path.exists(path):
        return None

    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)

        saved_time = data.get("time", 0)
        if time.time() - saved_time > max_age:
            return None

        return data.get("channels", [])

    except Exception as e:
        xbmc.log(f"[TV CACHE LOAD ERROR] {e}", xbmc.LOGERROR)
        return None

def _tv_channel_cache_file(slot_index, genre_id):

    slot = get_slot(slot_index)
    if not slot:
        return None

    portal = slot.get("portal", "").strip().lower()
    portal = portal.replace("http://", "").replace("https://", "")
    portal = portal.rstrip("/")
    portal = portal.replace("/", "_")

    if not genre_id:
        return None   # 🔥 blokada pustych genre

    cache_dir = os.path.join(ADDON_PROFILE, "_tv_cache")
    os.makedirs(cache_dir, exist_ok=True)

    filename = f"slot_{slot_index}_genre_{genre_id}.json"

    return os.path.join(cache_dir, filename)


def load_tv_genre_cache(slot_index):
    path = _tv_kateg_cache_file(slot_index)

    if not path or not os.path.exists(path):
        return []

    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)

        return data.get("categories", [])

    except Exception as e:
        xbmc.log(f"[TV] LOAD CACHE ERROR {e}", xbmc.LOGERROR)
        return []


def get_tv_categories(slot_index):
    slot = get_slot(slot_index)
    if not slot:
        return []

    portal = slot.get("portal", "").rstrip("/") + "/"
    mac = slot.get("mac", "")

    token = do_handshake(portal, mac, force=True)
    if not token:
        xbmc.log("[TV] Brak tokena", xbmc.LOGERROR)
        return []

    categories = []

    def try_request(url):
        try:
            raw = mag_request(url, mac, portal, token)
            if not raw:
                return None
            return json.loads(raw)
        except:
            return None

    # 1️⃣ NAJLEPSZE
    url = portal + "portal.php?type=itv&action=get_genre_id_map&JsHttpRequest=1-xml"
    data = try_request(url)

    if data and isinstance(data.get("js"), dict):
        genres = data.get("js", {})
        categories = [{"id": k, "title": v} for k, v in genres.items()]
        xbmc.log("[TV] get_genre_id_map OK", xbmc.LOGINFO)

    # 2️⃣ get_categories
    if not categories:
        url = portal + "portal.php?type=itv&action=get_categories&JsHttpRequest=1-xml"
        data = try_request(url)

        if data and isinstance(data.get("js"), list):
            categories = data.get("js", [])
            xbmc.log("[TV] get_categories OK", xbmc.LOGINFO)

    # 3️⃣ get_genres
    if not categories:
        url = portal + "portal.php?type=itv&action=get_genres&JsHttpRequest=1-xml"
        data = try_request(url)

        if data and isinstance(data.get("js"), list):
            categories = data.get("js", [])
            xbmc.log("[TV] get_genres OK", xbmc.LOGINFO)

    # 4️⃣ fallback (ciężki)
    if not categories:
        xbmc.log("[TV] FALLBACK get_all_channels", xbmc.LOGWARNING)

        url = portal + "portal.php?type=itv&action=get_all_channels&JsHttpRequest=1-xml"
        data = try_request(url)

        if data:
            if isinstance(data.get("js"), dict):
                channels = data.get("js", {}).get("data", [])
            elif isinstance(data.get("js"), list):
                channels = data.get("js")
            else:
                channels = []

            genre_map = {}
            for ch in channels:
                gid = str(ch.get("genre_id"))
                title = ch.get("genre_title", gid)
                if gid not in genre_map:
                    genre_map[gid] = title

            categories = [{"id": k, "title": v} for k, v in genre_map.items()]

    if not categories:
        xbmc.log("[TV] categories EMPTY", xbmc.LOGERROR)

    return categories

def strip_symbols(text):
    if not text:
        return ""
    return "".join(ch for ch in text if not unicodedata.category(ch).startswith(("So", "Sk", "Cs"))).strip()
def add_slot():

    raw_input = xbmcgui.Dialog().input(
        "Podaj portal i/lub MAC Możesz wkleić razem:nportal MAC"
    )

    if not raw_input:
        return

    lines = [l.strip() for l in raw_input.splitlines() if l.strip()]

    portal = None
    mac_list = []

    # ==========================
    # 1️⃣ WYKRYCIE PORTAL + MAC
    # ==========================
    if len(lines) >= 2:
        portal_candidate = lines[0]
        mac_candidate = "\n".join(lines[1:])
        mac_list = normalize_mac_list(mac_candidate)

        if mac_list:
            portal = portal_candidate

    # ==========================
    # 2️⃣ JEŚLI TYLKO PORTAL
    # ==========================
    if not portal:
        portal = lines[0]

        raw_mac = xbmcgui.Dialog().input(
            "Podaj adres MAC (można wkleić wiele, oddziel przecinkiem lub enterem)"
        )

        mac_list = normalize_mac_list(raw_mac)

        if not mac_list:
            xbmcgui.Dialog().notification("MAC", "Niepoprawny format MAC")
            return

    # ==========================
    # 3️⃣ NORMALIZACJA PORTALU
    # ==========================
    portal = portal.strip().rstrip("/")

    if portal.endswith("/c"):
        base_portal = portal[:-2]
    else:
        base_portal = portal

    portal_variants = [
        base_portal + "/",
        base_portal + "/c/"
    ]

    # ==========================
    # 4️⃣ TEST TYLKO 1 MAC (pierwszy)
    # ==========================
    test_mac = mac_list[0]
    working_portals = []

    for p in portal_variants:

        xbmcgui.Dialog().notification(
            "TEST PORTALU",
            f"Sprawdzam:{p}",
            xbmcgui.NOTIFICATION_INFO,
            2500
        )
        result, error = test_mac_speed(p, test_mac)

        if result:
            working_portals.append(p)

    # ==========================
    # 5️⃣ JEŚLI NIC NIE DZIAŁA
    # ==========================
    if not working_portals:
        xbmcgui.Dialog().notification(
            "Portal",
            "Żaden wariant nie działa",
            xbmcgui.NOTIFICATION_ERROR,
            4000
        )
        return

    # ==========================
    # 6️⃣ ZAPIS TYLKO DZIAŁAJĄCYCH
    # ==========================
    slots = load_slots()

    for p in working_portals:
        slots.append({
            "portal": p,
            "mac": "\n".join(mac_list)
        })

    save_slots(slots)

    xbmcgui.Dialog().notification(
        "Portal",
        f"Zapisano {len(working_portals)} działających wariantów ,potem usuń niepotrzebny wariant",
        xbmcgui.NOTIFICATION_INFO,
        3000
    )

    xbmc.executebuiltin("Container.Refresh")


def save_portal_debug(slot_index, raw_response, prefix="fail"):

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"{prefix}_slot{slot_index}_{timestamp}.txt"
    path = os.path.join(ADDON_CACHE_DIR, filename)

    try:
        with open(path, "w", encoding="utf-8") as f:
            f.write(raw_response if isinstance(raw_response, str) else json.dumps(raw_response, indent=2))

        xbmc.log(f"[MAC DEBUG] saved → {path}", xbmc.LOGINFO)

    except Exception as e:
        xbmc.log(f"[MAC DEBUG] SAVE ERROR {e}", xbmc.LOGERROR)



# ===============================
# POMOCNICZE
# ===============================
def _safe_id(text):
    return re.sub(r'[^A-Za-z0-9_]', '_', text)

def valid_mac(mac):
    pattern = r"^([0-9A-Fa-f]{2}:){5}([0-9A-Fa-f]{2})$"
    return re.match(pattern, mac)


def get_account_info(portal, mac):
    token = do_handshake(portal, mac)

    if not token:
        return None

    url = f"{portal}portal.php?type=stb&action=get_profile&JsHttpRequest=1-xml"

    data = mag_request(url, mac, portal, token)

    xbmc.log(f"[MAC] ACCOUNT RAW {data}", xbmc.LOGINFO)

    try:
        if isinstance(data, str):
            data = json.loads(data)

        return data.get("js", {})

    except Exception as e:
        xbmc.log(f"[MAC] ACCOUNT PARSE ERROR {e}", xbmc.LOGERROR)
        return None

def usun_cache():

    dirs = [TV_CACHE_DIR, VOD_CACHE_DIR]

    removed = 0

    for d in dirs:

        if not os.path.exists(d):
            continue

        for f in os.listdir(d):

            if not f.endswith(".json"):
                continue

            path = os.path.join(d, f)

            try:
                os.remove(path)
                removed += 1
            except:
                pass

    xbmc.log(f"[MAC] CACHE REMOVED {removed}", xbmc.LOGINFO)

    xbmcgui.Dialog().notification(
        "PolskaTV",
        f"Usunięto plików cache: {removed}"
    )

def show_account_info(portal, mac):

    info = get_account_info(portal, mac)

    if not info:
        xbmcgui.Dialog().notification("Informacje", "Brak danych z portalu")
        return

    labels = {

        # --- PODSTAWOWE ---
        "client_type": "Typ klienta",
        "name": "Nazwa urządzenia",
        "stb_type": "Typ STB",
        "default_timezone": "Strefa czasowa",

        # --- KONTO ---
        "expire_billing_date": "Data wygaśnięcia konta",
        "account_balance": "Saldo konta",
        "blocked": "Konto zablokowane",

        # --- ODTWARZANIE ---
        "playback_limit": "Limit jednoczesnych odtworzeń",
        "watchdog_timeout": "Watchdog (timeout)",
        "hls_fast_start": "Szybki start HLS",
        "tv_channel_default_aspect": "Domyślny format obrazu",

        # --- NAPISY / AUDIO ---
        "always_enabled_subtitles": "Napisy zawsze włączone",
        "pri_audio_lang": "Główny język audio",
        "pri_subtitle_lang": "Główny język napisów",

        # --- NAGRYWANIE / ARCHIWUM ---
        "max_local_recordings": "Maks. lokalnych nagrań",
        "ts_max_length": "Maksymalna długość Timeshift",

        # --- SYSTEM ---
        "enable_connection_problem_indication": "Sygnalizacja problemów z połączeniem",
        "enable_buffering_indication": "Wskaźnik buforowania",
        "enable_stream_error_logging": "Logowanie błędów streamu",

        # --- OSTATNIA AKTYWNOŚĆ ---
        "last_start": "Ostatnie uruchomienie",
        "last_active": "Ostatnia aktywność",
        "created": "Data utworzenia konta"
    }

    text = []

##    text.append("=== INFORMACJE O KONCIE / PORTALU ===\n")

    for key, label in labels.items():

        value = info.get(key)

        if value in [None, "", "0000-00-00 00:00:00"]:
            continue

        # zamiana 0/1 na TAK/NIE
        if value in ["0", 0, False]:
            value = "NIE"
        elif value in ["1", 1, True]:
            value = "TAK"

        text.append(f"{label}: {value}")

    xbmcgui.Dialog().textviewer(
        "Informacje o koncie *** "+portal,
        "\n".join(text)
    )
def normalize_mac_list(raw_input):
    if not raw_input:
        return []
    parts = re.split(r"[,\n;\s]+", raw_input)
    macs = []
    for part in parts:
        clean = part.strip().upper()
        clean = re.sub(r"[^0-9A-F]", "", clean)
        if len(clean) != 12:
            continue
        formatted = ":".join(clean[i:i+2] for i in range(0, 12, 2))
        macs.append(formatted)
    macs = list(dict.fromkeys(macs))
    return macs

# ===============================
# SLOTS / MAC
# ===============================
def delete_slot():
    slots = load_slots()
    if not slots:
        xbmcgui.Dialog().notification("Sloty", "Brak zapisanych portali")
        return

    labels = [f"{s['portal']}" for s in slots]

    # 🔥 wybór wielu pozycji
    selected = xbmcgui.Dialog().multiselect("Usuń sloty", labels)

    if not selected:
        return

    # 🔥 usuwamy od końca żeby indeksy się nie przesuwały
    for idx in sorted(selected, reverse=True):
        slots.pop(idx)

    save_slots(slots)

    xbmcgui.Dialog().notification("Sloty", "Usunięto zaznaczone portale")
    xbmc.executebuiltin("Container.Refresh")
def load_slots():
    if not os.path.exists(SLOTS_FILE):
        with open(SLOTS_FILE, "w", encoding="utf-8") as f:
            json.dump([], f)
        return []
    with open(SLOTS_FILE, "r", encoding="utf-8") as f:
        return json.load(f)

def save_slots(slots):
    try:
        with open(SLOTS_FILE, "w", encoding="utf-8") as f:
            json.dump(slots, f, indent=2)
    except Exception as e:
        xbmc.log("[MAC_API] SAVE ERROR " + str(e), xbmc.LOGERROR)

def get_slot(slot_index):
    slots = load_slots()
    if slot_index >= len(slots):
        return None
    slot = dict(slots[slot_index])
    mac_raw = slot.get("mac", "")
    if isinstance(mac_raw, list):
        mac_list = [m.strip() for m in mac_raw if m.strip()]
        mac = mac_list[0] if mac_list else ""
    else:
        mac_list = [m.strip() for m in mac_raw.splitlines() if m.strip()]
        mac = mac_list[0] if mac_list else ""
    slot["mac"] = mac
    return slot

def resolve_slot_mac(slot_index):
    slots = load_slots()
    if slot_index >= len(slots):
        return None
##    slot = slots[slot_index]
    slot = dict(slots[slot_index])
    mac_raw = slot.get("mac", "")
    if isinstance(mac_raw, list):
        mac_list = [m.strip() for m in mac_raw if m.strip()]
    else:
        mac_list = [m.strip() for m in mac_raw.splitlines() if m.strip()]
    mac_list = list(dict.fromkeys(mac_list))
    if not mac_list:
        return None
    selected_mac = mac_list[0]
    _active_macs[slot_index] = selected_mac
    set_active_mac(slot_index, selected_mac)
    return slot

def set_active_mac(slot_index, chosen_mac):
    slots = load_slots()
    if slot_index >= len(slots):
        return
    macs = slots[slot_index].get("mac", [])
    if isinstance(macs, str):
        macs = [m.strip() for m in macs.splitlines() if m.strip()]
    if chosen_mac in macs:
        macs.remove(chosen_mac)
    macs.insert(0, chosen_mac)
    slots[slot_index]["mac"] = macs
    _active_macs[slot_index] = chosen_mac
    save_slots(slots)


# =========================
# SESJA HTTP / COOKIE
# =========================
def get_session(portal, mac, force_new=False):
    """Tworzy lub zwraca sesję HTTP dla danego portalu i MAC."""
    key = f"{portal}|{mac}"
    if not force_new and key in _sessions:
        return _sessions[key]
    cj = http.cookiejar.CookieJar()
    opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(cj))
    _sessions[key] = (opener, cj)
    xbmc.log(f"[MAC] NEW SESSION {portal}", xbmc.LOGINFO)
    return _sessions[key]

# REQUEST DO PORTALU
# =========================
def mag_request(url, mac, portal, token=None, referer=None, return_code=False, opener=None):

    if not opener:
        opener, _ = get_session(portal, mac)

    req = urllib.request.Request(url)
    host = urllib.parse.urlparse(portal).netloc

    # NAGŁÓWKI
##    req.add_header("Host", host)   ################################################# do spr
    req.add_header("User-Agent","Mozilla/5.0 (QtEmbedded; U; Linux; C) MAG254")
    req.add_header("X-User-Agent", "Model: MAG254; Link: WiFi")
    req.add_header("Accept", "*/*")
    req.add_header("Accept-Language", "en-US,en;q=0.9")
##    req.add_header("Accept-Encoding", "gzip, deflate") ## dawna
    req.add_header("Accept-Encoding", "gzip")
##    req.add_header("Connection", "Keep-Alive")    ####  nowa
    req.add_header("Connection", "close")

    mac_encoded = urllib.parse.quote(mac)
    req.add_header("Cookie", f"mac={mac_encoded}; stb_lang=en; timezone=Europe/Warsaw")
    if token:
        req.add_header("Authorization", f"Bearer {token}")
    if referer:
        req.add_header("Referer", referer)

    start = time.time()
    profile = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    fail_file = os.path.join(profile, "tv_cache", "fails.json")

    raw_response = ""
    code_response = 0
    resp_headers = {}

    for attempt in range(2):

        try:
            resp = opener.open(req, timeout=10)
            code_response = resp.getcode()
            raw_bytes = resp.read() or b""
            resp_headers = {k: v for k, v in resp.headers.items()}

            # dekompresja gzip
            if "gzip" in resp.headers.get("Content-Encoding", ""):
                buf = io.BytesIO(raw_bytes)
                raw_bytes = gzip.GzipFile(fileobj=buf).read()

            raw_response = raw_bytes.decode("utf-8", "ignore")
            elapsed = round(time.time() - start, 2)
            xbmc.log(f"[MAC] HTTP {code_response} TIME {elapsed}s", xbmc.LOGINFO)

            # filtr HTML lub pusty response (częsty Cloudflare/nginx)
##            if not raw_response.strip():
            if len(raw_bytes) == 0:
                xbmc.log("[MAC] EMPTY RESPONSE", xbmc.LOGWARNING)
                return ("", code_response) if return_code else ""

            return (raw_response, code_response) if return_code else raw_response

        except Exception as e:
            if attempt == 0:
                xbmc.sleep(200)
                continue
            # zapis fail do zbiorczego pliku
            snippet = raw_response[:2000] if raw_response else "<empty>"
            fail_entry = {
                "timestamp": int(time.time()),
                "url": url,
                "portal": portal,
                "mac": mac,
                "code": code_response,
                "headers": resp_headers,
                "response_snippet": snippet,
                "error": str(e)
            }

            # odczyt istniejącego pliku fail
            try:
                if os.path.exists(fail_file):
                    with open(fail_file, "r", encoding="utf-8") as f:
                        fails = json.load(f)
                else:
                    fails = []
            except:
                fails = []

            # dodajemy tylko nowe entry (unikalne po url i mac)
            if not any(f["url"] == url and f["mac"] == mac for f in fails):
                fails.append(fail_entry)

            # zapis do pliku
            try:
                os.makedirs(os.path.dirname(fail_file), exist_ok=True)
                with open(fail_file, "w", encoding="utf-8") as f:
                    json.dump(fails, f, ensure_ascii=False, indent=2)
            except Exception as save_err:
                xbmc.log(f"[MAC] FAIL SAVE ERROR {save_err}", xbmc.LOGERROR)

            return ("", code_response) if return_code else ""


# HANDSHAKE / TOKEN
# =========================
def do_handshake(portal, mac, force=False):
    key = f"{portal}|{mac}"
    if not force and key in _tokens:
        if time.time() - _token_time.get(key, 0) < 300:
            return _tokens[key]

    url = f"{portal}portal.php?type=stb&action=handshake&JsHttpRequest=1-xml"

    # zawsze używamy tej samej sesji (opener)
    opener, _ = get_session(portal, mac, force_new=True)

    # nagłówki dla lepszej kompatybilności
    headers = {
        "Host": urllib.parse.urlparse(portal).netloc,
        "User-Agent": "Mozilla/5.0 (QtEmbedded; U; Linux; C) MAG254",
        "X-User-Agent": "Model: MAG254; Link: WiFi",
        "Accept": "*/*",
        "Accept-Language": "en-US,en;q=0.9",
        "Accept-Encoding": "gzip, deflate",
        "Connection": "Keep-Alive",
        "TE": "trailers",
        "Cookie": f"mac={mac}; stb_lang=en; timezone=Europe/Warsaw"
    }

    req = urllib.request.Request(url, headers=headers)

    try:
        resp = opener.open(req, timeout=10)
        raw = resp.read()
        # rozpakowanie gzip jeśli odpowiedź serwera
        if resp.info().get('Content-Encoding') == 'gzip':
            buf = io.BytesIO(raw)
            raw = gzip.GzipFile(fileobj=buf).read()
        raw = raw.decode("utf-8", "ignore")

        # bezpieczne pobranie tokena
        data = json.loads(raw)
        token = data.get("js", {}).get("token")
        if not token:
            raise ValueError("TOKEN EMPTY")

        _tokens[key] = token
        _token_time[key] = time.time()

        # fetch profile dla niektórych portali (bez czytania odpowiedzi)
        profile_url = f"{portal}portal.php?type=stb&action=get_profile&JsHttpRequest=1-xml"
        profile_req = urllib.request.Request(profile_url, headers=headers)
        try:
            opener.open(profile_req, timeout=5)
        except:
            pass  # ignorujemy ewentualne błędy przy profilu

        xbmc.log(f"[MAC] TOKEN OK {mac}", xbmc.LOGINFO)
        return token

    except Exception as e:
        xbmc.log(f"[MAC] HANDSHAKE FAIL {e}", xbmc.LOGERROR)
        return None
# ===============================
# CACHE TV / VOD
# ===============================
def _tv_cache_file(slot_index):

    slot = get_slot(slot_index)

    portal = slot.get("portal","").rstrip("/")

    unique = f"{slot_index}_{portal}"

    safe = _safe_id(unique)

    return os.path.join(TV_CACHE_DIR, f"tv_cache_{safe}.json")

def _tv_kateg_cache_file(slot_index):

    slot = get_slot(slot_index)
    if not slot:
        return None

    cache_dir = os.path.join(ADDON_PROFILE, "_tv_cache")
    os.makedirs(cache_dir, exist_ok=True)
    mac = slot.get("mac", "").replace(":", "")  # usuwamy dwukropki, żeby nazwa była poprawna
##    filename = f"slot_{slot_index}_categories.json"
    filename = f"slot_{slot_index}_{mac}_categories.json"
    return os.path.join(cache_dir, filename)
def load_tv_kateg_cache(slot_index):
    path = _tv_kateg_cache_file(slot_index)

    if not os.path.exists(path):
        xbmc.log("[TV] Brak pliku kategorii", xbmc.LOGWARNING)
        return []

    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)

        return data.get("categories", [])

    except Exception as e:
        xbmc.log(f"[TV] LOAD ERROR {e}", xbmc.LOGERROR)
        return []


def save_tv_categories(slot_index):
    categories = get_tv_categories(slot_index)

    if not categories:
        xbmc.log("[TV] Brak kategorii do zapisu", xbmc.LOGWARNING)
        return 0

    path = _tv_kateg_cache_file(slot_index)

    try:
        os.makedirs(TV_CACHE_DIR, exist_ok=True)

        data = {
            "time": time.time(),
            "categories": categories
        }

        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)

        xbmc.log(f"[TV] Kategorie zapisane → {path}", xbmc.LOGINFO)
        return len(categories)

    except Exception as e:
        xbmc.log(f"[TV] SAVE ERROR {e}", xbmc.LOGERROR)
        return 0
def get_channels_by_genre(slot_index, genre_id, max_pages=50):
    """
    Pobiera wszystkie kanały dla danej kategorii TV (łącznie wszystkie strony),
    ale zapisuje cache jako jedną stronę z pełną listą.
    """

    # 🔹 1️⃣ Sprawdź cache
    cached = load_tv_channel_cache(slot_index, genre_id)
    if cached is not None:
        xbmc.log(f"[TV CACHE] Używam cache dla genre {genre_id}", xbmc.LOGINFO)
        return cached

    slot = get_slot(slot_index)
    if not slot:
        return []

    portal = slot.get("portal", "").rstrip("/") + "/"
    mac = slot.get("mac", "")

    token = do_handshake(portal, mac)
    if not token:
        return []

    all_channels = []

    # 🔹 2️⃣ Pobierz wszystkie strony
    page = 1
    while page <= max_pages:
        url = (
            portal +
            f"portal.php?type=itv&action=get_ordered_list"
            f"&genre={genre_id}&p={page}&JsHttpRequest=1-xml"
        )

        raw = mag_request(url, mac, portal, token)
        if not raw:
            break

        try:
            data = json.loads(raw)
            channels = []
            if isinstance(data.get("js"), dict):
                channels = data["js"].get("data", [])
            elif isinstance(data.get("js"), list):
                channels = data["js"]
            else:
                channels = []

            if not channels:
                break

            all_channels.extend(channels)
            page += 1

        except Exception as e:
            xbmc.log(f"[TV PARSE ERROR] {e}", xbmc.LOGERROR)
            break

    # 🔹 3️⃣ Zapisz cache jako jedną stronę
    if all_channels:
        minimal = []
        for ch in all_channels:
            minimal.append({
                "name": ch.get("name"),
                "cmd": ch.get("cmd"),
                "logo": ch.get("logo"),
                "number": ch.get("number")
            })
        save_tv_channel_cache(slot_index, genre_id, minimal)

    xbmc.log(f"[TV] Pobrano {len(all_channels)} kanałów dla genre {genre_id}", xbmc.LOGINFO)
    return all_channels

def get_tv_genres(slot_index):

    slot = get_slot(slot_index)
    if not slot:
        return []

    portal = slot["portal"].rstrip("/") + "/"
    mac = slot["mac"]

    token = do_handshake(portal, mac)

    url = f"{portal}portal.php?type=itv&action=get_genres&JsHttpRequest=1-xml"

    raw = mag_request(url, mac, portal, token)

    try:
        if not raw.strip() or raw.strip()[0] != '{':
            xbmc.log("[MAC] PUSTY LUB NIEJSON RESPONSE, pomijam", xbmc.LOGWARNING)
            return None
        data = json.loads(raw)
        return data.get("js", [])
    except:
        return []

# ===============================
# LIVE TV
# ===============================
def get_channels_by_category(slot_index, cat_id=None):
    """
    Zwraca listę kanałów tylko dla danej kategorii.
    Jeżeli cat_id=None, zwraca wszystkie kategorie główne.
    """

    # 🔹 Załaduj cały cache kanałów (z portalu / cache)
    all_channels = load_tv_cache(slot_index)
    if not all_channels:
        all_channels = get_channels(slot_index) or []

    # 🔹 Przyspieszone filtrowanie per category
    if cat_id is None or cat_id == "ALL":
        filtered = all_channels
    elif cat_id == "PL":
        filtered = [i for i in all_channels if is_polish(i.get("name", ""))]
    else:
        filtered = [i for i in all_channels if str(i.get("genre_id")) == str(cat_id)]

    # 🔹 Posortuj szybko po nazwie
    for i in filtered:
        name_clean = strip_symbols(i.get("name", "")).strip()
        starts_digit = name_clean[0].isdigit() if name_clean else True
        i["_sort_key"] = (starts_digit, name_clean.upper())

    filtered.sort(key=lambda x: x["_sort_key"])

    return filtered

def get_channels(slot_index):
    cached = load_tv_cache(slot_index)
    if cached:
        return cached
    xbmc.log("[MAC] downloading channel list from portal", xbmc.LOGINFO)
    slot = get_slot(slot_index)
    if not slot:
        return []
    portal = slot["portal"].rstrip("/") + "/"
    mac = slot["mac"]
    token = do_handshake(portal, mac)
##    url = f"{portal}portal.php?type=itv&action=get_all_channels&JsHttpRequest=1-xml"
    url = (
        f"{portal}portal.php"
        f"?type=itv"                  # ważne: portal wymaga typu
        f"&action=get_all_channels"   # lista kanałów
        f"&JsHttpRequest=1-xml"       # konieczne dla większości portali
    )



    raw = mag_request(url, mac, portal, token)

    # 🔁 retry jeśli portal zwróci pustą odpowiedź
    if not raw:
        xbmc.log("[MAC] CHANNEL RETRY", xbmc.LOGINFO)

##        token = do_handshake(portal, mac, force=True)

##        url = f"{portal}portal.php?type=itv&action=get_all_channels&JsHttpRequest=1-xml"
        url = (
            f"{portal}portal.php"
            f"?type=itv"                  # ważne: portal wymaga typu
            f"&action=get_all_channels"   # lista kanałów
            f"&JsHttpRequest=1-xml"       # konieczne dla większości portali
        )


        raw = mag_request(url, mac, portal, token)

    try:
        if not raw.strip() or raw.strip()[0] != '{':
            xbmc.log("[MAC] PUSTY LUB NIEJSON RESPONSE, pomijam", xbmc.LOGWARNING)
            return None


        data = json.loads(raw)
        channels = data.get("js", {}).get("data", [])
        slim = []
        for ch in channels:
            slim.append({
##                "id": ch.get("id"),
##                "number": ch.get("number"),
                "name": ch.get("name"),
                "cmd": ch.get("cmd"),
##                "logo": ch.get("logo"),
##                "tmp": ch.get("tmp"),
                "genre_id": ch.get("tv_genre_id")
            })
        save_tv_cache(slim, slot_index)
        return slim
    except Exception as e:
        xbmc.log(f"[MAC] get_channels parse error {e}", xbmc.LOGERROR)
        return []


# ===============================
# VOD
# ===============================

def _vod_cache_file(slot_index):
    slot = get_slot(slot_index)
    portal = slot.get("portal", "")
    mac = slot.get("mac", "")
    unique = f"{slot_index}_{portal}_{mac}"
    safe = _safe_id(unique)
    return os.path.join(VOD_CACHE_DIR, f"vod_cache_{safe}.json")

def _vod_kateg_cache_file(slot_index):
    slot = get_slot(slot_index)
    portal = slot.get("portal", "")
    mac = slot.get("mac", "")
    unique = f"{slot_index}_{portal}_{mac}"
    safe = _safe_id(unique)
    return os.path.join(VOD_CACHE_DIR, f"vod_kateg_{safe}.json")

def _vod_page_cache_file(slot_index, category_id, page):
    slot = get_slot(slot_index)
    portal = slot.get("portal", "")
    mac = slot.get("mac", "")

    unique = f"{slot_index}_{portal}_{mac}_{category_id}_{page}"
    safe = _safe_id(unique)

    return os.path.join(VOD_CACHE_DIR, f"{slot_index}_vod_page_{safe}.json")

def load_vod_kateg_cache(slot_index):
    path = _vod_kateg_cache_file(slot_index)

    if not os.path.exists(path):
        return []

    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)

        # jeśli stary format (bez time) — ignoruj cache
        if not isinstance(data, dict) or "time" not in data:
            return []

        # sprawdź TTL
        if (time.time() - data.get("time", 0)) > VOD_CACHE_TTL:
            xbmc.log("[MAC] VOD cache expired", xbmc.LOGINFO)
            return []

        xbmc.log("[MAC] VOD cache valid", xbmc.LOGINFO)
        return data.get("categories", [])

    except Exception as e:
        xbmc.log(f"[MAC] VOD cache load error {e}", xbmc.LOGERROR)
        return []

def save_vod_kateg_cache(slot_index, categories):
    path = _vod_kateg_cache_file(slot_index)
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)

        data = {
            "version": "1",
            "time": time.time(),
            "categories": categories
        }

        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, separators=(',', ':'))

        xbmc.log("[MAC] VOD cache saved", xbmc.LOGINFO)

    except Exception as e:
        xbmc.log(f"[MAC] VOD cache save error {e}", xbmc.LOGERROR)

def load_vod_page_cache(slot_index, category_id, page):

    cache_file = os.path.join(
        ADDON_PROFILE,
        "_vod_cache",
        f"slot{slot_index}_cat_{category_id}.json"
    )

    if not xbmcvfs.exists(cache_file):
        return None

    try:
        with xbmcvfs.File(cache_file) as f:
            data = json.load(f)

        page_data = data.get("pages", {}).get(str(page))

        if not page_data:
            return None

        return page_data

    except Exception as e:
        xbmc.log(f"[MAC] CACHE LOAD ERROR {e}", xbmc.LOGERROR)
        return None

def save_vod_page_cache(slot_index, category_id, page, items, total, page_size):

    path = _vod_page_cache_file(slot_index, category_id, page)

    try:

        # jeśli brak elementów – nie zapisuj pustego cache
        if not items:
            xbmc.log(f"[MAC] VOD PAGE CACHE EMPTY - SKIP {category_id} p{page}", xbmc.LOGINFO)
            return

        os.makedirs(os.path.dirname(path), exist_ok=True)

        data = {
            "time": time.time(),
            "items": items,
            "total": total,
            "page_size": page_size
        }

        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        xbmc.log(f"[MAC] VOD PAGE CACHE SAVED {category_id} p{page}", xbmc.LOGINFO)

    except Exception as e:

        xbmc.log(f"[MAC] VOD PAGE CACHE SAVE ERROR {e}", xbmc.LOGERROR)


def get_categories(slot_index, content_type="vod"):

    if content_type == "vod":
        cached = load_vod_kateg_cache(slot_index)
        if cached:
            xbmc.log("[MAC] VOD categories loaded from cache", xbmc.LOGINFO)
            return cached

    slot = get_slot(slot_index)
    if not slot:
        return []

    portal = slot["portal"].rstrip("/") + "/"
    mac = slot["mac"]

    # 🔥 DODAJ HANDSHAKE
    token = do_handshake(portal, mac)

    url = f"{portal}portal.php?type={content_type}&action=get_categories&JsHttpRequest=1-xml"

    raw = mag_request(url, mac, portal, token)

    try:
        if not raw.strip() or raw.strip()[0] != '{':
            xbmc.log("[MAC] PUSTY LUB NIEJSON RESPONSE, pomijam", xbmc.LOGWARNING)
            return None

        data = json.loads(raw)
        categories = data.get("js", [])

        if content_type == "vod" and categories:
            save_vod_kateg_cache(slot_index, categories)

        return categories

    except Exception as e:
        xbmc.log(f"[MAC] get_categories parse error {e}", xbmc.LOGERROR)
        return []
def get_vod_list(slot_index, category_id, max_pages=50):
    slot = get_slot(slot_index)
    if not slot:
        return []
    portal = slot["portal"].rstrip("/") + "/"
    mac = slot["mac"]
    token = do_handshake(portal, mac)
    if not token:
        xbmc.log("[MAC] No token for VOD", xbmc.LOGERROR)
        return []
    all_items = []
    page = 1
    while page <= max_pages:
        url = (f"{portal}portal.php?type=vod&action=get_ordered_list"
               f"&genre={category_id}&p={page}&JsHttpRequest=1-xml")
        raw = mag_request(url, mac, portal, token, referer=portal + "c/")
        if not raw:
            break
        try:
            if not raw.strip() or raw.strip()[0] != '{':
                xbmc.log("[MAC] PUSTY LUB NIEJSON RESPONSE, pomijam", xbmc.LOGWARNING)
                return None
            data = json.loads(raw)
            items = data.get("js", {}).get("data", [])
        except Exception as e:
            xbmc.log(f"[MAC] VOD parse error {e}", xbmc.LOGERROR)
            break
        if not items:
            xbmc.log(f"[MAC] VOD end at page {page}", xbmc.LOGINFO)
            break
        for it in items:
            all_items.append({
                "id": it.get("id"),
                "name": it.get("name"),
                "description": it.get("description"),
                "cmd": it.get("cmd"),
                "screenshot_uri": it.get("screenshot_uri"),
                "poster": it.get("poster"),
                "year": it.get("year"),
                "actors": it.get("actors"),
                "director": it.get("director"),
                "category_id": category_id
            })
        page += 1
    xbmc.log(f"[MAC] VOD TOTAL = {len(all_items)}", xbmc.LOGINFO)
    return all_items

def get_vod_page(slot_index, category_id, page=1):

    # 🔥 1. CACHE CHECK
    cached = load_vod_page_cache(slot_index, category_id, page)
    if cached:
        return (
            cached.get("items", []),
            cached.get("total", 0),
            cached.get("page_size", 0)
        )

    # 🔥 2. NORMALNE POBRANIE
    slot = get_slot(slot_index)
    if not slot:
        return [], 0, 0

    portal = slot["portal"].rstrip("/") + "/"
    mac = slot["mac"]

    token = do_handshake(portal, mac)
    if not token:
        return [], 0, 0

    url = (
        f"{portal}portal.php?type=vod&action=get_ordered_list"
        f"&genre={category_id}&p={page}&JsHttpRequest=1-xml"
    )

    raw = mag_request(url, mac, portal, token, referer=portal + "c/")
    if not raw:
        return [], 0, 0

    try:
        data = json.loads(raw)
        js = data.get("js", {})
        items = js.get("data", [])
        total = int(js.get("total_items", 0))
    except Exception as e:
        xbmc.log(f"[MAC] VOD PAGE parse error {e}", xbmc.LOGERROR)
        return [], 0, 0

    result = []
    for it in items:
        result.append({
            "id": it.get("id"),
            "name": it.get("name"),
            "description": it.get("description"),
            "cmd": it.get("cmd"),
            "screenshot_uri": it.get("screenshot_uri"),
            "poster": it.get("poster"),
            "year": it.get("year"),
            "actors": it.get("actors"),
            "director": it.get("director"),
            "category_id": category_id
        })

    page_size = len(result)

    # 🔥 3. ZAPIS CACHE
    save_vod_page_cache(slot_index, category_id, page, result, total, page_size)

    return result, total, page_size

# RESOLVE STREAM
# =========================

def get_stream_url(cmd, slot_index=0, content_type="itv"):
    """
    Stabilny resolve stream dla LIVE / VOD:
    - direct m3u8
    - create_link (z retry token)
    - play
    - get_link
    - live rewrite (ostatni fallback)
    """

    original_cmd = urllib.parse.unquote(cmd or "").strip()

    if original_cmd.startswith("ffmpeg "):
        original_cmd = original_cmd.split(" ", 1)[1].strip()

    # 🔥 LIVE.PHP – nie ruszamy
    if "live.php" in original_cmd and "stream=" in original_cmd:
        xbmc.log("[MAC] USING DIRECT LIVE.PHP LINK", xbmc.LOGINFO)
        return original_cmd

    slot = get_slot(slot_index)
    if not slot:
        return None

    portal = slot["portal"].rstrip("/") + "/"
    mac = slot["mac"]

    xbmc.log(f"[MAC] STREAM CMD → {original_cmd}", xbmc.LOGINFO)

    # 🔥 direct m3u8 (bez play_token)
    if original_cmd.startswith("http") and ".m3u8" in original_cmd and "play_token" not in original_cmd:
        xbmc.log("[MAC] DIRECT M3U8 STREAM", xbmc.LOGINFO)
        return original_cmd

    # 🔥 HANDSHAKE
    token = do_handshake(portal, mac)
    opener, _ = get_session(portal, mac)
    _active_sessions[mac] = opener

    if not token:
        xbmc.log("[MAC] TOKEN FAIL – RETRY FORCE", xbmc.LOGINFO)
        token = do_handshake(portal, mac, force=True)
        if not token:
            return None

    # 🔧 wspólne czyszczenie linku
    def clean_link(link):
        if not link:
            return None
        link = link.strip()
        if link.startswith("ffmpeg "):
            link = link.split(" ", 1)[1].strip()
        # 🔥 NIE TNJEMY "|"
        return link

    # ==========================================================
    # 1️⃣ CREATE_LINK
    # ==========================================================

    create_url = (
        f"{portal}portal.php?type={content_type}&action=create_link"
        f"&cmd={urllib.parse.quote(original_cmd)}&JsHttpRequest=1-xml"
    )

    for attempt in range(2):

        raw = mag_request(create_url, mac, portal, token, referer=portal + "c/")

        if not raw or "authorization" in raw.lower():
            xbmc.log("[MAC] CREATE_LINK – NEW TOKEN", xbmc.LOGINFO)
            token = do_handshake(portal, mac, force=True)
            continue

        try:
            data = json.loads(raw)
            link = clean_link(data.get("js", {}).get("cmd"))
            if link and link.startswith("http"):
                xbmc.log(f"[MAC] CREATE_LINK OK → {link}", xbmc.LOGINFO)
                return link
        except Exception as e:
            xbmc.log(f"[MAC] CREATE_LINK PARSE FAIL {e}", xbmc.LOGERROR)

        break

    # ==========================================================
    # 2️⃣ PLAY
    # ==========================================================

    try:
        play_url = (
            f"{portal}portal.php?type={content_type}&action=play"
            f"&cmd={urllib.parse.quote(original_cmd)}&JsHttpRequest=1-xml"
        )

        raw = mag_request(play_url, mac, portal, token, referer=portal + "c/")

        if raw:
            data = json.loads(raw)
            link = clean_link(data.get("js", {}).get("cmd"))
            if link and link.startswith("http"):
                xbmc.log(f"[MAC] PLAY OK → {link}", xbmc.LOGINFO)
                return link

    except Exception as e:
        xbmc.log(f"[MAC] PLAY FAIL {e}", xbmc.LOGERROR)

    # ==========================================================
    # 3️⃣ GET_LINK
    # ==========================================================

    try:
        getlink_url = (
            f"{portal}portal.php?type={content_type}&action=get_link"
            f"&cmd={urllib.parse.quote(original_cmd)}&JsHttpRequest=1-xml"
        )

        raw = mag_request(getlink_url, mac, portal, token, referer=portal + "c/")

        if raw:
            data = json.loads(raw)
            link = clean_link(data.get("js", {}).get("cmd"))
            if link and link.startswith("http"):
                xbmc.log(f"[MAC] GET_LINK OK → {link}", xbmc.LOGINFO)
                return link

    except Exception as e:
        xbmc.log(f"[MAC] GET_LINK FAIL {e}", xbmc.LOGERROR)

    # ==========================================================
    # 4️⃣ LIVE REWRITE (ostateczny fallback)
    # ==========================================================

    try:
        if "/ch/" in original_cmd:
            xbmc.log("[MAC] LIVE REWRITE", xbmc.LOGINFO)

            channel_id = original_cmd.split("/ch/")[1].split("_")[0]
            mac_clean = mac.replace(":", "")

            live_url = f"{portal}live/{mac_clean}/{token}/{channel_id}.m3u8"

            xbmc.log(f"[MAC] LIVE URL → {live_url}", xbmc.LOGINFO)
            return live_url

    except Exception as e:
        xbmc.log(f"[MAC] LIVE REWRITE FAIL {e}", xbmc.LOGERROR)

    return None
# ===============================
# DECODE VOD
# ===============================
def decode_vod_cmd(cmd):
    try:
        decoded = base64.b64decode(cmd).decode("utf-8")
        return json.loads(decoded)
    except:
        return None

def normalize_portal(portal):
    portal = portal.rstrip("/") + "/"
    return portal
def auto_detect_portal(portal, mac):
    portal = normalize_portal(portal)

    # 1️⃣ test bez /c/
    result, err = test_mac_speed(portal, mac)
    if result:
        return portal, result

    # 2️⃣ test z /c/
    portal_c = portal + "c/"
    result, err = test_mac_speed(portal_c, mac)
    if result:
        return portal_c, result

    return None, "NO_WORKING_PORTAL"

def test_mac_speed(portal, mac):

    start = time.time()

    token = do_handshake(portal, mac, force=True)
    if not token:
        return None, "TOKEN_FAIL"

    url = f"{portal}portal.php?type=itv&action=get_all_channels&JsHttpRequest=1-xml"

    try:
        raw, http_code = mag_request(url, mac, portal, token, return_code=True)
    except Exception as e:
        return None, f"REQUEST_ERR:{e}"

    if http_code != 200:
        return None, f"HTTP_{http_code}"

    try:
        data = json.loads(raw)
        channels = data.get("js", {}).get("data", [])
        channel_count = len(channels)
    except:
        return None, "BAD_JSON"

    if channel_count == 0:
        return None, "NO_CHANNELS"

    elapsed = time.time() - start

    result = {
        "time": elapsed,
        "channels": channel_count,
        "http": http_code
    }

    return result, None


def manage_macs(slot_index):

    slots = load_slots()

    if slot_index >= len(slots):
        return

    slot = slots[slot_index]
    mac_raw = slot.get("mac", [])

    # zawsze lista
    if isinstance(mac_raw, list):
        mac_list = [m.strip() for m in mac_raw if m.strip()]
    else:
        mac_list = [m.strip() for m in mac_raw.splitlines() if m.strip()]

    portal = slot["portal"].rstrip("/") + "/"

    while True:

        menu = [
            "Info konta",
            "Wpisz MAC",
            "Auto wybór najszybszego (TEST)",
            "Usuń cache"
        ]

        if mac_list:
            menu.append("───────── MAC:(lista niżej) ───────── Akcja na wybranym ─────────")
            menu.extend(mac_list)

        choice = xbmcgui.Dialog().select("Zarządzaj MAC", menu)

        if choice == -1:
            return

        # ℹ INFO
        if choice == 0:
            active_mac = mac_list[0] if mac_list else None
            if not active_mac:
                xbmcgui.Dialog().notification("Info", "Brak MAC")
                continue
            show_account_info(portal, active_mac)
            continue

        # ➕ DODAJ MAC
        if choice == 1:
            new_mac = xbmcgui.Dialog().input("Podaj MAC")
            if not new_mac:
                continue
            new_mac = new_mac.strip()
            if new_mac in mac_list:
                xbmcgui.Dialog().notification("MAC", "MAC już istnieje")
                continue
            mac_list.append(new_mac)
            slot["mac"] = mac_list
            save_slots(slots)
            continue


        # ⚡ AUTO TEST – skrócony i szybszy
        if choice == 2:
            xbmcgui.Dialog().notification(
                "TEST MAC",
                "Rozpoczynam test portalu i MAC-ów...",
                xbmcgui.NOTIFICATION_INFO,
                1500
            )

            MAX_TEST = 20
            test_list = mac_list[:MAX_TEST]

            # -------------------------
            # 1️⃣ Wybór działającego portalu
            # -------------------------
            working_portal, portal_result = auto_detect_portal(slot["portal"], test_list[0])
            if not working_portal:
                xbmcgui.Dialog().notification(
                    "TEST MAC",
                    f"Żaden portal nie działa\n{portal_result}",
                    xbmcgui.NOTIFICATION_ERROR,
                    5000
                )
                continue

            xbmcgui.Dialog().notification(
                "TEST MAC",
                f"Działający portal:\n{working_portal}",
                xbmcgui.NOTIFICATION_INFO,
                1500
            )

            # -------------------------
            # 2️⃣ Test MAC-ów na działającym portalu
            # -------------------------
            best_mac = None
            best_time = float("inf")
            best_channels = 0
            best_http = 0
            rejected = {}

            for mac in test_list:
                xbmcgui.Dialog().notification(
                    "TEST MAC",
                    f"Sprawdzam:\n{mac}",
                    xbmcgui.NOTIFICATION_INFO,
                    1000
                )

                result, error = test_mac_speed(working_portal, mac)

                if error:
                    rejected[mac] = error
                    continue

                elapsed = result["time"]
                channel_count = result["channels"]
                http_code = result["http"]

                if elapsed < best_time:
                    best_time = elapsed
                    best_mac = mac
                    best_channels = channel_count
                    best_http = http_code

            # -------------------------
            # 3️⃣ Wynik testu
            # -------------------------
            if best_mac:
                mac_list.remove(best_mac)
                mac_list.insert(0, best_mac)
                slot["mac"] = mac_list
                save_slots(slots)

                xbmcgui.Dialog().notification(
                    "MAC TEST",
                    f"Wybrano: {best_mac}\nHTTP: {best_http}  Kanały: {best_channels}  Czas: {best_time:.2f}s\nOdrzucono: {len(rejected)}",
                    xbmcgui.NOTIFICATION_INFO,
                    10000
                )
            else:
                xbmcgui.Dialog().notification(
                    "MAC TEST",
                    f"Żaden MAC nie działa\nOdrzucono: {len(rejected)}",
                    xbmcgui.NOTIFICATION_ERROR,
                    10000
                )

            # =========================
            # wynik testu
            # =========================
            if best_mac:
                mac_list.remove(best_mac)
                mac_list.insert(0, best_mac)
                slot["mac"] = mac_list
                save_slots(slots)

                xbmcgui.Dialog().notification(
                    "MAC TEST",
                    f"Wybrano: {best_mac} "
                    f"HTTP: {best_http}  Kanały: {best_channels} "
                    f"Czas: {best_time:.2f}s  Status: OK\n"
                    f"Odrzucono: {len(rejected)} {rejected}",
                    xbmcgui.NOTIFICATION_INFO,
                    15000
                )

            else:
                xbmcgui.Dialog().notification(
                    "MAC TEST",
                    f"{portal}\nŻaden MAC nie działa\nOdrzucono: {len(rejected)}",
                    xbmcgui.NOTIFICATION_INFO,
                    15000
                )
                delete_slot()
##                xbmc.executebuiltin("Container.Refresh")
                return
        # 🧹 CACHE
        if choice == 3:
            usun_cache()
            continue

        if choice < len(menu) and "MAC:" in menu[choice]:
            continue

        # WYBRANY MAC Z LISTY
        selected_mac = menu[choice]
        if selected_mac not in mac_list:
            continue

        actions = ["Użyj"]
        if len(mac_list) > 1:
            actions.append("Usuń")
        action = xbmcgui.Dialog().select(selected_mac, actions)
        if action == -1:
            continue

        if action == 0:  # UŻYJ
            mac_list.remove(selected_mac)
            mac_list.insert(0, selected_mac)
            slot["mac"] = mac_list
            save_slots(slots)
            xbmcgui.Dialog().notification("MAC", f"Aktywny:\n{selected_mac}")
            return

        if action == 1:  # USUŃ
            mac_list.remove(selected_mac)
            slot["mac"] = mac_list
            save_slots(slots)
            continue