# -*- coding: utf-8 -*-
import sys
import xbmc
import xbmcgui
import xbmcplugin
from yt_dlp import YoutubeDL

ADDON_NAME = "[PolskaTV:YouTube_test]"

def log(msg):
    xbmc.log(f"{ADDON_NAME} {msg}", xbmc.LOGINFO)

# ============================================================
# 📺 Lista kanałów YouTube
# ============================================================
CHANNELS = [
    {"name": "*** Otwórz wpisany link youtube ***", "url": "keyboard","icon":"https://cdn.pixabay.com/photo/2022/01/21/00/38/youtube-icon-6953527_1280.jpg"},
    {"name": "Śpiewające Brzdące", "url": "https://www.youtube.com/watch?v=6NlE1MwLgeM","icon": "https://i.ytimg.com/vi/6NlE1MwLgeM/hqdefault.jpg"},
    {"name": "Telewizja Republika", "url": "https://www.youtube.com/watch?v=dzntyCTgJMQ","icon": "https://i.ytimg.com/vi/dzntyCTgJMQ/hqdefault.jpg"},
    {"name": "Królestwo Zwierząt 4K", "url": "https://www.youtube.com/watch?v=ItoNVjSmkx0","icon": "https://i.ytimg.com/vi/ItoNVjSmkx0/maxresdefault.jpg"},
    {"name": "TVP INFO", "url": "https://www.youtube.com/watch?v=3jKb-uThfrg","icon": "https://i.ytimg.com/vi/3jKb-uThfrg/maxresdefault.jpg"},
    {"name": "Bajlandia", "url": "https://www.youtube.com/watch?v=cP8BZR4Ro6Q","icon": "https://i.ytimg.com/vi/cP8BZR4Ro6Q/maxresdefault.jpg"},
    {"name": "Telewizja Narew", "url": "https://www.youtube.com/watch?v=V3ilOsyY-sw ","icon": "https://yt3.ggpht.com/PAdueMhc9cFYkYeiLiRDOWOTc-TwHUpUICnBVuL7DSPJYXeojPNvGOL00cles1INGFE_vC0f5rc=s176-c-k-c0x00ffffff-no-rj"},
    {"name": "Telewizja Zabrze", "url": "https://www.youtube.com/watch?v=f5njIX-Y31U","icon": "https://yt3.ggpht.com/ytc/AIdro_kGsibFgHllYE5MBKBrjzESc_SSmQbIefmfJvUTqm0DNXU=s176-c-k-c0x00ffffff-no-rj"},
    {"name": "TV Sudecka", "url": "https://www.youtube.com/watch?v=HMjf450mRfk","icon": "https://yt3.ggpht.com/ytc/AIdro_lhasv660tqs7kj0PgCG9XXDR13uDbE9ksRjKwFHKV7Puw=s176-c-k-c0x00ffffff-no-rj"},
    {"name": "Horyzont TV", "url": "https://www.youtube.com/watch?v=ixEFVDIVKAU","icon": "https://yt3.ggpht.com/g2hJyG6kaWEkU3vlVV8ojx5FtGN8IG4xqUcDp2FTibZKKCYokW14ZrDvGrZksmujMNhFIaHLIA=s176-c-k-c0x00ffffff-no-rj"},
    {"name": "Telewizja wPolsce24 ", "url": "https://www.youtube.com/watch?v=YNqeMjq3E5A","icon": "https://yt3.ggpht.com/LKFnPg1dhI5bCp4dW2plZAW_fvqydTe7yUVg0y1uYcEfOZ0EFvtKZFz2tOYTWBk0ht-AeBl4ow=s176-c-k-c0x00ffffff-no-rj"},
    {"name": "BIZNES24", "url": "https://www.youtube.com/watch?v=1ocbJcGikfM","icon": "https://yt3.ggpht.com/ibnEkJafyvInsEN9n7tmPlTUas9xevH4Z14okEM5UyLx4tIzoVHG-5h3Bgitywepv-HtqHemng=s176-c-k-c0x00ffffff-no-rj"},
    {"name": "Telewizja Wielkopolska", "url": "https://www.youtube.com/watch?v=udyDT4URRKs","icon": "https://yt3.ggpht.com/ytc/AIdro_nEMQMK7qfC-CZeAOlK6GZNxO07TG78ScjEZJ58DVktcw=s176-c-k-c0x00ffffff-no-rj"},
    {"name": "TVP Polonia", "url": "https://www.youtube.com/watch?v=O1CMEAPYZ9c","icon": "https://yt3.ggpht.com/Xyn3JDvD38LdFBQomwaXJvyAXiHJP5CG4adq-WVzFj72x_9mWlkx37QiFnyOQM6eSGXZBgKP9w=s176-c-k-c0x00ffffff-no-rj"},
    {"name": "Python Tutorial","url": "https://www.youtube.com/watch?v=B9BRuhqEb2Q", "icon": "https://yt3.ggpht.com/ytc/AIdro_k4SjBuOliq_ddGDX8fy9Ql1Q-K72AfLNmc7ntQqlneLWg=s176-c-k-c0x00ffffff-no-rj"},
]



def open_keyboard_and_play():
    kb = xbmc.Keyboard("", "Podaj URL streamu")
    kb.doModal()
    if not kb.isConfirmed():
        return

    url = kb.getText().strip()
    if not url:
        return

    return url


# ============================================================
# 🎬 Funkcja pobierająca najlepszy strumień YouTube
# ============================================================
def get_best_youtube_stream(video_url):
    """Zwraca najlepszy możliwy stream (najlepsze video + audio lub HLS)."""

    ydl_opts = {
        "quiet": True,
        "no_warnings": True,
        "skip_download": True,
        "noplaylist": True,
        "geo_bypass": True,
        "extractor_args": {"youtube": {"player_client": ["android", "web"]}},
        "format_sort": ["res:1080,fps,codec:avc:m4a"],  # preferuj 1080p+
        "age_limit": 0,  # umożliwia kanały "for kids"
    }

    try:
        with YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(video_url, download=False)
            if "entries" in info:
                info = info["entries"][0]

            # 🔹 Priorytet: manifest HLS (najstabilniejsze w Kodi)
            for f in reversed(info.get("formats", [])):
                if f.get("url") and "m3u8" in f.get("url"):
                    log(f"🎯 HLS znaleziony: {f['url']}")
                    return f["url"]

            # 🔹 Alternatywa: najwyższa jakość MP4 (fallback)
            best_video = max(
                (f for f in info.get("formats", []) if f.get("vcodec") != "none" and f.get("acodec") != "none"),
                key=lambda x: x.get("height", 0),
                default=None
            )
            if best_video:
                log(f"🎯 Najlepszy MP4: {best_video['url']}")
                return best_video["url"]

            # 🔹 Ostatecznie — cokolwiek YouTube zwróci
            if info.get("url"):
                log(f"🎯 Domyślny URL: {info['url']}")
                return info["url"]

    except Exception as e:
        log(f"❌ Błąd get_best_youtube_stream: {e}")

    return None


# ============================================================
# ▶️ Odtwarzanie kanału
# ============================================================
def play_channel(url):
    """Odtwarza kanał YouTube w najlepszej jakości."""
    if url =='keyboard':
        url =open_keyboard_and_play()

    try:
        handle = int(sys.argv[1])
        log(f"Odtwarzanie: {url}")

        stream_url = get_best_youtube_stream(url)
        if not stream_url:
            xbmcgui.Dialog().ok("Błąd", f"Nie udało się pobrać linku dla:\n{url}")
            return

        li = xbmcgui.ListItem(path=stream_url)
        li.setInfo("video", {"title": url})
##        li.setInfo("video", {"title": name or url})
        # Jeśli to manifest HLS
        if ".m3u8" in stream_url:
            li.setMimeType("application/vnd.apple.mpegurl")
            li.setContentLookup(False)
            try:
                from inputstreamhelper import Helper
                hls = Helper("hls")
                if hls.check_inputstream():
                    li.setProperty("inputstream", hls.inputstream_addon)
                    li.setProperty("inputstream.adaptive.manifest_type", "hls")
                    xbmc.log("[PolskaTV:YouTube_test] InputStream Adaptive aktywny", xbmc.LOGINFO)
            except Exception as e:
                xbmc.log(f"[PolskaTV:YouTube_test] InputStream Adaptive niedostępny: {e}", xbmc.LOGWARNING)

        xbmcplugin.setResolvedUrl(handle, True, li)
        log(f"✅ setResolvedUrl OK: {stream_url}")

    except Exception as e:
        xbmcgui.Dialog().ok("Błąd odtwarzania", str(e))
        log(f"❌ play_channel: {e}")
