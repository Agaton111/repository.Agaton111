# -*- coding: utf-8 -*-
CHANNELS = [
    {"name": "Stacja Test (BigBuckBunny)", "url": "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
     "icon": "special://home/addons/plugin.video.polskietv/resources/media/test.png"},


    {"name": "Red Bull TV (live)", "url": "https://shls-live-enc.edgenextcdn.net/out/v1/ad35123d4ad041068bce26ae67ee3180/index.m3u8",
     "icon": "special://home/addons/plugin.video.polskietv/resources/media/redbull.png"},



    {"name": "Music Box", "url": "https://vs2131.vcdn.biz/3e0c9afcea819df6b5f994671a5b8981_megogo/live/hls/b/4000/u_sid/0/o/156751011/rsid/a1f6ea0a-9280-432e-a466-25c5dcab2319/u_uid/0/u_vod/1/u_device/embed_all/u_devicekey/_embed_web/lip/31.182.190.52*asn/type.live/chunklist-sid4965610826451018698-b4000000.m3u8",
     "icon": ""},
    {"name": "FILMBOX FAMILY HD", "url": "https://cdn.kinoteka.cc/weebtv/gen.m3u8.php?id=nickelodeon_", "icon": ""},
    {"name": "Polsat Sport Premium 1", "url": "https://cdn.kinoteka.cc/weebtv/gen.m3u8.php?id=pspremium1", "icon": ""},
    {"name": "Polsat Sport Premium 2", "url": "https://cdn.kinoteka.cc/weebtv/gen.m3u8.php?id=pspremium2", "icon": ""},
    {"name": "TVP Sport", "url": "https://cdn.kinoteka.cc/weebtv/gen.m3u8.php?id=sportTVP_channeed", "icon": ""},



]




