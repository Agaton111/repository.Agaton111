# -*- coding: utf-8 -*-
#####  cmf3.py
import os
import re
import json
import time
import requests
import xbmc
import xbmcvfs
from bs4 import BeautifulSoup
from urllib.parse import urljoin, urlparse
from resources.lib import jsunpack
from resources.lib import config
import xbmcgui

LOG_FILE = config.LOG_FILE
ADDON_PROFILE = config.ADDON_PROFILE
HEADERS = {"User-Agent": config.USER_AGENT}

def _log(msg, level=xbmc.LOGINFO):
    try:
        if not xbmcvfs.exists(ADDON_PROFILE):
            xbmcvfs.mkdirs(ADDON_PROFILE)
        with open(LOG_FILE, "a", encoding="utf-8") as f:
            f.write(f"{time.strftime('%Y-%m-%d %H:%M:%S')} [cmf3] {msg}\n")
    except Exception:
        pass
    xbmc.log(f"[cmf3] {msg}", level)

def normalize_url(u, base=None):
    if not u:
        return None
    u = u.strip()
    if base and not bool(urlparse(u).scheme):
        u = urljoin(base, u)
    u = re.sub(r"^(https?:)/+", r"\1//", u)
    if u.startswith("//"):
        u = "https:" + u
    return u

def _collect_from_text(text, base):
    found = []
    if not text:
        return found
    # manifesty
    found += re.findall(r"https?://[^\s'\"<>]+?\.(?:m3u8|mpd|mp4)(?:[^\s'\"<>]*)", text, flags=re.IGNORECASE)
    # niektóre "masterlist" itd.
    found += re.findall(r"https?://[^\s'\"<>]+?(?:masterlist|index|playlist)[^\s'\"<>]*", text, flags=re.IGNORECASE)
    # base64 duże ciągi (potencjalne podlinkowane dane)
    b64s = re.findall(r"(?:(?:[A-Za-z0-9+/]{80,}={0,2}))", text)
    for b in b64s:
        try:
            import base64
            dec = base64.b64decode(b + "==", validate=False).decode("utf-8", "ignore")
            found += re.findall(r"https?://[^\s'\"<>]+", dec)
        except Exception:
            continue
    # normalizuj i odfiltruj
    out = []
    for u in found:
        nu = normalize_url(u, base)
        if nu and nu not in out:
            out.append(nu)
    return out

def run_dynamic_parse(page_url, render_html=None):
    """
    Analizuje stronę; jeśli render_html jest podane, użyje go zamiast requests (przydatne gdy Playwright zwraca HTML).
    Zwraca listę oczyszczonych linków (same manifesty .m3u8/.mpd/.mp4 itd.)
    """
    try:
        _log(f"📡 [cmf3] Start analizy dla: {page_url}")
        if render_html is None:
            r = requests.get(page_url, headers=HEADERS, timeout=10)
            r.raise_for_status()
            html = r.text
        else:
            html = render_html

        _log(f"📄 [cmf3] Długość HTML: {len(html)}")

        # JS-packed
        if jsunpack.detect_packed(html):
            _log("🧩 [cmf3] Wykryto zapakowany JavaScript — próbuję rozpakować (może pomóc).")
            try:
                html_un = jsunpack.unpack(html)
                if html_un and len(html_un) > len(html):
                    html = html_un
                    _log(f"✅ [cmf3] JS rozpakowany, długość: {len(html)}")
                else:
                    # nadal przydatne: HTML może nie znacząco wzrosnąć — logujemy
                    _log("ℹ️ [cmf3] JS rozpakowany, ale brak znaczącej zmiany rozmiaru.")
            except Exception as e:
                _log(f"⚠️ [cmf3] Błąd przy unpack: {e}")

        soup = BeautifulSoup(html, "html.parser")
        base = page_url

        found = []

        # 1) tagi video/source
        for tag in soup.find_all(["video","source"]):
            s = tag.get("src") or tag.get("data-src") or ""
            if s:
                nu = normalize_url(s, base)
                if nu:
                    found.append(nu)

        # 2) iframe
        for ifr in soup.find_all("iframe"):
            s = ifr.get("src") or ifr.get("data-src") or ""
            if s:
                nu = normalize_url(s, base)
                if nu:
                    found.append(nu)
                    # krótki fragment do logu
                    frag = str(ifr)[:600].replace("\n"," ")
                    _log(f"🔍 Fragment iframe: {frag}")

        # 3) skrypty (szukamy manifestUri, linków, base64)
        for s in soup.find_all("script"):
            txt = s.string or s.get_text() or ""

            if not txt:
                continue
            # loguj jeśli zawiera manifestUri lub base64
            if "manifestUri" in txt or "base64" in txt or "playerDataUrl" in txt:

                snippet = txt[:400].replace("\n"," ")
                _log(f"🔍 Fragment script zawierający manifestUri/base64/playerDataUrl: {snippet}")
            found += _collect_from_text(txt, base)

        # 4) surowy regex po całym HTML (ostatnia szansa)
        found += _collect_from_text(html, base)

        # uniq & filtr
        cleaned = []
        for u in found:
            if not u:
                continue
            # proste ominięcie linków analytics i reklam
            if any(x in u.lower() for x in ("googletagmanager","doubleclick","gtm.","tracking","analytics","pixel")):
                continue
            if u not in cleaned:
                cleaned.append(u)

##            _log(f"✅ [cmf3] Znaleziono {len(cleaned)} link(ów).")
            for u in cleaned:
                _log(f"   -> {u}")
            return cleaned

        # debug: pokaż fragmenty gdy nic nie znaleziono
        _log("❌ [cmf3] Nic nie znaleziono — pokazuję fragmenty HTML do diagnostyki:")
        # kilka pierwszych iframe/video/script
        if soup.find_all("iframe"):
            _log("🔎 [cmf3] Przykładowy iframe (pierwsze 900 znaków):")
            _log(str(soup.find_all("iframe")[0])[:900].replace("\n"," "))
        if soup.find_all("video"):
            _log("🔎 [cmf3] Przykładowy video/source (pierwsze 900 znaków):")
            _log(str(soup.find_all("video")[0])[:900].replace("\n"," "))
        for s in soup.find_all("script")[:6]:
            txt = (s.string or s.get_text() or "")[:900].replace("\n"," ")
            if txt.strip():
                _log("🔎 [cmf3] Skrypt fragment:")
                _log(txt)
                break

        return []

    except Exception as e:
        _log(f"⚠️ [cmf3] Błąd pobierania lub parsowania: {e}")
        return []
