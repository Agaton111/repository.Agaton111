import xbmcgui
import os
import sys
import re
import json
import xbmcaddon
import xbmc
import xbmcvfs
import urllib.parse


ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo("id") or "plugin.video.polskatv"
FOLDER = xbmcvfs.translatePath(f"special://profile/addon_data/{ADDON_ID}")
LISTY_RAZEM_FILE = os.path.join(FOLDER, "listy_razem.json")

params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
action = params.get("action")
# ==================================================
# OKNO – PODAJ NAZWĘ KANAŁU
# ==================================================
def ask_channel_name():
    kb = xbmc.Keyboard("", "Podaj nazwę kanału TV")
    kb.doModal()
    # Jeśli użytkownik anulował, zwróć None
    if not kb.isConfirmed():
        xbmc.sleep(100)  # krótka pauza, pozwala Kodi zamknąć Keyboard
        return None
    return kb.getText().strip()


# ==================================================
# WCZYTAJ BAZĘ
# ==================================================
def load_listy_razem():
    if not os.path.exists(LISTY_RAZEM_FILE):
        xbmcgui.Dialog().ok("Błąd", "Brak pliku listy_razem.json")
        return []

    with open(LISTY_RAZEM_FILE, "r", encoding="utf-8") as f:
        return json.load(f)

# ==================================================
# SZUKAJ KANAŁU
# ==================================================
def natural_key(text):
    return [int(c) if c.isdigit() else c.lower()
            for c in re.split(r'(\d+)', text)]



def find_channels(data, query):
    query = query.lower()
    results = []

    for item in data:
        name = item.get("nazwa", "").lower()
        if query in name:
            results.append(item)
##    results.sort(key=lambda x: x.get("nazwa", "").lower())
##    results.sort(key=lambda x: natural_key(x.get("nazwa", "")))
    results.sort(key=lambda x: (
        x.get("nazwa", "").lower(),
        x.get("id_modulu", "").lower()
    ))


    return results


# ==================================================
# ZBUDUJ CHANNELS → uni_player
# ==================================================
def build_channels(items):
    if not items:
        xbmcgui.Dialog().ok("Brak wyniku", "Nie znaleziono kanałów.")
        return []

    channels = []

    for item in items:
        url = (
            "plugin://plugin.video.polskatv/"
            "?action=uni_player2"
            f"&url={urllib.parse.quote(item['url'])}"
            f"&name={urllib.parse.quote(item['nazwa'])}"
            f"&module={urllib.parse.quote(item['id_modulu'])}"
        )

        # 🔥 Dodaj moduł do wyświetlanej nazwy
        display_name = f"{item['nazwa']}  ({item['id_modulu']})"

        channels.append({
            "name": display_name,
            "url": url,
            "icon": "https://cdn.pixabay.com/photo/2022/01/21/00/38/youtube-icon-6953527_1280.jpg"
        })

    return channels

# BUDOWANIE LISTY (TYLKO open_list)
# ==================================================
if action == "open_list":
    szukane = ask_channel_name()
    if szukane:
        baza = load_listy_razem()
        wyniki = find_channels(baza, szukane)
        CHANNELS = build_channels(wyniki)
    else:
        CHANNELS = []