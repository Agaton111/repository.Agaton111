# -*- coding: utf-8 -*-
import xbmcaddon
import xbmcvfs
import xbmcgui
import xbmc
import json
import os

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo("id")
ADDON_PROFILE = xbmcvfs.translatePath(f"special://profile/addon_data/{ADDON_ID}/")


# -------------------------------------------------
# pomocnicze
# -------------------------------------------------

def get_dir_stats(path):
    """zlicza pliki i rozmiar katalogu"""
    total_files = 0
    total_size = 0

    try:
        dirs, files = xbmcvfs.listdir(path)

        for f in files:
            total_files += 1
            fp = path + f
            try:
                stat = xbmcvfs.Stat(fp)
                total_size += stat.st_size()
            except:
                pass

        for d in dirs:
            dpath = path + d + "/"
            fcount, fsize = get_dir_stats(dpath)
            total_files += fcount
            total_size += fsize

    except:
        pass

    return total_files, total_size


def format_size(size):
    """format MB"""
    try:
        return f"{size/1024/1024:.2f} MB"
    except:
        return "0 MB"


def delete_dir_recursive(path):
    """usuwa katalog rekurencyjnie"""

    try:
        dirs, files = xbmcvfs.listdir(path)

        for f in files:
            xbmcvfs.delete(path + f)

        for d in dirs:
            delete_dir_recursive(path + d + "/")

        xbmcvfs.rmdir(path)

    except Exception as e:
        xbmc.log(f"[PolskaTV] delete error {path} {e}", xbmc.LOGWARNING)


# -------------------------------------------------
# tworzenie pustego cache
# -------------------------------------------------

def create_empty_cache():

    cache_file = ADDON_PROFILE + "nowy_test_cache.json"

    try:
        if not xbmcvfs.exists(ADDON_PROFILE):
            xbmcvfs.mkdirs(ADDON_PROFILE)

        with xbmcvfs.File(cache_file, "w") as f:
            f.write(json.dumps({}, ensure_ascii=False, indent=2))

    except Exception as e:
        xbmc.log(f"[PolskaTV] cache create error {e}", xbmc.LOGWARNING)


# -------------------------------------------------
# zbieranie cache
# -------------------------------------------------

def get_cache_items():

    dirs, files = xbmcvfs.listdir(ADDON_PROFILE)

    cache_files = [f for f in files if f.endswith("_cache.json")]
    cache_dirs = [d + "/" for d in dirs if d.endswith("_cache")]

    return cache_files + cache_dirs


# -------------------------------------------------
# usuwanie
# -------------------------------------------------

def remove_items(items):

    removed = []

    for item in items:

        path = ADDON_PROFILE + item

        try:
            if item.endswith("/"):
                delete_dir_recursive(path)
            else:
                xbmcvfs.delete(path)

            removed.append(item)

        except Exception as e:
            xbmc.log(f"[PolskaTV] delete error {path} {e}", xbmc.LOGWARNING)

    return removed


# -------------------------------------------------
# główne menu
# -------------------------------------------------

def run():

    items = get_cache_items()

    if not items:
        xbmcgui.Dialog().ok("Cache", "Brak cache.")
        create_empty_cache()
        return

    # budowa opisów
    display = []

    for item in items:

        path = ADDON_PROFILE + item

        if item.endswith("/"):
            files, size = get_dir_stats(path)
            label = f"{item}  ({files} plików | {format_size(size)})"
        else:
            try:
                stat = xbmcvfs.Stat(path)
                label = f"{item} ({format_size(stat.st_size())})"
            except:
                label = item

        display.append(label)

    menu = [
        "🧹 Wyczyść wszystko",
        "🎬 Wyczyść tylko VOD cache",
        "📺 Wyczyść tylko TV cache",
        "📂 Wybierz ręcznie"
    ]
    choice = xbmcgui.Dialog().select("Czyszczenie cache", menu)

# -------------------------------------------------

    if choice == 0:

        removed = remove_items(items)

    elif choice == 1:

        vod = [i for i in items if "vod" in i.lower()]
        removed = remove_items(vod)

    elif choice == 2:

        tv = [i for i in items if "tv" in i.lower()]
        removed = remove_items(tv)

    else:

        idx = xbmcgui.Dialog().multiselect(
            "Wybierz cache",
            display
        )

        if not idx:
            return

        selected = [items[i] for i in idx]

        removed = remove_items(selected)
    # -------------------------------------------------

    create_empty_cache()

    if removed:

        xbmcgui.Dialog().ok(
            "Cache",
            "Usunięto:\n\n" + "\n".join(removed)
        )

    else:

        xbmcgui.Dialog().ok(
            "Cache",
            "Nic nie usunięto."
        )