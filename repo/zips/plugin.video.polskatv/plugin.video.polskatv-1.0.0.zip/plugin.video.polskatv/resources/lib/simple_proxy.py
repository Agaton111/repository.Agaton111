import threading
import requests
from http.server import BaseHTTPRequestHandler, HTTPServer
import socketserver
import urllib.parse
import xbmc
import mac_api_li

PORT = 19090
_server = None


class ThreadedHTTPServer(socketserver.ThreadingMixIn, HTTPServer):
    daemon_threads = True


class StreamHandler(BaseHTTPRequestHandler):

    def do_GET(self):
        try:
            parsed = urllib.parse.urlparse(self.path)
            params = urllib.parse.parse_qs(parsed.query)

            url = params.get("url", [None])[0]
            slot = int(params.get("slot", [0])[0])

            if not url:
                self.send_error(400)
                return

            slot_data = mac_api_li.get_slot(slot)
            portal = slot_data["portal"]
            mac = slot_data["mac"]

            # 🔹 Pobierz sesję z mac_api_li
            opener, cookiejar = mac_api_li.get_session(portal, mac)

            cookies = {c.name: c.value for c in cookiejar}

            headers = {
                "User-Agent": "Mozilla/5.0 (QtEmbedded; U; Linux; C) MAG254",
                "Referer": portal.rstrip("/") + "/c/"
            }

            xbmc.log(f"[PROXY] STREAMING {url}", xbmc.LOGINFO)

            with requests.get(
                url,
                headers=headers,
                cookies=cookies,
                stream=True,
                timeout=10,
                verify=False
            ) as r:

                self.send_response(r.status_code)

                for key, value in r.headers.items():
                    if key.lower() in ["content-type", "content-length"]:
                        self.send_header(key, value)

                self.end_headers()

                for chunk in r.iter_content(chunk_size=64 * 1024):
                    if chunk:
                        self.wfile.write(chunk)

        except Exception as e:
            xbmc.log(f"[PROXY ERROR] {e}", xbmc.LOGERROR)

    def log_message(self, format, *args):
        return  # cisza


def start_proxy():
    global _server

    if _server:
        return

    server = ThreadedHTTPServer(("127.0.0.1", PORT), StreamHandler)
    thread = threading.Thread(target=server.serve_forever)
    thread.daemon = True
    thread.start()

    _server = server
    xbmc.log("[PROXY] STARTED", xbmc.LOGINFO)