# -*- coding: utf-8 -*-
# Prosty plik konfiguracji używany przez nowy_test.py i cmf3.py

import xbmcvfs
import xbmcaddon
import os

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo("id")
ADDON_PROFILE = xbmcvfs.translatePath(f"special://profile/addon_data/{ADDON_ID}")

LOG_FILE = os.path.join(ADDON_PROFILE, "nowy_test_log.txt")
CACHE_FILE = os.path.join(ADDON_PROFILE, "nowy_test_cache.json")

# wartości konfiguracyjne
LOG_MAX_SIZE = 500 * 1024
CACHE_MAX_AGE = 3 * 3600  # 3 godziny
USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"
