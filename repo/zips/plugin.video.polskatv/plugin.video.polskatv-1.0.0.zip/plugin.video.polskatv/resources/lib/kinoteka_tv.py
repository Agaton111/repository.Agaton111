# -*- coding: utf-8 -*-
import os
import re
import json
import time
import sys
import requests
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import urllib
from bs4 import BeautifulSoup
from urllib.parse import urljoin, urlparse

import urllib.parse


# ==================================================
# KONFIG
# ==================================================
ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo("id")
PROFILE = xbmcvfs.translatePath(f"special://profile/addon_data/{ADDON_ID}")
UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"
HEADERS = {"User-Agent": UA}

params = dict(
    urllib.parse.parse_qsl(sys.argv[2][1:])
)

base = ''

# ==================================================
# POMOCNICZE
# ==================================================
def normalize_url(u, base=None):
    if not u:
        return None
    u = u.strip()
    try:
        if base and not urlparse(u).scheme:
            u = urljoin(base, u)
    except Exception:
        pass
    if u.startswith("//"):
        u = "https:" + u
    u = re.sub(r'^(https?:)/+', r'\1//', u)
    return u

def looks_like_stream(u):
    return bool(re.search(r'\.(m3u8|mpd|mp4)(\?|$)', u, re.I))

# ==================================================
# DYNAMICZNE KANAŁY (weebtv)
# ==================================================
def get_channels_from_weebtv():
    url = "https://cdn.kinoteka.cc/weebtv/"
    channels = []

    try:
        r = requests.get(url, headers=HEADERS, timeout=10)
        r.raise_for_status()
        soup = BeautifulSoup(r.text, "html.parser")

        for div in soup.select("div.channel-card[onclick]"):
            onclick = div.get("onclick", "")
            m = re.search(
                r'playStream\(\s*"([^"]+)"\s*,\s*"([^"]+)"\s*\)',
                onclick
            )

            if not m:
                continue

            # pobranie ikony
            img = div.find("img")
            icon = img["src"].strip() if img and img.has_attr("src") else ""

            channels.append({
                "name": m.group(2).strip(),
                "url": m.group(1).strip(),
                "icon": icon
            })



    except:
        xbmcgui.Dialog().notification("kinoteka", "Błąd weebtv", xbmcgui.NOTIFICATION_INFO, 2000)
    return channels

# ==================================================
# STATYCZNE KANAŁY  "icon": "https://epg.ovh/logo/PlayLive+PPV+Platform.png"
# ==================================================
CHANNELS_STATIC = [

    {"name": "Disney Junior online", "url": "https://kinoteka.cc/tv_watch.php?id=37", "icon": "https://epg.ovh/logo/Disney+Junior.png"},
    {"name": "JimJam Polsat online", "url": "https://kinoteka.cc/tv_watch.php?id=136", "icon": "https://epg.ovh/logo/JimJam+Polsat.png"},
    {"name": "13 Ulica online", "url": "https://kinoteka.cc/tv_watch.php?id=119", "icon": "https://epg.ovh/logo/13+Ulica.png"},
    {"name": "AXN online", "url": "https://kinoteka.cc/tv_watch.php?id=62", "icon": "https://epg.ovh/logo/AXN.png"},
    {"name": "AXN BLACK online", "url": "https://kinoteka.cc/tv_watch.php?id=63", "icon": "https://epg.ovh/logo/AXN+Black.png"},
    {"name": "AXN White online", "url": "https://kinoteka.cc/tv_watch.php?id=65", "icon": "https://epg.ovh/logo/AXN+White.png"},
    {"name": "Filmbox Family online", "url": "https://kinoteka.cc/tv_watch.php?id=135", "icon": "https://epg.ovh/logo/Filmbox+Family.png"},
    {"name": "HBO online", "url": "https://kinoteka.cc/tv_watch.php?id=46", "icon": "https://epg.ovh/logo/HBO.png"},
    {"name": "HBO 2 online", "url": "https://kinoteka.cc/tv_watch.php?id=47", "icon": "https://epg.ovh/logo/HBO+2.png"},
    {"name": "Paramount Network online", "url": "https://kinoteka.cc/tv_watch.php?id=45", "icon": "https://epg.ovh/logo/Paramount+Channel.png"},
    {"name": "Polsat Film online", "url": "https://kinoteka.cc/tv_watch.php?id=27", "icon": "https://epg.ovh/logo/Polsat+Film+HD.png"},
    {"name": "Polsat Seriale online", "url": "https://kinoteka.cc/tv_watch.php?id=28", "icon": "https://epg.ovh/logo/Polsat+Seriale.png"},
    {"name": "TVN Fabuła online", "url": "https://kinoteka.cc/tv_watch.php?id=123", "icon": "https://epg.ovh/logo/TVN+Fabula.png"},
    {"name": "Warner TV online", "url": "https://kinoteka.cc/tv_watch.php?id=59", "icon": "https://epg.ovh/logo/Warner+TV.png"},
    {"name": "ABC News online", "url": "https://kinoteka.cc/tv_watch.php?id=138", "icon": "https://yt3.ggpht.com/GJ8V0NX6NddGh9bf4zED4tsjPjjBK2hdp5FWHMy09pV7sdSkkE3yEhCRSch4waEb9ZavyUrWfw=s176-c-k-c0x00ffffff-no-rj"},
    {"name": "BBC America online", "url": "https://kinoteka.cc/tv_watch.php?id=139", "icon": "https://yt3.ggpht.com/Rsa-C1kXjVDQtAhbcp1uxvPuSVsVFX7HYEIoDLyiDZVqr5xV6FDh9F7J5DlM5RIytVHTntgzXQ=s176-c-k-c0x00ffffff-no-rj"},
    {"name": "CBN News online", "url": "https://kinoteka.cc/tv_watch.php?id=140", "icon": "https://yt3.googleusercontent.com/ev4M4-4mLO6bj3tiYwh5gDqLKFIEMYNtfoQdab2fyEfJbehipv1n5r8HTsYQGfxuaYRC4eUnMdk=s900-c-k-c0x00ffffff-no-rj"},
    {"name": "FOX News online", "url": "https://kinoteka.cc/tv_watch.php?id=141", "icon": "https://epg.ovh/logo/Fox+News.png"},
    {"name": "Polsat News online", "url": "https://kinoteka.cc/tv_watch.php?id=131", "icon": ""},
    {"name": "Polsat News Polityka online", "url": "https://kinoteka.cc/tv_watch.php?id=106", "icon": ""},
    {"name": "TVN 24 online", "url": "https://kinoteka.cc/tv_watch.php?id=130", "icon": ""},
    {"name": "Wydarzenia 24 online", "url": "https://kinoteka.cc/tv_watch.php?id=133", "icon": ""},
    {"name": "History 2 online", "url": "https://kinoteka.cc/tv_watch.php?id=132", "icon": ""},


]

# ==================================================
# BUDOWANIE LISTY KANAŁÓW
# ==================================================
def build_channels():
    dynamic = get_channels_from_weebtv()
    merged = {}

    for ch in dynamic + CHANNELS_STATIC:
        name = ch.get("name", "").strip()
        if "BRZYDULA"in name:
            continue
        if "13 POS"in name:
            continue

        if not name:
            continue
        merged[name.lower()] = ch

    return sorted(
        merged.values(),
        key=lambda x: x.get("name", "").lower()
    )


CHANNELS = build_channels()

# ==================================================
# WYCIĄGANIE STRUMIENIA
# ==================================================
def extract_hls_from_page(page_url,name, timeout=10):

    resp = requests.get(page_url, headers=HEADERS, timeout=timeout)
    resp.raise_for_status()
    html = resp.text
    soup = BeautifulSoup(html, "html.parser")


    for ifr in soup.find_all("iframe"):
        src = ifr.get("src") or ifr.get("data-src") or ""
        page_url = normalize_url(src, base)
        resp = requests.get(page_url, headers=HEADERS, timeout=timeout)
        html = resp.text
        final = re.findall(r'https?://[^\s\'"<>]+?\.(?:m3u8|mpd|mp4)[^\s\'"<>]*', html)
        final =final[0]
        return final

    try:
        import cmf3
        if hasattr(cmf3, "run_dynamic_parse"):
            res = cmf3.run_dynamic_parse(page_url)
            if res:

                # wybierz pierwszy manifest-like
                for r in res:
                    final = normalize_url(r, page_url)
                    return final
    except:
        pass
# ==================================================
# ODTWARZANIE
# ==================================================
import re
import base64
import urllib.parse
import requests

HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
    "Referer": "https://kinoteka.cc/",
    "Origin": "https://kinoteka.cc"
}


def resolve_stream(url):

    try:

        # -------------------------------------------------
        # 1. obsługa proxy.php?url=
        # -------------------------------------------------
        if "proxy.php" in url:

            parsed = urllib.parse.urlparse(url)
            params = urllib.parse.parse_qs(parsed.query)

            if "url" in params:
                url = urllib.parse.unquote(params["url"][0])

        # -------------------------------------------------
        # 2. dekodowanie base64 jeśli wygląda na base64
        # -------------------------------------------------
        if re.match(r'^[A-Za-z0-9+/=]+$', url) and len(url) > 40:
            try:
                decoded = base64.b64decode(url).decode("utf-8")
                if decoded.startswith("http"):
                    url = decoded
            except:
                pass

        # -------------------------------------------------
        # 3. jeśli to bezpośredni stream
        # -------------------------------------------------
        if url.endswith(".m3u8") or url.endswith(".mpd") or url.endswith(".mp4"):
            return add_headers(url)

        # -------------------------------------------------
        # 4. pobranie strony / playlisty
        # -------------------------------------------------
        r = requests.get(url, headers=HEADERS, timeout=10)
        html = r.text

        # -------------------------------------------------
        # 5. szukamy m3u8
        # -------------------------------------------------
        m3u8 = re.search(r'https?://[^"\']+\.m3u8[^"\']*', html)

        if m3u8:
            return add_headers(m3u8.group(0))

        # -------------------------------------------------
        # 6. szukamy mpd (DASH)
        # -------------------------------------------------
        mpd = re.search(r'https?://[^"\']+\.mpd[^"\']*', html)

        if mpd:
            return add_headers(mpd.group(0))

        # -------------------------------------------------
        # 7. iframe player
        # -------------------------------------------------
        iframe = re.search(r'<iframe[^>]+src=["\']([^"\']+)', html)

        if iframe:
            iframe_url = urllib.parse.urljoin(url, iframe.group(1))


            return resolve_stream(iframe_url)

        # -------------------------------------------------
        # fallback
        # -------------------------------------------------
        xbmcgui.Dialog().textviewer('info2222', str(url))
        return add_headers(url)

    except Exception:
        return add_headers(url)


def add_headers(stream):

    headers = "|User-Agent=" + urllib.parse.quote(HEADERS["User-Agent"])
    headers += "&Referer=" + urllib.parse.quote(HEADERS["Referer"])
    headers += "&Origin=" + urllib.parse.quote(HEADERS["Origin"])

    return stream + headers


def resolve_s2tream(url):

    headers = {
        "User-Agent": "Mozilla/5.0",
        "Referer": "https://kinoteka.cc/"
    }

    try:

        # sprawdzamy czy to proxy
        if "proxy.php" in url:

            parsed = urllib.parse.urlparse(url)
            params = urllib.parse.parse_qs(parsed.query)

            if "url" in params:
                url = urllib.parse.unquote(params["url"][0])

        # pobieramy playlistę
        r = requests.get(url, headers=headers, timeout=10)

        if r.status_code == 200:

            text = r.text

            # szukamy prawdziwego streamu
            for line in text.splitlines():

                if line.startswith("#"):
                    continue

                if ".m3u8" in line:
                    real_stream = line.strip()

                    # jeśli link względny
                    if not real_stream.startswith("http"):
                        base = url.rsplit("/",1)[0]
                        real_stream = base + "/" + real_stream

                    return real_stream + "|User-Agent=Mozilla/5.0&Referer=https://kinoteka.cc/"

        # fallback
        return url + "|User-Agent=Mozilla/5.0"

    except Exception:
        return url



def play_channel(url, name=None):

    """Odtwarzanie w Kodi z obsługą inputstreamhelper."""




    name   = params.get("name")
    try:
        import sys
        handle = int(sys.argv[1])
        fi =resolve_stream(url)
        final= resolve_s2tream(fi)
##        final = extract_hls_from_page(url,name)
##
##        if not final:
##           if '/embed.html' in url:
##                final =url.replace('/embed.html','/index.m3u8')
##           if '/index.mpd' in url:
##                final =url
####           if 'gen.m3u8' in url:
####                final =url

        xbmcgui.Dialog().textviewer('info', str(final))

        # ustawienia listitem
        li = xbmcgui.ListItem(path=final)
        li.setInfo("video", {"title": name or final})
        li.setProperty("IsPlayable", "true")

        # HLS
        try:
            if ".m3u8" in final:
                li.setMimeType("application/vnd.apple.mpegurl")
                li.setContentLookup(False)
                try:
                    from inputstreamhelper import Helper
                    hls = Helper("hls")
                    if hls.check_inputstream():
                        li.setProperty("inputstream", hls.inputstream_addon)
                        li.setProperty("inputstream.adaptive.manifest_type", "hls")
                except Exception as e:
                    log(f"⚠️ inputstream HLS: {e}")
            elif ".mpd" in final:
                li.setMimeType("application/dash+xml")
                li.setContentLookup(False)
                try:
                    from inputstreamhelper import Helper
                    dash = Helper("mpd")
                    if dash.check_inputstream():
                        li.setProperty("inputstream", dash.inputstream_addon)
                        li.setProperty("inputstream.adaptive.manifest_type", "mpd")
                except Exception as e:
                    log(f"⚠️ inputstream MPD: {e}")
        except Exception:
            pass
        xbmc.sleep(300)
        xbmcplugin.setResolvedUrl(handle, True, li)
        return final   # <── DO co teraz


    except Exception as e:

        xbmcgui.Dialog().ok("Błąd odtwarzania", str(e))
