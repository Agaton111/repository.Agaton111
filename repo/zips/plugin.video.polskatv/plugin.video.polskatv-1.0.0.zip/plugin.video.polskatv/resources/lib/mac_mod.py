# -*- coding: utf-8 -*-
# mac_mod.py — zoptymalizowany, ultraszybkie TV, paginacja 800–2000 filmów, cache VOD

import os
import sys
import json
import time
import urllib.parse
import re
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
from datetime import datetime
import unicodedata
import xbmcvfs
import urllib.request

import urllib.parse
import threading


from resources.lib import mac_api_li

VOD_PORTAL_LIMIT = {}
HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]
ADDON = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo('path')

EPG_PATH = xbmcvfs.translatePath("special://userdata/addon_data/plugin.video.polskatv/epg.json")
HANDLE = int(sys.argv[1])

PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))

SLOTS_FILE = os.path.join(PROFILE, "slots.json")
##VOD_CACHE_TTL = 60*60*6
PAGE_SIZE = 60
ile_przyszlych = 2  # ilość przyszłych programów w opisie
##ACTIVE_VOD_CACHE_TTL = 60 * 30  # 30 minut
POSTER_CACHE = {}

params = dict(
    urllib.parse.parse_qsl(sys.argv[2][1:])
)

# ================================
# Pomocnicze funkcje
# ================================


def load_slots():
    if os.path.exists(SLOTS_FILE):
        try:
            with open(SLOTS_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except:
            return []
    return []


def normalize_mac_list(raw_input):
    if not raw_input:
        return []
    parts = re.split(r"[,\n;\s]+", raw_input)
    macs = []
    for part in parts:
        clean = part.strip().upper()
        clean = re.sub(r"[^0-9A-F]", "", clean)
        if len(clean) != 12:
            continue
        formatted = ":".join(clean[i:i+2] for i in range(0, 12, 2))
        macs.append(formatted)
    macs = list(dict.fromkeys(macs))
    return macs

def save_slots(slots):
    os.makedirs(os.path.dirname(SLOTS_FILE), exist_ok=True)
    with open(SLOTS_FILE, "w", encoding="utf-8") as f:
        json.dump(slots, f, ensure_ascii=False, indent=2)


        return
    mac = xbmcgui.Dialog().input("Podaj MAC")
    if not mac:
        return
    slots = load_slots()
    slots.append({"portal": portal.rstrip("/") + "/", "mac": mac.strip()})
    save_slots(slots)
    xbmcgui.Dialog().notification("Slot", "Dodano slot", xbmcgui.NOTIFICATION_INFO, 3000)


def normalize_title(text):
    if not text:
        return ""
    text = text.strip().replace("\u00a0", " ")
    cleaned = "".join(ch for ch in text if not unicodedata.category(ch).startswith("So"))
    return cleaned.upper().strip()

def strip_symbols(text):
    if not text:
        return ""
    return "".join(ch for ch in text if not unicodedata.category(ch).startswith(("So", "Sk", "Cs"))).strip()

def get_param(key, default=None):
    params_raw = urllib.parse.parse_qs(sys.argv[2][1:]) if len(sys.argv) > 2 else {}
    params = {k: v[0] for k, v in params_raw.items()}
    return params.get(key, default)



def add_dir(name, query, slot_index, icon_name=None):
    li = xbmcgui.ListItem(label=name)
    if icon_name:
        icon_path = os.path.join(ADDON_PATH, "resources", "media", icon_name)
        li.setArt({'icon': icon_path, 'thumb': icon_path})
    url = f"{BASE_URL}?action={query}&slot={slot_index}&list=mac_mod"
    xbmcplugin.addDirectoryItem(HANDLE, url, li, True)


def load_epg_json(slot_index=0):
    if not os.path.exists(EPG_PATH):
        return {"channels": [], "data": {}}
    try:
        with open(EPG_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    except:
        return {"channels": [], "data": {}}
_normalize_cache = {}
def _normalize(name):
    if not name:
        return ""

    if name in _normalize_cache:
        return _normalize_cache[name]

    n = name.upper()
    n = re.sub(r"\b(FHD|HD|SD|UHD|4K|HEVC|H265|PL|POL|RAW|POLSKA|VIP)\b","",n)
    n = re.sub(r"[.\-_/|]"," ",n)
    n = re.sub(r"[^A-Z0-9 ]","",n)
    n = re.sub(r"\s+"," ",n).strip()
    n = re.sub(r"([A-Z])([A-Z][a-z])", r"\1 \2", n)
    n = re.sub(r"([A-Z]{3,})([A-Z]{3,})", r"\1 \2", n)
    n = re.sub(r"([A-Z])(\d)", r"\1 \2", n)
    n = re.sub(r"(\d)([A-Z])", r"\1 \2", n)

    _normalize_cache[name] = n
    return n
def is_polish(name):
    if not name: return False
    n = name.upper().strip()
    m = re.match(r"^([A-Z]{2,3})\s*[\|\-]", n)
    if m and m.group(1) != "PL": return False
    blocked = ["PREMIER LEAGUE","CHELSEA","LIVE","MATCH","EVENT","STUDIO","NO SIGNAL","NO STREAM","OFFLINE","TEST","4K|"]
    if any(w in n for w in blocked): return False
    patterns = [r"\( *PL *\)", r"\[ *PL *\]", r"\| *PL *\|", r"\bPL\b", r"\bPOLSKI\b",
                r"\bLEKTOR *PL\b", r"\bPL *LEKTOR\b", r"\bDUB *PL\b", r"\bPL *DUB\b"]
    return any(re.search(p,n) for p in patterns)


def formatuj_opis(programy_list, kanal_name=""):
    if not programy_list: return f"[COLOR yellow]{kanal_name}[/COLOR]",""
    progs = sorted(programy_list, key=lambda p: p.get("start",""))
    teraz = datetime.now()
    teraz_prog = None
    przyszle = []
    for p in progs:
        try:
            start = datetime.fromisoformat(p["start"])
            stop = datetime.fromisoformat(p["stop"])
        except: continue
        if start <= teraz < stop:
            teraz_prog = p
        elif start > teraz and len(przyszle)<ile_przyszlych:
            przyszle.append(p)
    opis_lines = [f"[COLOR yellow]{kanal_name}[/COLOR]"]
    plakat=""
    def linia(prog):
        s = datetime.fromisoformat(prog["start"]).strftime("%H:%M")
        return f"[COLOR lime]{s}[/COLOR] - {prog.get('tytul','')}"
    if teraz_prog:
        opis_lines.append(linia(teraz_prog))
        if teraz_prog.get("opis"): opis_lines.append(teraz_prog["opis"])
        plakat = teraz_prog.get("plakat","")
    for p in przyszle: opis_lines.append(linia(p))
    return "\n".join(opis_lines).strip(), plakat


def build_epg_index(epg_data):
    return {_normalize(k): k for k in epg_data.keys()}

def get_epg_for_channel(channel_name, slot_index=0):
    epg_json = load_epg_json(slot_index)

    epg_data = epg_json.get("data", {})
    if not epg_data:
        return "", ""

    epg_index = build_epg_index(epg_data)

    norm_name = _normalize(channel_name)
    epg_key = epg_index.get(norm_name)

    if not epg_key:
        return "", ""

    programy = epg_data.get(epg_key, [])
    return formatuj_opis(programy, channel_name)


def _active_vod_cache_file(slot_index):
    profile = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
    return os.path.join(profile, f"active_vod_{slot_index}.json")

# ================================
# MENU / SLOTY
# ================================
def show_menu():
    slots = mac_api_li.load_slots()
    li = xbmcgui.ListItem(label="Dodaj slot (portal + MAC)")
    li.setArt({'icon': os.path.join(ADDON_PATH,"resources","media","dodaj1.png")})
    xbmcplugin.addDirectoryItem(HANDLE,f"{BASE_URL}?action=mac_add&list=mac_mod",li,False)
    if slots:
        li = xbmcgui.ListItem(label="Usuń slot")
        li.setArt({'icon': os.path.join(ADDON_PATH,"resources","media","kosz2.jpg")})
        xbmcplugin.addDirectoryItem(HANDLE,f"{BASE_URL}?action=mac_del&list=mac_mod",li,False)
    for i,slot in enumerate(slots):
        li = xbmcgui.ListItem(label=f"{slot['portal']}")
        li.setArt({'icon': os.path.join(ADDON_PATH,"resources","media","zapis.jpg")})
        url = f"{BASE_URL}?action=mac_enter&slot={i}&list=mac_mod"
        xbmcplugin.addDirectoryItem(HANDLE,url,li,True)
    xbmcplugin.endOfDirectory(HANDLE)

def enter_slot():
    slot_index = int(get_param("slot", 0))
    try:
        mac_api_li.save_tv_categories(slot_index)
    except Exception as e:
        xbmc.log(f"[TV SAVE ERROR] {e}", xbmc.LOGERROR)

    slot = mac_api_li.resolve_slot_mac(slot_index)
    if not slot: return
    add_dir("TELEWIZJA","list_tv_categories",slot_index,"tv_all.png")
    add_dir("FILMY","list_vod_categories",slot_index,"film_all.png")
    add_dir("Zarządzaj MAC", "mac_manage", slot_index, "repair.png")
    xbmcplugin.endOfDirectory(HANDLE)


# ================================
# TV LIST (ULTRASZYBKIE)
# ================================
def list_tv_categories():
    slot_index = int(get_param("slot", 0))

    # jeśli nie ma pliku – zapisz raz
    categories = mac_api_li.load_tv_kateg_cache(slot_index)
    if not categories:
        mac_api_li.save_tv_categories(slot_index)
        categories = mac_api_li.load_tv_kateg_cache(slot_index)

    if not categories:
        xbmcgui.Dialog().notification("TV", "Brak kategorii")
        xbmcplugin.endOfDirectory(HANDLE)
        return

    # 1️⃣ Wszystkie Kategorie
    url_all = f"{BASE_URL}?action=mac_list_real_categories&slot={slot_index}&mode=ALL&list=mac_mod"
    li_all = xbmcgui.ListItem(label="Wszystkie Kategorie")
    li_all.setArt({'icon': os.path.join(ADDON_PATH,"resources","media","tv_all.png")})
    xbmcplugin.addDirectoryItem(HANDLE, url_all, li_all, True)

    # 2️⃣ Kategorie PL
    url_pl = f"{BASE_URL}?action=mac_list_real_categories&slot={slot_index}&mode=PL&list=mac_mod"
    li_pl = xbmcgui.ListItem(label="Kategorie PL")
    li_pl.setArt({'icon': os.path.join(ADDON_PATH,"resources","media","tv_pl.png")})
    xbmcplugin.addDirectoryItem(HANDLE, url_pl, li_pl, True)
    xbmcplugin.endOfDirectory(HANDLE)


def list_real_categories():
    slot_index = int(get_param("slot", 0))
    mode = get_param("mode", "ALL")

    categories = mac_api_li.load_tv_kateg_cache(slot_index)

    if not categories:
        xbmcgui.Dialog().notification("TV", "Brak zapisanych kategorii")
        xbmcplugin.endOfDirectory(HANDLE)
        return

    blocked_words = ["SWEDEN", "DENMARK", "NORWAY", "FINLAND", "NL|", "FR|", "US|", "UK|","NO EVENT STREAMING"]

    # 🔥 wszystkie dozwolone znaczniki PL
    PL_PATTERNS = [
        r"\bPL\b",
        r"\|PL\|",
        r"\(PL\)",
        r"\[PL\]",
        r"┃PL┃",
        r"^POLAND$",
        r"^POLSKA",


    ]

    for cat in categories:
        title = cat.get("title", "")
        cat_id = str(cat.get("id"))
        title_upper = title.upper().strip()

        # 🔵 TRYB PL – filtruj tylko polskie
        if mode == "PL":

            # blokada krajów
            if any(word in title_upper for word in blocked_words):
                continue

            # musi pasować do któregoś wzorca PL
            if not any(re.search(pattern, title_upper) for pattern in PL_PATTERNS):
                continue


        url = f"{BASE_URL}?action=mac_show_items&slot={slot_index}&cat={cat_id}&list=mac_mod"

        li = xbmcgui.ListItem(label=title)

        # 🔵 Ikona PL
        if any(re.search(pattern, title_upper) for pattern in PL_PATTERNS):
            icon_name = "tv_pl.png"
        else:
            icon_name = "tv_all.png"

        icon_path = os.path.join(ADDON_PATH, "resources", "media", icon_name)
        li.setArt({'icon': icon_path, 'thumb': icon_path})

        xbmcplugin.addDirectoryItem(HANDLE, url, li, True)

    xbmcplugin.endOfDirectory(HANDLE)


##
def show_items():    # DLA TV
    slot_index = int(get_param("slot", 0))
    cat = get_param("cat", "")

    if not cat:
        xbmcplugin.endOfDirectory(HANDLE)
        return

    items = []

    # ================================
    # 1️⃣ KONKRETNA KATEGORIA
    # ================================
    if cat not in ("ALL", "PL"):
        items = mac_api_li.get_channels_by_genre(slot_index, cat) or []
    else:
        xbmcgui.Dialog().notification(
            "TV",
            "Wybierz konkretną kategorię"
        )
        xbmcplugin.endOfDirectory(HANDLE)
        return

    if not items:
        xbmcgui.Dialog().notification("TV", "Brak kanałów")
        xbmcplugin.endOfDirectory(HANDLE)
        return
    # ==========================================
    # 🔥 EPG ŁADOWANE TYLKO RAZ (NAJWAŻNIEJSZE)
    # ==========================================
    epg_json = load_epg_json(slot_index)
    epg_data = epg_json.get("data", {})
    epg_index = build_epg_index(epg_data) if epg_data else {}

    seen = set()
    directory_items = []

    EXCLUDED_WORDS = (
        "NO EVENT",
        "NO SIGNAL",
        "TEST",
        "BRAK SYGNAŁU"
    )

    for item in items:
        name = (item.get("name") or "").strip()
        if any(word in name.upper() for word in EXCLUDED_WORDS):
            continue
        cmd = item.get("cmd")

        if not name or not cmd or cmd in seen:
            continue

        seen.add(cmd)

        # ================================
        # ⚡ SZYBKIE EPG (bez ponownego czytania pliku)
        # ================================
        opis = ""
        plakat = ""

        if epg_data:
            norm_name = _normalize(name)
            epg_key = epg_index.get(norm_name)

            if epg_key:
                programy = epg_data.get(epg_key, [])
                opis, plakat = formatuj_opis(programy, name)

        logo = item.get("logo") or item.get("screenshot_uri")

        cmd_enc = urllib.parse.quote(cmd, safe='')
        li = xbmcgui.ListItem(label=name)

        li.setInfo("video", {"plot": opis})

        if plakat:
            art = plakat
        elif logo:
            art = logo
        else:
            art = os.path.join(ADDON_PATH, "resources", "media", "plakat.jpg")

        li.setArt({
            "thumb": art,
            "icon": art,
            "poster": art
        })
        li.addContextMenuItems([
            ("Otwórz przez proxy", f"RunPlugin({BASE_URL}?action=mac_play_proxy&cmd={cmd_enc}&slot={slot_index}&list=mac_mod)")
        ])

        li.setProperty("IsPlayable", "true")

        name_enc = urllib.parse.quote(name)

        play_url = (
            f"{BASE_URL}?action=mac_play"
            f"&cmd={cmd_enc}"
            f"&name={name_enc}"
            f"&slot={slot_index}"
            f"&list=mac_mod"
        )
        directory_items.append((play_url, li, False))

    xbmcplugin.addDirectoryItems(HANDLE, directory_items, len(directory_items))
    xbmcplugin.endOfDirectory(HANDLE)



# VOD (BEZ ZMIAN)
# ================================
def list_vod_categories():
    slot_index = int(get_param("slot", 0))
    show_vod_groups()

def show_vod_groups():
    slot_index = int(get_param("slot", 0))
    pl_mode = get_param("pl_mode")
    categories = mac_api_li.get_categories(slot_index, "vod") or []

    def is_pl_category(title):
        t = title.upper()
        patterns = ["[PL]", "(PL)", "|PL|", " PL ", ".PL", "PL ","POLAND","POLSKA"]
        return any(p in t for p in patterns)

    categories.sort(key=lambda x: (0 if is_pl_category(x["title"]) else 1, x["title"].upper()))
    all_pl_entry={"id":"__ALL_PL__","title":"ALL Ukryte PL, jak są to pojedyncze, przeważnie brak.","icon":"film_pl.png"}

    for cat in categories:
        cat_id,title=cat.get("id"),cat.get("title","")
        if not cat_id: continue
        if cat_id=="__ALL_PL__":
            url=f"{BASE_URL}?action=mac_show_vod_titles&slot={slot_index}&vod_cat=0&all=1&pl_mode=PL&page=1&list=mac_mod"
        else:
            url=f"{BASE_URL}?action=mac_show_vod_titles&slot={slot_index}&vod_cat={cat_id}&pl_mode={pl_mode}&page=1&list=mac_mod"
        t=title.upper()
        icon="film_pl.png" if "|PL|" in t or t.startswith("PL") or "[PL]" in t or "POLSKa" in t or "POLAND" in t else "film_all.png"
        li=xbmcgui.ListItem(label=strip_symbols(title))
        icon_path=os.path.join(ADDON_PATH,"resources","media",icon)
        li.setArt({'icon':icon_path,'thumb':icon_path})

        li.setPath(path=url)
        xbmcplugin.addDirectoryItem(HANDLE,url,li,True)
    xbmcplugin.endOfDirectory(HANDLE)

def show_vod_titles_paged():
    slot_index = int(get_param("slot", 0))

    slot = mac_api_li.get_slot(slot_index)
    portal = slot.get("portal", "")

    add_item = xbmcplugin.addDirectoryItem

    vod_cat=get_param("vod_cat")
    slot_index=int(get_param("slot",0))
    pl_mode=get_param("pl_mode")
    page=int(get_param("page",1))

    media_path=os.path.join(ADDON_PATH,"resources","media")
    fallback_poster=os.path.join(media_path,"camera.jpg")

    # ALL PL
    if vod_cat=="__ALL_PL__":
        all_items=mac_api_li.get_vod_list(slot_index,None) or []
        filtered=[i for i in all_items if is_polish(i.get("name",""))]
        total=len(filtered)
        total_pages=max(1,(total+PAGE_SIZE-1)//PAGE_SIZE)
        page=max(1,min(page,total_pages))
        start=(page-1)*PAGE_SIZE
        end=start+PAGE_SIZE
        items=filtered[start:end]
    else:
        first_items,total,portal_page_size=mac_api_li.get_vod_page(slot_index,vod_cat,1)
        if total==0:
            xbmcgui.Dialog().notification("VOD","Kategoria pusta")
            xbmcplugin.endOfDirectory(HANDLE,updateListing=True)
            return
        if portal_page_size<=0: portal_page_size=1

        pages_to_fetch = min(3, max(1, PAGE_SIZE // portal_page_size))


        start_portal_page=(page-1)*pages_to_fetch+1
        items=[]
        for p in range(start_portal_page, start_portal_page + pages_to_fetch):
            time.sleep(0.15)
            page_items = []
            for _ in range(2):
                page_items, _, _ = mac_api_li.get_vod_page(slot_index, vod_cat, p)
                if page_items:
                    break
                xbmc.sleep(300)

            if not page_items:
                break
            items.extend(page_items)

            if len(items) >= PAGE_SIZE:
                break



        if pl_mode=="PL":
            items=[i for i in items if is_polish(i.get("name",""))]
        items=items[:PAGE_SIZE]
        total_pages=max(1,(total+PAGE_SIZE-1)//PAGE_SIZE)

    # MENU INFO
    info_url=f"{BASE_URL}?action=mac_show_vod_titles&slot={slot_index}&vod_cat={vod_cat}&pl_mode={pl_mode}&page=1&list=mac_mod"
    li_info=xbmcgui.ListItem(label=f"Strona {page} z {total_pages} | {total} pozycji (powrót do strony 1)")
    li_info.setProperty("IsPlayable","false")
    li_info.setArt({'icon':os.path.join(media_path,"list1.png"),'thumb':os.path.join(media_path,"list1.png")})
    xbmcplugin.addDirectoryItem(HANDLE,info_url,li_info,True)

    # POPRZEDNIA STRONA
    if page>1:
        prev_url=f"{BASE_URL}?action=mac_show_vod_titles&slot={slot_index}&vod_cat={vod_cat}&pl_mode={pl_mode}&page={page-1}&list=mac_mod"
        li_prev=xbmcgui.ListItem(label="◀ Poprzednia strona")
        li_prev.setArt({'icon':os.path.join(media_path,"list3.png"),'thumb':os.path.join(media_path,"list3.png")})
        xbmcplugin.addDirectoryItem(HANDLE,prev_url,li_prev,True)

    # LISTA FILMÓW
    for item in items:
        if not isinstance(item,dict): continue
        cmd=item.get("cmd") or ""
        if not cmd: continue
        name=item.get("name") or "???"
        description=item.get("description") or ""
        li=xbmcgui.ListItem(label=name)
        cmd_enc = urllib.parse.quote(cmd)

        li.addContextMenuItems([
            ("Otwórz przez proxy",
             f"RunPlugin({BASE_URL}?action=mac_play_proxy&cmd={cmd_enc}&slot={slot_index}&list=mac_mod)")
        ])

        li.setProperty("IsPlayable","true")
        li.setInfo("video",{"title":name,"plot":description})



        poster = item.get("poster") or item.get("screenshot_uri")
        bad_hosts = ["jinbox.eu"]
        if any(h in poster for h in bad_hosts):
            poster = fallback_poster

        if not poster:
            poster = fallback_poster
        elif poster.startswith("/"):
            poster = portal + poster


        li.setArt({'icon':poster,'thumb':poster})

        name_enc = urllib.parse.quote(name)

        play_url=(
            f"{BASE_URL}?action=mac_play"
            f"&cmd={urllib.parse.quote(cmd)}"
            f"&name={name_enc}"
            f"&slot={slot_index}"
            f"&list=mac_mod"
        )

        add_item(HANDLE, play_url, li, False)

    # NASTĘPNA STRONA
    if page<total_pages:
        next_url=f"{BASE_URL}?action=mac_show_vod_titles&slot={slot_index}&vod_cat={vod_cat}&pl_mode={pl_mode}&page={page+1}&list=mac_mod"
        li_next=xbmcgui.ListItem(label="Następna strona ▶")
        li_next.setArt({'icon':os.path.join(media_path,"list2.png"),'thumb':os.path.join(media_path,"list2.png")})
        xbmcplugin.addDirectoryItem(HANDLE,next_url,li_next,True)

    xbmcplugin.endOfDirectory(HANDLE,updateListing=True)

# ================================
# PLAY / PROXY
# ================================


def mac_play(cmd, use_proxy=False):
    from resources.lib.simple_proxy import start_proxy
    name = params.get("name")
    name = urllib.parse.unquote(name) if name else None

    slot_index = int(get_param("slot", 0))
    cmd = urllib.parse.unquote(cmd).strip()
    xbmc.log(f"[MAC_PLAY] ORIGINAL CMD = {cmd}", xbmc.LOGINFO)

    # 🔹 Obsługa FFMPEG prefix
    if cmd.startswith("ffmpeg "):
        cmd = cmd[7:].strip()
        xbmc.log("[MAC_PLAY] STRIPPED FFMPEG PREFIX", xbmc.LOGINFO)

    # ==========================================
    # USTALENIE TYPU (RAZ — BEZ ZMIANY W RETRY)
    # ==========================================

    if cmd.startswith("http"):
        if "/ch/" in cmd:
            content_type = "itv"
        else:
            content_type = None
    else:
        content_type = "vod"

    # ==========================================
    # ROZWIĄZANIE STRUMIENIA
    # ==========================================

    if content_type:
        stream_url = mac_api_li.get_stream_url(cmd, slot_index, content_type)
    else:
        stream_url = cmd

    # 🔹 Minimalny retry (tylko 1)
    if not stream_url and content_type:
        xbmc.log("[MAC_PLAY] RETRY resolve", xbmc.LOGINFO)
        xbmc.sleep(700)
        stream_url = mac_api_li.get_stream_url(cmd, slot_index, content_type)

    if not stream_url:
        xbmc.log(f"[MAC_PLAY] STREAM_URL EMPTY cmd={cmd}", xbmc.LOGERROR)
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return

    # 🔹 Pobierz aktywną sesję (cookiejar)
    slot = mac_api_li.get_slot(slot_index)
    portal = slot["portal"]
    mac_addr = slot["mac"]

    opener, cookiejar = mac_api_li.get_session(portal, mac_addr)

    # 🔹 Zbuduj Cookie header z aktualnej sesji
    cookie_string = "; ".join(
        f"{c.name}={c.value}" for c in cookiejar
    )

    # 🔹 Referer jak w prawdziwym MAG
    referer = portal.rstrip("/") + "/c/"

    header_string = (
        f"Cookie={urllib.parse.quote(cookie_string)}&"
        f"Referer={urllib.parse.quote(referer)}&"
        f"User-Agent={urllib.parse.quote('Mozilla/5.0 (QtEmbedded; U; Linux; C) MAG254')}"
    )

    final_stream = stream_url.split("|")[0]

    final_url = final_stream


    if use_proxy:
        encoded_url = urllib.parse.quote_plus(final_url)

        f4m_proxy_url = (
            f"plugin://plugin.video.f4mTesterAG/"
            f"?streamtype=TSDOWNLOADER&name=test&url={encoded_url}"
        )


        xbmc.log(f"[MAC_PLAY] FINAL STREAM via F4mProxy = {f4m_proxy_url}", xbmc.LOGINFO)

        xbmc.executebuiltin(f'RunPlugin({f4m_proxy_url})')
        return

    else:

        # Odtwarzanie bez proxy

        final_url_with_headers = f"{final_stream}|{header_string}"

        li = xbmcgui.ListItem(label=name or "Odtwarzanie", path=final_url_with_headers)
        li.setInfo("video", {"title": name or "Odtwarzanie"})
        li.setProperty("IsPlayable", "true")
        li.setContentLookup(False)




        if content_type == "itv":
            li.setProperty("inputstream", "inputstream.ffmpegdirect")
            li.setProperty("inputstream.ffmpegdirect.buffer_size", "20971520")
            li.setProperty("inputstream.ffmpegdirect.stream_mode", "live")
            li.setMimeType("video/mp2t")

        else:
            li.setProperty("inputstream", "inputstream.ffmpegdirect")
            li.setProperty("inputstream.ffmpegdirect.buffer_size", "20971520")
            li.setProperty("inputstream.ffmpegdirect.stream_mode", "default")

            # 🔥 FINALNA POPRAWKA (VOD ONLY) — TUTAJ
            li.setProperty("inputstream.ffmpegdirect.reconnect", "true")
            li.setProperty("inputstream.ffmpegdirect.reconnect_streamed", "true")
            li.setProperty("inputstream.ffmpegdirect.reconnect_delay_max", "5")
            li.setProperty("inputstream.ffmpegdirect.timeout", "10000000")

            # opcjonalnie testowo:
            # li.setMimeType("video/mp4")

        xbmcplugin.setResolvedUrl(HANDLE, True, li)

