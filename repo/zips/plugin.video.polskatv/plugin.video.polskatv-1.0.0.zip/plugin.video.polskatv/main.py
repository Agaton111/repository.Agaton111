# -*- coding: utf-8 -*-

#####################    main.py
import xbmc
import xbmcgui
import xbmcplugin
import sys
import os
import json
import importlib
import urllib.parse
import xbmcvfs
import gzip
import xbmcaddon

import xml.etree.ElementTree as ET
from datetime import datetime, timedelta
import requests
import traceback
from collections import defaultdict
from resources.lib import mac_mod
from resources.lib import mac_api_li

##from resources.lib.proxy_live import start_live_proxy
##start_live_proxy()

params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
ADDON = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo('path')

# ======================

# --- Naprawa ścieżki importów (dla cmf3, helperów itp.) ---

# Przechowuje tymczasowo listy kanałów
TEMP_CHANNELS = {}

addon_path = xbmcaddon.Addon().getAddonInfo('path')
lib_path = os.path.join(addon_path, 'resources', 'lib')
if lib_path not in sys.path:
    sys.path.append(lib_path)

##import resources.lib.mac_mod as mac_mod


# ----------------------------------------------------------

URL2 = "https://epg.ovh/pl.gz"


def get_addon():
    return xbmcaddon.Addon()

def get_addon_id():
    return get_addon().getAddonInfo("id")

ADDON_ID = get_addon_id()

ADDON_NAME = "[PolskaTV]"
BASE_URL = sys.argv[0]

HANDLE = int(sys.argv[1])


FOLDER = xbmcvfs.translatePath(f"special://profile/addon_data/{ADDON_ID}")
if not os.path.exists(FOLDER):
    os.makedirs(FOLDER, exist_ok=True)

KANALY_ZRODLA = {}

def log(msg):
    xbmc.log(f"{ADDON_NAME} {msg}", xbmc.LOGINFO)

try:
    xbmc.log(f"[PolskaTV DEBUG] startup sys.argv: {sys.argv}", xbmc.LOGINFO)
except Exception:
    pass

# dodatkowy  log w addon_data
try:
    prof = xbmcvfs.translatePath(f"special://profile/addon_data/{xbmcaddon.Addon().getAddonInfo('id')}")
    if not xbmcvfs.exists(prof):
        xbmcvfs.mkdirs(prof)
    dbgfile = os.path.join(prof, "router_debug.txt")
    with xbmcvfs.File(dbgfile, "a") as f:
        f.write(f"\n--- STARTUP {str(datetime.now())} ---\n")
        f.write(f"sys.argv: {repr(sys.argv)}\n")
except Exception:
    # nie przerywamy działania dodatku jeśli to się nie uda
    xbmc.log("[PolskaTV DEBUG] nie udało się zapisać debug pliku", xbmc.LOGWARNING)
# --- DEBUG END ---


# === LISTY DOSTĘPNYCH MODUŁÓW ===
LISTS = [
    {"id": "polskie_tv", "name": "Polskie TV", "desc": "Kanały z TVP i Megogo"},
    {"id": "nowy_test_tv", "name": "Test różnych stron TV", "desc": "Proba szukania linkow ze stron, tworzy cache"},
    {"id": "wizja_tv", "name": "Test strony Wizja cc", "desc": "Proba szukania linkow ze stront wizja cc"},
##    {"id": "kinoteka_tv", "name": "Test strony kinoteka cc", "desc": "Proba szukania linkow ze stront kinoteka cc"},
    {"id": "channels", "name": "Lista 1", "desc": "Kanały z listy lokalnej"},
    {"id": "change_m3u", "name": "Wybierz listę M3U8", "desc": "Wybierz lokalizację listy z dysku"},
    {"id": "channels2", "name": "Wczytaj listę M3U8", "desc": "Wczytaj kanały z listy M3U8 (dysk / URL)"},
    {"id": "YouTube_test", "name": "YouTube", "desc": "Kanały YouTube (bez cache)"},
    {"id": "polskie_tvn", "name": "TV Kanały TVN", "desc": "Kanały TVN"},
    {"id": "Clear_nowy_test", "name": "Usuń cache", "desc": "", "type": "action"},
##    {"id": "channels_prosta", "name": "Lista prostych linkow", "desc": "Linki działające np. w VLC"},
    {"id": "co_teraz", "name": "Co teraz w TV", "desc": "Programy aktualnie w telewizji"},
    {"id": "mac_mod", "name": "Kanały z MAC ", "desc": ""},
    {"id": "otworz_kanal", "name": "otworz kanał tv", "desc": ""},

]
def list_lists():
    for l in LISTS:
        handle = int(sys.argv[1])
        li = xbmcgui.ListItem(label=l["name"], label2=l["desc"])
        li.setInfo("video", {"title": l["name"], "plot": l["desc"]})
        icon_path = os.path.join(ADDON_PATH, "resources", "media", "folder1.png")
        li.setArt({'icon': icon_path, 'thumb': icon_path})

        url = f"{BASE_URL}?action=open_list&list={l['id']}"
##        xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=li, isFolder=True)
        xbmcplugin.addDirectoryItem(HANDLE, url, li, True)
    xbmcplugin.endOfDirectory(handle)



# === EPG FUNKCJA ===
def epg_lista(lista_kanalow: list, ile_przyszlych: int = 4):


    CACHE = {"generated": None, "data": {}, "channels": []}

    def pobierz_i_zapisz():
        """Pobiera plik gz, rozpakowuje, zapisuje epg.json i ładuje do CACHE"""
        try:
            xbmcgui.Dialog().notification(
                heading="EPG",
                message="Pobieram dane EPG...",
                icon=xbmcgui.NOTIFICATION_WARNING,
                time=2500,
                sound=False
            )

            sciezka_gz = os.path.join(FOLDER, "epg.gz")
            sciezka_xml = os.path.join(FOLDER, "epg.xml")
            sciezka_json = os.path.join(FOLDER, "epg.json")

            r = requests.get(URL2, timeout=60, headers={"User-Agent": "Kodi/EPG"})
            r.raise_for_status()
            with open(sciezka_gz, "wb") as f:
                f.write(r.content)

            with gzip.open(sciezka_gz, "rb") as f_in, open(sciezka_xml, "wb") as f_out:
                f_out.write(f_in.read())

            tree = ET.parse(sciezka_xml)
            root = tree.getroot()

            id2name = {}
            for ch in root.findall("channel"):
                cid = ch.attrib.get("id")
                dn = ch.find("display-name")
                if cid and dn is not None and dn.text:
                    id2name[cid] = dn.text.strip()

            data = {}
            for prog in root.findall("programme"):
                cid = prog.attrib.get("channel")
                display = id2name.get(cid)
                if not display:
                    continue
                key = display.lower().strip()

                start_raw = prog.attrib.get("start", "")[:14]
                stop_raw = prog.attrib.get("stop", "")[:14]
                try:
                    start_dt = datetime.strptime(start_raw, "%Y%m%d%H%M%S")
                    stop_dt = datetime.strptime(stop_raw, "%Y%m%d%H%M%S")
                except Exception:
                    continue

                tytul = prog.findtext("title", default="").strip()
                kategoria = prog.findtext("category", default="").strip()
                opis = prog.findtext("desc", default="").strip()
                ikona = prog.find("icon")
                plakat = ikona.attrib.get("src") if ikona is not None and "src" in ikona.attrib else ""

                data.setdefault(key, []).append({
                    "start": start_dt.isoformat(),
                    "stop": stop_dt.isoformat(),
                    "tytul": tytul,
                    "kategoria": kategoria,
                    "opis": opis,
                    "plakat": plakat
                })

            dane_json = {
                "generated": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "channels": [id2name[cid] for cid in id2name],
                "data": data
            }
            with open(sciezka_json, "w", encoding="utf-8") as f:
                json.dump(dane_json, f, ensure_ascii=False, indent=2)

            for tmp in ("epg.gz", "epg.xml"):
                try:
                    os.remove(os.path.join(FOLDER, tmp))
                except Exception:
                    pass

            xbmcgui.Dialog().notification(
                heading="EPG",
                message="EPG pobrane i zapisane.",
                icon=xbmcgui.NOTIFICATION_INFO,
                time=2000,
                sound=False
            )

            CACHE["generated"] = dane_json["generated"]
            CACHE["data"] = dane_json["data"]
            CACHE["channels"] = dane_json["channels"]
            return True

        except Exception as e:
            xbmcgui.Dialog().notification(
                heading="EPG",
                message=f"Problem z pobraniem EPG: {e}",
                icon=xbmcgui.NOTIFICATION_ERROR,
                time=4000,
                sound=False
            )
            return False

    def ensure_data_fresh():
        """Ładuje z cache/json albo pobiera nowe dane"""
        if CACHE.get("generated"):
            try:
                gen = datetime.strptime(CACHE["generated"], "%Y-%m-%d %H:%M:%S")
                if datetime.now() - gen < timedelta(days=2):
                    return True
            except Exception:
                pass

        sciezka_json = os.path.join(FOLDER, "epg.json")
        if os.path.exists(sciezka_json):
            try:
                mtime = datetime.fromtimestamp(os.path.getmtime(sciezka_json))
                if datetime.now() - mtime < timedelta(days=2):
                    with open(sciezka_json, "r", encoding="utf-8") as f:
                        dane = json.load(f)
                    CACHE["generated"] = dane.get("generated")
                    CACHE["data"] = dane.get("data", {})
                    CACHE["channels"] = dane.get("channels", [])
                    return True
            except Exception:
                pass

        return pobierz_i_zapisz()

    def dopasuj_nazwe_epg(nazwa_kanalu: str, data_dict: dict):
        """Dopasowuje nazwę kanału do danych EPG (z obsługą aliasów i uproszczeń)."""
        klucz = nazwa_kanalu.lower().strip()

        alias_file = os.path.join(FOLDER, "epg_alias.json")
        aliasy = {}
        if not os.path.exists(alias_file):
            with open(alias_file, "w", encoding="utf-8") as f:
                json.dump(
                    {"TVP 1 HD": "TVP 1", "TVP 2 HD": "TVP 2", "Polsat Film HD": "Polsat Film"},
                    f,
                    ensure_ascii=False,
                    indent=2
                )
        else:
            try:
                with open(alias_file, "r", encoding="utf-8") as f:
                    aliasy = json.load(f)
            except:
                pass

        # dopasowanie przez alias
        if nazwa_kanalu in aliasy:
            alias = aliasy[nazwa_kanalu].lower().strip()
            if alias in data_dict:
                return alias

        # dokładne dopasowanie
        if klucz in data_dict:
            return klucz

        # uproszczenie nazw
        klucz_simpl = (
            klucz.replace(" hd", "")
            .replace(" pl", "")
            .replace("PL:", "")
            .replace("(polska)", "")
            .replace("(pol)", "")
            .replace("polska", "")
            .replace("online", "")
            .replace("Eurosport 1", "Eurosport")
            .replace("(polskie_tvn)", "")
            .replace("(nowy_test_tv)", "")
            .replace("(polskie_tv)", "")
            .replace("(wizja_tv)", "")
            .replace("(kinoteka_tv)", "")

            .strip()
        )
        if klucz_simpl in data_dict:
            return klucz_simpl

##        # częściowe dopasowanie
##        for k in data_dict.keys():
##            if klucz_simpl in k or k in klucz_simpl:
##                return k

        # dopasowanie po usunięciu spacji
        klucz_no_space = klucz_simpl.replace(" ", "")
        for k in data_dict.keys():
            if klucz_no_space == k.replace(" ", ""):
                return k

        return None

    def formatuj_opis(programy_list):
        """Buduje opis i wybiera plakat; tylko godziny mają kolor zielony."""
        if not programy_list:
            return "", ""

        progs = sorted(programy_list, key=lambda p: p["start"])
        teraz = datetime.now()
        teraz_prog = None
        przyszle = []

        for p in progs:
            try:
                start = datetime.fromisoformat(p["start"])
                stop = datetime.fromisoformat(p["stop"])
            except Exception:
                continue
            if start <= teraz < stop:
                teraz_prog = p
            elif start > teraz and len(przyszle) < ile_przyszlych:
                przyszle.append(p)

        opis_lines = []
        plakat = ""

        def linia(prog):
            s = datetime.fromisoformat(prog["start"]).strftime("%H:%M")
            # tylko godzina w kolorze
            return f"[COLOR lime]{s}[/COLOR] - {prog.get('tytul', '')}"

        if teraz_prog:
            opis_lines.append(linia(teraz_prog))
            if teraz_prog.get("opis"):
                opis_lines.append(teraz_prog["opis"])
            plakat = teraz_prog.get("plakat", "")

        for p in przyszle:
            opis_lines.append(linia(p))

        return "\n".join(opis_lines).strip(), plakat

    # ===== logika główna =====
    if not ensure_data_fresh():
        for kanal in lista_kanalow:
            yield {"nazwa": kanal, "opis": kanal, "plakat": ""}
        return

    for kanal in lista_kanalow:
        key = dopasuj_nazwe_epg(kanal, CACHE.get("data", {}))
        prog_list = CACHE.get("data", {}).get(key) if key else None

        if not prog_list:
            yield {"nazwa": kanal, "opis": kanal, "plakat": ""}
            continue

        opis, plakat = formatuj_opis(prog_list)
        yield {"nazwa": kanal, "opis": opis or kanal, "plakat": plakat or ""}

# === LISTA KANAŁÓW ===
def list_channels(module_name):
    """
    Ładuje kanały z modułu, grupuje po nazwie, pobiera EPG i zapisuje źródła do pliku.
    """
    global KANALY_ZRODLA

    if module_name == "change_m3u":
        handle = int(sys.argv[1])

        change_m3u_file()
        xbmcplugin.endOfDirectory(handle)
        return

    try:
        mod = importlib.import_module(f"resources.lib.{module_name}")
        channels = getattr(mod, "CHANNELS", [])
    except Exception as e:
        handle = int(sys.argv[1])

        xbmcgui.Dialog().notification("Błąd", f"Nie można załadować {module_name}: {e}", xbmcgui.NOTIFICATION_ERROR)
##        log(f"list_channels import error: {e}")
        xbmcplugin.endOfDirectory(handle)
        return

    if not channels:
        handle = int(sys.argv[1])

        xbmcgui.Dialog().ok("Brak kanałów", f"Moduł {module_name} nie zawiera listy CHANNELS.")
        xbmcplugin.endOfDirectory(handle)
        return

    # ===== GRUPOWANIE KANAŁÓW =====
    grupy = defaultdict(list)
    for ch in channels:
        nazwa = (ch.get("name") or "").strip()
        url = (ch.get("url") or "").strip()
        icon = ch.get("icon") or ""
        if not nazwa or not url:
            continue
        grupy[nazwa].append({"module": module_name, "url": url, "icon": icon})

    KANALY_ZRODLA = grupy

    # zapisujemy źródła do pliku, żeby play_channel mogło je odczytać
    try:
        with open(os.path.join(FOLDER, "sources.json"), "w", encoding="utf-8") as f:
            json.dump(KANALY_ZRODLA, f, ensure_ascii=False, indent=2)
    except Exception as e:
        log(f"Nie udało się zapisać źródeł: {e}")

    # lista unikalnych kanałów
    unikalne = []
    for nazwa, zrodla in grupy.items():
        pierwszy = zrodla[0]
        unikalne.append({"name": nazwa, "url": pierwszy["url"], "icon": pierwszy["icon"]})

    # ===== POBIERZ EPG =====
    try:
        epg_map = {e["nazwa"]: e for e in epg_lista([u["name"] for u in unikalne])}
    except Exception as e:
        log(f"EPG error: {e}")
        epg_map = {}

    # ===== WYŚWIETLENIE W KODI =====
    for ch in unikalne:
        name = ch["name"]
        icon = ch.get("icon", "")

        epg_info = epg_map.get(name, {})
        opis = epg_info.get("opis") or name
##        plakat = epg_info.get("plakat") or icon or ""

        plakat_epg = epg_info.get("plakat")

        if plakat_epg and plakat_epg.startswith(("http://", "https://")):
            plakat = plakat_epg
        else:
            plakat = icon or  os.path.join(ADDON_PATH, "resources", "media", "brak.png")

        li = xbmcgui.ListItem(label=name, label2=opis)
        li.setInfo("video", {"title": name, "plot": opis})
        li.setProperty("IsPlayable", "true")
        li.setArt({"thumb": plakat, "icon": plakat, "fanart": plakat})

        play_url = f"{BASE_URL}?action=play_channel&name={urllib.parse.quote(name)}"
        xbmcplugin.addDirectoryItem(HANDLE, play_url, li, isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE)


def play_channel(nazwa):
    """
    Odczytuje źródła z pliku sources.json i odtwarza kanał.
    """
    global KANALY_ZRODLA
    key = nazwa.strip()

    # spróbuj najpierw z pamięci
    sources = KANALY_ZRODLA.get(key)

    # jeśli puste – odczytaj z pliku
    if not sources:
        try:
            with open(os.path.join(FOLDER, "sources.json"), "r", encoding="utf-8") as f:
                data = json.load(f)
            sources = data.get(key) or data.get(nazwa)
        except Exception as e:
            log(f"Nie udało się odczytać sources.json: {e}")

    if not sources:
        xbmcgui.Dialog().notification("Odtwarzanie", "Brak źródeł dla kanału", xbmcgui.NOTIFICATION_INFO, 2500)
        return

    # jeden link → odtwarzaj
    if len(sources) == 1:
        s = sources[0]
        play_video(s.get("module"), s.get("url"), nazwa)
        return

    # kilka źródeł → wybór
    labels = []
    for i, s in enumerate(sources, 1):
        mod = s.get("module", "")
        url = s.get("url", "")
        host = ""
        try:
            host = urllib.parse.urlparse(url).hostname or ""
        except:
            pass
        labels.append(f"{mod} ({host or 'źródło ' + str(i)})")

    idx = xbmcgui.Dialog().select(f"Wybierz źródło dla {nazwa}", labels)
    if idx == -1:
        return
    s = sources[idx]
    play_video(s.get("module"), s.get("url"), nazwa)

# === ODTWARZANIE ===
def play_video(module_name, video_url, video_name=None):
    if not video_url:
        xbmcgui.Dialog().notification("Błąd", "Brak adresu URL", xbmcgui.NOTIFICATION_ERROR, 2000)
        return
    try:
        if module_name:
            mod = importlib.import_module(f"resources.lib.{module_name}")
            if hasattr(mod, "play_channel"): return mod.play_channel(video_url)
            if hasattr(mod, "play"): return mod.play(video_url, video_name)
    except Exception as e:
        log(f"play_video error: {e}")
#    li = xbmcgui.ListItem(path=urllib.parse.unquote(video_url))
    li = xbmcgui.ListItem(path=video_url)
    li.setInfo("video", {"title": video_name or video_url})
    li.setProperty("IsPlayable", "true")
    xbmcplugin.setResolvedUrl(HANDLE, True, li)
# === ZMIANA LISTY M3U I CLEAR ===
def change_m3u_file():
    dialog = xbmcgui.Dialog()
    mask = "*.m3u|*.m3u8"
    m3u_path = dialog.browse(1, "📂 Wybierz lokalizację listy M3U8", "files", mask)
    if not m3u_path:
        dialog.notification("Anulowano", "Nie wybrano pliku.", xbmcgui.NOTIFICATION_INFO)
        return
    try:
        profile_dir = xbmcvfs.translatePath(f"special://profile/addon_data/{ADDON_ID}")
        if not xbmcvfs.exists(profile_dir): xbmcvfs.mkdirs(profile_dir)
        save_path = os.path.join(profile_dir, "m3u_path.json")
        with xbmcvfs.File(save_path, "w") as f:
            f.write(json.dumps({"path": m3u_path}, ensure_ascii=False, indent=2))
        xbmcgui.Dialog().notification("Lista M3U8", "Nowa lista została zapisana.", xbmcgui.NOTIFICATION_INFO)
    except Exception as e:
        xbmcgui.Dialog().ok("Błąd zapisu", str(e))
## 📦 GŁÓWNY ROUTER DODATKU PolskaTV


def router(paramstring):
    xbmc.log(f"[PolskaTV router] paramstring: {paramstring}", xbmc.LOGINFO)

    params = dict(urllib.parse.parse_qsl(paramstring))
    action = params.get("action")
    module_name = params.get("list")
    name = params.get("name")
    url = params.get("url")
    category = params.get("cat")

    # ==================================================
    # START – MENU GŁÓWNE
    # ==================================================
    if not action:
        list_lists()  # Twój standardowy startowy ekran
        return

    # ==================================================
    # 🔵 UNI_PLAYER (BEZ ZMIAN)
    # ==================================================
    if action == "uni_player":
        from resources.lib import uni_player
        uni_player.play_uni(
            urllib.parse.unquote(params.get("url")),
            urllib.parse.unquote(params.get("name", "")),
            params.get("module")
        )
        return

    if action == "uni_player2":
        from resources.lib import uni_player2
        uni_player2.play_uni(
            urllib.parse.unquote(params.get("url")),
            urllib.parse.unquote(params.get("name", "")),
            params.get("module")
        )
        return

    # ==================================================
    # ✅ MAC_MOD – CAŁE STEROWANIE IDZIE DO MODUŁU
    # ==================================================

    if action is None or action == "mac_menu":
        mac_mod.show_menu()
        return

    elif action == "mac_add":
        mac_api_li.add_slot()
        mac_mod.show_menu()
        return

    elif action == "mac_del":
        mac_api_li.delete_slot()
        mac_mod.show_menu()
        return

    elif action == "mac_enter":
        mac_mod.enter_slot()
        return

    elif action == "mac_show_items":
        mac_mod.show_items()
        return

    elif action == "mac_show_categories":
        mac_mod.show_categories()
        return


    elif action == "mac_series":
        mac_mod.show_series()
        return

    elif action == "mac_series_list":
        mac_mod.show_series_list()
        return

    elif action == "mac_play":
        cmd = params.get("cmd")
        mac_mod.mac_play(cmd)
        return

    elif action == "list_tv_categories":
        mac_mod.list_tv_categories()
        return

    elif action == "list_vod_categories":
        mac_mod.list_vod_categories()
        return

    elif action == "list_vod_main_menu":
        mac_mod.list_vod_main_menu()
        return
    elif action == "show_vod_groups":
        mac_mod.show_vod_groups()
        return

    elif action == "mac_show_vod_titles":
        mac_mod.show_vod_titles_paged()
        return

    elif action == "mac_list_real_categories":
        mac_mod.list_real_categories()
        return

    elif action == "show_vod_titles":
        mac_mod.show_vod_titles()
        return


    elif action == "mac_play":
        cmd = params.get("cmd")
        mac_mod.mac_play(cmd)
        mac_play(cmd, use_proxy=False)

        return

    elif action == "mac_play_proxy":
        cmd = params.get("cmd")
        if cmd:
            mac_mod.mac_play(cmd, use_proxy=True)
        return




    elif action == "mac_manage":
        slot_index = int(params.get("slot", 0))
        mac_api_li.manage_macs(slot_index)
        mac_mod.enter_slot()
        return
    # ==================================================
    # WIZJA TV (BEZ ZMIAN)
    # ==================================================
    elif action == "open_list" and module_name == "wizja_tv":
        from resources.lib import wizja_tv
        wizja_tv.list_categories()
        return

    elif action == "wizja_category" and category:
        from resources.lib import wizja_tv
        wizja_tv.list_channels_by_category(
            urllib.parse.unquote(category)
        )
        return

    elif action == "wizja_play" and url:
        from resources.lib import wizja_tv
        wizja_tv.play_channel(
            urllib.parse.unquote(url),
            urllib.parse.unquote(name) if name else None
        )
        return


    # ==================================================
    # STANDARDOWE MODUŁY
    # ==================================================
    if action == "open_list" and module_name:
        if module_name == "co_teraz":
            from resources.lib import co_teraz
            co_teraz.pokaz_wybor_modulu(LISTS)
            return

        if module_name == "Clear_nowy_test":
            from resources.lib import Clear_nowy_test
            Clear_nowy_test.run()
            return
        if module_name == "mac_mod":

            mac_mod.show_menu()
            return

        # Inne moduły, standardowe listowanie
        list_channels(module_name)
        return


    # ==================================================
    # ODTWARZANIE Z sources.json (RESZTA DODATKU)
    # ==================================================

    if action == "play_channel" and name:
        play_channel(urllib.parse.unquote(name))
        return


# ==================================================
# URUCHOMIENIE ROUTERA
# ==================================================
if __name__ == "__main__":
    import sys
    try:
        paramstring = sys.argv[2][1:] if len(sys.argv) > 2 else ""
        router(paramstring)
    except Exception as e:
        import traceback
        xbmcgui.Dialog().ok("Błąd krytyczny", str(e))
        xbmc.log(f"[PolskaTV router] Błąd routera: {e}\n{traceback.format_exc()}", xbmc.LOGERROR)
