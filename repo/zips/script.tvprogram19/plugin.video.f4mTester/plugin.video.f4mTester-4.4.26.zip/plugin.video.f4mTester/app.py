from flask import Flask, request, Response, jsonify
import urllib.parse
import requests
import re
import time
import logging
from urllib.parse import urljoin
from doh import DNSOverrideDoH
import sys

PORT = 8088

app = Flask(__name__)
app.debug = True

DEFAULT_USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"

###HANDLE = int(sys.argv[1])


logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(levelname)s - %(message)s'
)

# ================= RESET =================

@app.route("/reset")
def reset():
    logging.info("[f4mProxy] RESET cache")
    return jsonify({"status": "reset done"})


# ================= HELPERS =================

def get_ip():
    return request.headers.get("X-Forwarded-For", request.remote_addr)


# ================= HLS PROXY =================

@app.route("/hlsretry")
def hls_retry():
    DNSOverrideDoH()

    url = request.args.get('url')
    if not url:
        logging.error("[HLS] No URL provided")
        return jsonify({"błąd": "No URL"}), 400

    logging.info(f"[HLS] START url={url}")

    headers = {
        k: v for k, v in request.headers.items()
        if k.lower() != 'host'
    }
    if start:
        headers["Range"] = f"bytes={start * 1024 * 1024}-"
        logging.info(f"[HTTP] RESUME start={start}")

    headers.setdefault("User-Agent", DEFAULT_USER_AGENT)
    headers.pop("Accept-Encoding", None)
    headers.setdefault("Connection", "keep-alive")

    try:
        with requests.get(url, headers=headers, stream=True, allow_redirects=True, timeout=8) as r:

            logging.info(f"[HLS] status={r.status_code} final_url={r.url}")

            if "mpegurl" in r.headers.get("content-type", "").lower() or ".m3u8" in url:
                base_url = url.rsplit('/', 1)[0]
                content = r.text

                logging.debug("[HLS] rewriting playlist URLs")

                def replace_url(match):
                    segment_url = match.group(0).strip()
                    if segment_url.startswith('#') or not segment_url:
                        return segment_url

                    absolute_url = urljoin(base_url + '/', segment_url)
                    return f"http://127.0.0.1:{PORT}/hlsretry?url={urllib.parse.quote(absolute_url)}"

                rewritten = re.sub(r'^(?!#)\S+', replace_url, content, flags=re.MULTILINE)

                return Response(rewritten, content_type="application/x-mpegURL")

            return Response(
                r.iter_content(chunk_size=4096),
                content_type=r.headers.get("content-type", "application/octet-stream")
            )

    except Exception as e:
        logging.error(f"[HLS] ERROR url={url} err={e}")
        return jsonify({"błąd": "HLS failed"}), 500


# ================= TS DOWNLOADER =================

@app.route("/tsdownloader")
def ts_downloader():
    DNSOverrideDoH()

    url = request.args.get("url")
    start = request.args.get("start", type=int)


    if not url:
        logging.error("[TS] No URL provided")
        return jsonify({"błąd": "No URL"}), 400

    logging.info(f"[TS] START url={url}")

    headers = {
        k: v for k, v in request.headers.items()
        if k.lower() != 'host'
    }

    headers.setdefault("User-Agent", DEFAULT_USER_AGENT)
    headers.pop("Accept-Encoding", None)
    headers.setdefault("Connection", "keep-alive")

    stop_ts = False
    last_url = ''

    def generate_ts():
        nonlocal last_url, stop_ts
        last_data_time = time.time()
        while not stop_ts:
            try:
                with requests.get(
                    last_url or url,
                    headers=headers,
                    stream=True,

                    timeout=(5, 60),
                    allow_redirects=True
                ) as r:

                    last_url = r.url
                    logging.info(f"[TS] connected url={last_url} status={r.status_code}")

                    if r.status_code != 200:
                        logging.warning(f"[TS] bad status={r.status_code}")
                        time.sleep(1)
                        continue


                    for chunk in r.iter_content(chunk_size=4096):
                        if stop_ts:
                            return

                        if chunk:
                            last_data_time = time.time()
                            yield chunk


                    if time.time() - last_data_time > 5:
                        yield b'\x00'

            except Exception as e:
                logging.warning(f"[TS] błąd: {e}")
                last_url = ''
                time.sleep(1)
                continue

    resp = Response(generate_ts(), content_type="video/mp2t")

    @resp.call_on_close
    def close():
        nonlocal stop_ts
        stop_ts = True
        logging.info("[TS] client disconnected")

    return resp


# ================= HTTP PROXY =================

@app.route("/http")
def http_proxy():
    url = request.args.get("url")
    start = request.args.get("start")

    if start:
        headers["Range"] = f"bytes={int(start)*1024*1024}-"


    headers = {k: v for k, v in request.headers.items() if k.lower() != 'host'}
    headers.setdefault("User-Agent", DEFAULT_USER_AGENT)
    headers["Connection"] = "keep-alive"
    headers["Accept"] = "*/*"

    if "Range" not in request.headers:
        start = request.args.get("start")

        if start:
            try:
                start = int(start)
                start_bytes = start * 1024 * 1024
                headers["Range"] = f"bytes={start_bytes}-"
                logging.info(f"[HTTP] START OFFSET {start}s (~{start_bytes} bytes)")
            except Exception as e:
                logging.error(f"[HTTP] START OFFSET ERROR {e}")

    def generate():
        last_url = url
        retries = 0
        max_retries = 5

        while True:
            try:
                with requests.get(
                    last_url,
                    headers=headers,
                    stream=True,
                    timeout=(5, 60),
                    allow_redirects=True
                ) as r:

                    last_url = r.url
                    status = r.status_code

                    logging.info(f"[HTTP] status={status} final_url={last_url}")

                    if status in (462, 509):
                        logging.error(f"[HTTP] session expired status={status}")
                        break

                    if status not in (200, 206):
                        logging.warning(f"[HTTP] bad status={status}")
                        time.sleep(2)
                        continue

                    for chunk in r.iter_content(chunk_size=262144):
                        if chunk:
                            yield chunk

                    break

            except requests.exceptions.ConnectTimeout:
                retries += 1
                logging.warning(f"[HTTP] connect timeout retry={retries}")

                if retries >= max_retries:
                    logging.error("[HTTP] max retries reached")
                    break

                time.sleep(min(10, retries * 2))
                last_url = url
                continue

            except Exception as e:
                retries += 1
                logging.warning(f"[HTTP] error retry={retries} err={e}")

                if retries >= max_retries:
                    break

                time.sleep(2)
                last_url = url
                continue


    return Response(
        generate(),
        content_type="video/mp4",
        headers={
            "Accept-Ranges": "bytes",
            "Cache-Control": "no-cache"
        }
    )


# ================= MP4 → RANGE =================

@app.route("/mp4hls")
def mp4_to_hls():
    url = request.args.get("url")
    start = request.args.get("start")

    if not url:
        return jsonify({"error": "No URL"}), 400

    # 🔥 RESUME
    if start:
        try:
            start = int(start)
        except:
            start = 0
    else:
        start = 0

    def generate():
        position = start * 1024 * 1024  # 🔥 TU DZIAŁA RESUME
        chunk_size = 1024 * 1024

        while True:
            try:
                headers = {
                    "User-Agent": DEFAULT_USER_AGENT,
                    "Range": f"bytes={position}-{position + chunk_size - 1}"
                }

                logging.info(f"[MP4] RANGE {position}")

                r = requests.get(url, headers=headers, stream=True, timeout=(5, 60))

                if r.status_code not in (200, 206):
                    logging.warning(f"[MP4] BAD STATUS {r.status_code}")
                    break

                data = r.content
                if not data:
                    break

                position += len(data)
                yield data

            except Exception as e:
                logging.error(f"[MP4HLS] {e}")
                break

    return Response(
        generate(),
        content_type="video/mp4",
        headers={"Accept-Ranges": "bytes"}
    )
# ================= INDEX =================

@app.route("/")
def index():
    logging.info("[f4mProxy] INDEX accessed")
    return jsonify({"message": "F4MTESTER PROXY CLEAN"})


def server_run():
    app.run(host='127.0.0.1', port=PORT, debug=False)