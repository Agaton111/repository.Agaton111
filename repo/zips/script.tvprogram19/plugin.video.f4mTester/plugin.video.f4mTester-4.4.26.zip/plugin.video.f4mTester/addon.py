 # -*- coding: utf-8 -*-
### addon.py  fm4Tester

import xbmc
import xbmcgui
import xbmcaddon
import xbmcvfs
import os


from urllib.parse import urlparse, parse_qs, parse_qsl, quote, unquote, quote_plus, unquote_plus, urlencode #python 3
from app import PORT
import time
import requests
##from flask import request

URL_HLSRETRY = f"http://127.0.0.1:{PORT}/hlsretry?url="
URL_TS_DOWNLOADER = f"http://127.0.0.1:{PORT}/tsdownloader?url="
URL_MP4_HLS = f"http://127.0.0.1:{PORT}/mp4hls?url="

addon = xbmcaddon.Addon()
addonName = addon.getAddonInfo('name')
dialog_ = xbmcgui.Dialog()
translate = xbmcvfs.translatePath
homeDir = addon.getAddonInfo('path')
addonIcon = translate(os.path.join(homeDir, 'icon.png'))

kversion = int(xbmc.getInfoLabel('System.BuildVersion').split(".")[0])

ADDON_ID = xbmcaddon.Addon().getAddonInfo('id')
ADDON_DATA = xbmcvfs.translatePath(f'special://profile/addon_data/{ADDON_ID}')
player = None



if not os.path.exists(ADDON_DATA):
    os.makedirs(ADDON_DATA)

RESUME_FILE = os.path.join(ADDON_DATA, 'resume.txt')


def player_auto(name, url, iconimage, description):

    xbmc.log(f"[f4mProxy] AUTO URL={url}", xbmc.LOGINFO)

    url = unquote_plus(url)
    url = url.split('|')[0] if '|' in url else url

    # 🔥 wybór trybu
    if ".m3u8" in url:
        mode = "HLS"
    elif ".mp4" in url or ".mkv" in url:
        mode = "HTTP"
    else:
        mode = "HTTP"  # fallback

    xbmc.log(f"[f4mProxy] AUTO MODE={mode}", xbmc.LOGINFO)

    # 🔥 RESUME tylko dla HTTP
    start = 0
    if mode == "HTTP":
        start = ask_resume(url)

    # ================= HLS =================
    if mode == "HLS":
        proxy = URL_HLSRETRY + quote(url)

    # ================= HTTP (MP4/MKV) =================
    else:
        proxy = f"http://127.0.0.1:{PORT}/http?url=" + quote(url)
##
##        if start > 0:
##            proxy += f"&start={start}"

    # ================= PLAY =================
    li = xbmcgui.ListItem(name)
    li.setArt({"icon": "DefaultVideo.png", "thumb": iconimage})

    if mode == "HTTP":
        li.setProperty("inputstream", "inputstream.ffmpegdirect")
        li.setProperty("inputstream.ffmpegdirect.stream_mode", "default")
        li.setProperty("inputstream.ffmpegdirect.seekable", "true")


    player.play(item=proxy, listitem=li)

    # 🔥 TWÓJ mechanizm (poprawiony timing)
    if start > 0:
        xbmc.log("[f4mProxy] WAIT FOR STABLE PLAYBACK", xbmc.LOGINFO)


        progress = xbmcgui.DialogProgress()
        progress.create("Wznawianie", "Przygotowanie odtwarzania...")

        for i in range(40):
            if player.isPlaying():
                try:
                    t = player.getTime()

                    if t > 4:
                        xbmc.log(f"[f4mProxy] READY t={t} -> SEEK {start}", xbmc.LOGINFO)

                        progress.update(200, "Wznawiam odtwarzanie...")

                        xbmc.sleep(1000)  # 🔥 kluczowy moment
                        player.seekTime(start)

                        break

                except Exception as e:
                    xbmc.log(f"[f4mProxy] SEEK ERROR {e}", xbmc.LOGERROR)

            xbmc.sleep(300)
            progress.update(int(i * 2.5), "Buforowanie...")

        progress.close()

def normalize_url(url):
    if not url:
        return url

    url = url.split('|')[0]

    parsed = urlparse(url)
    qs = parse_qs(parsed.query)

    qs.pop("play_token", None)

    # SORT parametrów → KLUCZ DO STABILNOŚCI
    new_query = urlencode(sorted(qs.items()), doseq=True)

    if new_query:
        return f"{parsed.scheme}://{parsed.netloc}{parsed.path}?{new_query}"
    else:
        return f"{parsed.scheme}://{parsed.netloc}{parsed.path}"

def get_stream_id(url):
    try:
        parsed = urlparse(url)
        qs = parse_qs(parsed.query)

        stream = qs.get("stream", [None])[0]

        if stream:
            # usuń rozszerzenie .mp4/.mkv
            stream = stream.split('.')[0]

        return stream

    except Exception as e:
        xbmc.log(f"[f4mProxy] STREAM PARSE ERROR {e}", xbmc.LOGERROR)
        return None
def save_resume(url, position):
    try:
        if position < 5:
            return  # 🔴 ignoruj śmieci

        with open(RESUME_FILE, "w") as f:

            # wyciąg oryginalnego URL
            clean_url = url.split('?url=')[-1] if '?url=' in url else url
            clean_url = normalize_url(clean_url)

            f.write(f"{clean_url}|{int(position)}")

##        xbmc.log(f"[f4mProxy] SAVE OK pos={position}", xbmc.LOGINFO)

    except Exception as e:
        xbmc.log(f"[f4mProxy] SAVE ERROR {e}", xbmc.LOGERROR)


def load_resume():
    try:
        if not os.path.exists(RESUME_FILE):
            return None, None

        with open(RESUME_FILE, "r") as f:
            data = f.read()

        url, pos = data.split("|")

        xbmc.log(f"[f4mProxy] LOAD RESUME url={url} pos={pos}", xbmc.LOGINFO)

        return url, int(pos)

    except Exception as e:
        xbmc.log(f"[f4mProxy] LOAD RESUME ERROR {e}", xbmc.LOGERROR)

    return None, None
def ask_resume(current_url):

    saved_url, pos = load_resume()

    if not pos:
        return 0

    saved_clean = normalize_url(saved_url)
    current_clean = normalize_url(current_url)


    xbmc.log(f"[f4mProxy] CLEAN saved={saved_clean}", xbmc.LOGINFO)
    xbmc.log(f"[f4mProxy] CLEAN current={current_clean}", xbmc.LOGINFO)

    if saved_clean == current_clean and pos > 5:

        choice = dialog_.select(
            "Wznów odtwarzanie",
            [
                f"Wznów od {pos//60}:{pos%60:02d}",
                "Odtwarzaj od początku"
            ]
        )

        if choice == 0:
            return pos
##    xbmcgui.Dialog().textviewer('info22', str(pos))

    return 0
####  xbmcgui.Dialog().textviewer('info', str(stream_saved +" "+stream_current))

def m3u8_to_ts(url):
    if '.m3u8' in url and '/live/' in url and int(url.count("/")) > 5:
        url = url.replace('/live', '').replace('.m3u8', '')
    return url

def dialog(msg):
    dialog = xbmcgui.Dialog()
    dialog.ok(addonName, msg)

def infoDialog(message, iconimage='', time=3000, sound=False):
    heading = addonName
    if iconimage == '':
        iconimage = addonIcon
    elif iconimage == 'INFO':
        iconimage = xbmcgui.NOTIFICATION_INFO
    elif iconimage == 'WARNING':
        iconimage = xbmcgui.NOTIFICATION_WARNING
    elif iconimage == 'ERROR':
        iconimage = xbmcgui.NOTIFICATION_ERROR
    dialog_.notification(heading, message, iconimage, time, sound=sound)

def select(name,items):
    op = dialog_.select(name, items)
    return op


def basename(p):
    """Returns the final component of a pathname"""
    i = p.rfind('/') + 1
    return p[i:]

def convert_to_m3u8(url):
    if '|' in url:
        url = url.split('|')[0]
    elif '%7C' in url:
        url = url.split('%7C')[0]
    if not '.m3u8' in url and not '/hl' in url and int(url.count("/")) > 4 and not '.mp4' in url and not '.avi' in url:
        parsed_url = urlparse(url)
        try:
            host_part1 = '%s://%s'%(parsed_url.scheme,parsed_url.netloc)
            host_part2 = url.split(host_part1)[1]
            url = host_part1 + '/live' + host_part2
            file = basename(url)
            if '.ts' in file:
                file_new = file.replace('.ts', '.m3u8')
                url = url.replace(file, file_new)
            else:
                url = url + '.m3u8'
                # file_new = file + '.m3u8'
                # new_url = url.replace(file, file_new)
        except:
            pass
    return url

def player_hlsretry(name,url,iconimage,description):
    xbmc.log(f"[f4mProxy] HLSRETRY URL={url}", xbmc.LOGINFO)
    if name:
        name = 'F4MTESTER - HLSRETRY - ' + name
    else:
        name = 'F4MTESTER - HLSRETRY'
    url = unquote_plus(url)
    url = url.split('%7C')[0] if '%7C' in url else url
    url = url.split('|')[0] if '|' in url else url
    url = convert_to_m3u8(url)
    url = URL_HLSRETRY + quote(url)
    li=xbmcgui.ListItem(name)
    iconimage = iconimage if iconimage else ''
    li.setArt({"icon": "DefaultVideo.png", "thumb": iconimage})
    if kversion > 19:
        info = li.getVideoInfoTag()
        info.setTitle(name)
        info.setPlot(description)
    else:
        li.setInfo(type="Video", infoLabels={"Title": name, "Plot": description})

    player.play(item=url, listitem=li)

def player_tsdownloader(name,url,iconimage,description):
    xbmc.log(f"[f4mProxy] TSDOWNLOADER URL={url}", xbmc.LOGINFO)
    if name:
        name = 'F4MTESTER - TSDOWNLOADER - ' + name
    else:
        name = 'F4MTESTER - TSDOWNLOADER'
    url = unquote_plus(url)
    url = url.split('%7C')[0] if '%7C' in url else url
    url = url.split('|')[0] if '|' in url else url
    url = url.replace('live/', '').replace('.m3u8', '')
    url = URL_TS_DOWNLOADER + quote(url)
    li=xbmcgui.ListItem(name)
    iconimage = iconimage if iconimage else ''
    li.setArt({"icon": "DefaultVideo.png", "thumb": iconimage})
    if kversion > 19:
        info = li.getVideoInfoTag()
        info.setTitle(name)
        info.setPlot(description)
    else:
        li.setInfo(type="Video", infoLabels={"Title": name, "Plot": description})
    player.play(item=url, listitem=li)


def player_http(name,url,iconimage,description):
    xbmc.log(f"[f4mProxy] HTTP URL={url}", xbmc.LOGINFO)

    if name:
        name = 'F4MTESTER - HTTP - ' + name
    else:
        name = 'F4MTESTER - HTTP'

    url = unquote_plus(url)
    url = url.split('|')[0] if '|' in url else url

    start = ask_resume(url)

    if start > 0:
        sep = "&" if "?" in url else "?"
##        url += f"{sep}start={start}"
        url=url


    li = xbmcgui.ListItem(name)
    li.setArt({"icon": "DefaultVideo.png", "thumb": iconimage})
    li.setProperty("inputstream", "inputstream.ffmpegdirect")
    li.setProperty("inputstream.ffmpegdirect.stream_mode", "default")
    li.setProperty("inputstream.ffmpegdirect.seekable", "true")

    player.play(item=url, listitem=li)

    # 🔥 SEEK po starcie

    if start > 0:
        xbmc.log("[f4mProxy] WAIT FOR STABLE PLAYBACK", xbmc.LOGINFO)

        progress = xbmcgui.DialogProgress()
        progress.create("Wznawianie", "Przygotowanie odtwarzania...")

        for i in range(40):
            if player.isPlaying():
                try:
                    t = player.getTime()

                    if t > 4:
                        xbmc.log(f"[f4mProxy] READY t={t} -> SEEK {start}", xbmc.LOGINFO)

                        progress.update(200, "Wznawiam odtwarzanie...")

                        xbmc.sleep(1000)  # 🔥 kluczowy moment
                        player.seekTime(start)

                        break

                except Exception as e:
                    xbmc.log(f"[f4mProxy] SEEK ERROR {e}", xbmc.LOGERROR)

            xbmc.sleep(300)
            progress.update(int(i * 2.5), "Buforowanie...")

        progress.close()

def player_mp4_hls(name, url, iconimage, description):

    xbmc.log(f"[f4mProxy] MP4HLS URL={url}", xbmc.LOGINFO)

    if name:
        name = 'F4MTESTER - MP4→HLS - ' + name
    else:
        name = 'F4MTESTER - MP4→HLS'

    url = unquote_plus(url)
    url = url.split('|')[0] if '|' in url else url

    start = ask_resume(url)

    if start > 0:
        sep = "&" if "?" in url else "?"
##        url += f"{sep}start={start}"
        url=url


    li = xbmcgui.ListItem(name)
    li.setArt({"icon": "DefaultVideo.png", "thumb": iconimage})

##    player.play(item=proxy, listitem=li)
    player.play(item=url, listitem=li)

    if start > 0:
        xbmc.log("[f4mProxy] WAIT FOR STABLE PLAYBACK", xbmc.LOGINFO)

        progress = xbmcgui.DialogProgress()
        progress.create("Wznawianie", "Przygotowanie odtwarzania...")

        for i in range(40):
            if player.isPlaying():
                try:
                    t = player.getTime()

                    if t > 4:
                        xbmc.log(f"[f4mProxy] READY t={t} -> SEEK {start}", xbmc.LOGINFO)

                        progress.update(200, "Wznawiam odtwarzanie...")

                        xbmc.sleep(1000)  # 🔥 kluczowy moment
                        player.seekTime(start)

                        break

                except Exception as e:
                    xbmc.log(f"[f4mProxy] SEEK ERROR {e}", xbmc.LOGERROR)

            xbmc.sleep(300)
            progress.update(int(i * 2.5), "Buforowanie...")

        progress.close()


def reset_mag():
    try:
        r = requests.get(f"http://127.0.0.1:{PORT}/reset", timeout=3)
        if r.status_code == 200:
            xbmcgui.Dialog().notification("PROXY", "RESET OK", xbmcgui.NOTIFICATION_INFO, 2000)
        else:
            xbmcgui.Dialog().notification("PROXY", "RESET FAIL", xbmcgui.NOTIFICATION_WARNING, 2000)
    except Exception:
        xbmcgui.Dialog().notification("PROXY", "RESET ERROR", xbmcgui.NOTIFICATION_ERROR, 2000)

#### run addon ####
def run(params):
    xbmc.log(f"[f4mProxy] RUN params={params}", xbmc.LOGINFO)
    stream_type = params.get('streamtype', None)
    xbmc.log(f"[f4mProxy] stream_type={stream_type}", xbmc.LOGINFO)
    iconimage = params.get('iconImage', params.get('thumbnailImage', addonIcon))
    name = params.get('name', 'F4mTester')
    url = params.get('url', '')
    description = params.get('description', '')

    if not stream_type:
        dialog('F4MTESTER PLAYER')
    elif stream_type !=None:

        if url:
            op = select('SELECT PLAYER', [
                'AUTO (zalecane)',
                'PROXY - HLSRETRY',
                'PROXY - TSDOWNLOADER',
                'PROXY - HTTP (VOD)',
                'PROXY - MP4 → HLS',
                '---------------------------',
                'RESET SESJI IPTV'
            ])
##            if op == -1:
##                return
            if op == 0:
                player_auto(name, url, iconimage, description)
            elif op == 1:
                player_hlsretry(name,url,iconimage,description)
            elif op == 2:
                player_tsdownloader(name,url,iconimage,description)
            elif op == 3:
                player_http(name,url,iconimage,description)
            elif op == 4:
                 player_mp4_hls(name,url,iconimage,description)

            elif op == 6:
                reset_mag()

class ResumePlayer(xbmc.Player):
    def __init__(self):
        super().__init__()
        self.url = None
        self.running = False
    def onAVStarted(self):
        xbmc.log("[f4mProxy] AV STARTED", xbmc.LOGINFO)

        if hasattr(self, "seek_to") and self.seek_to > 0:
            try:
                self.seekTime(self.seek_to)
                xbmc.log(f"[f4mProxy] SEEK (event) {self.seek_to}", xbmc.LOGINFO)
            except Exception as e:
                xbmc.log(f"[f4mProxy] SEEK ERROR {e}", xbmc.LOGERROR)

    def _monitor_playback(self):

        def loop():
            while self.running:
                if self.isPlaying():
                    try:
                        pos = int(self.getTime())
                        save_resume(self.url, pos)
                    except Exception as e:
                        xbmc.log(f"[f4mProxy] MONITOR ERROR {e}", xbmc.LOGERROR)

                xbmc.sleep(5000)  # co 5 sek

        import threading
        threading.Thread(target=loop, daemon=True).start()

    def onPlayBackStopped(self):
        xbmc.log("[f4mProxy] STOP", xbmc.LOGINFO)
        self.running = False

    def onPlayBackEnded(self):
        xbmc.log("[f4mProxy] END", xbmc.LOGINFO)
        self.running = False
        try:
            save_resume(self.url, 0)
        except:
            pass
    def play(self, item="", listitem=None, windowed=False, startpos=-1):

        if "?url=" in item:
            self.url = unquote(item.split("?url=")[-1].split("&")[0])
        else:
            self.url = item


        xbmc.log(f"[f4mProxy] PLAY START url={self.url}", xbmc.LOGINFO)

        super().play(item, listitem, windowed, startpos)

        self.running = True
        self._monitor_playback()

player = ResumePlayer()