 # -*- coding: utf-8 -*-
### addon.py  fm4Tester

import xbmc
import xbmcgui
import xbmcaddon
import xbmcvfs
import os
import xbmcplugin
import sys

from urllib.parse import urlparse, parse_qs, parse_qsl, quote, unquote, quote_plus, unquote_plus, urlencode #python 3
from app import PORT
import time
import requests
##from flask import request

URL_HLSRETRY = f"http://127.0.0.1:{PORT}/hlsretry?url="
URL_TS_DOWNLOADER = f"http://127.0.0.1:{PORT}/tsdownloader?url="
URL_MP4_HLS = f"http://127.0.0.1:{PORT}/mp4hls?url="

addon = xbmcaddon.Addon()
addonName = addon.getAddonInfo('name')
dialog_ = xbmcgui.Dialog()
translate = xbmcvfs.translatePath
homeDir = addon.getAddonInfo('path')
addonIcon = translate(os.path.join(homeDir, 'icon.png'))

kversion = int(xbmc.getInfoLabel('System.BuildVersion').split(".")[0])

ADDON_ID = xbmcaddon.Addon().getAddonInfo('id')
ADDON_DATA = xbmcvfs.translatePath(f'special://profile/addon_data/{ADDON_ID}')

if not os.path.exists(ADDON_DATA):
    os.makedirs(ADDON_DATA)

RESUME_FILE = os.path.join(ADDON_DATA, 'resume.txt')

handle = int(sys.argv[1])


def get_resume_file(stream_id):
    return os.path.join(ADDON_DATA, f"resume_{stream_id}.txt")

def wait_for_proxy_ready():
    for _ in range(30):
        try:
            r = requests.get(f"http://127.0.0.1:{PORT}/status", timeout=0.5)
            if r.json().get("ready"):
                return True
        except:
            pass
        xbmc.sleep(200)




def normalize_url(url):

    if not url:
        return url

    url = url.split('|')[0]

    parsed = urlparse(url)
    qs = parse_qs(parsed.query)

    # 🔥 jeśli to proxy → wyciągnij prawdziwy URL
    if parsed.netloc == "127.0.0.1":
        if "url" in qs:
            real_url = unquote(qs["url"][0])
            return normalize_url(real_url)

    qs.pop("play_token", None)

    new_query = urlencode(sorted(qs.items()), doseq=True)

    if new_query:
        return f"{parsed.scheme}://{parsed.netloc}{parsed.path}?{new_query}"
    else:
        return f"{parsed.scheme}://{parsed.netloc}{parsed.path}"

def get_stream_id(url):
    try:
        # 🔥 wielokrotne dekodowanie
        for _ in range(5):
            if "%" in url:
                url = unquote(url)

        parsed = urlparse(url)

        qs = parse_qs(parsed.query)

        # 🔥 jeśli proxy → wyciągnij prawdziwy URL
        if "127.0.0.1" in parsed.netloc and "url" in qs:
            return get_stream_id(qs["url"][0])

        # 🔥 stream=2044337.mkv
        stream = qs.get("stream", [None])[0]
        if stream:
            return stream.split('.')[0]

        # 🔥 /live/play/.../2044337
        parts = parsed.path.strip("/").split("/")
        if parts:
            last = parts[-1]
            if last.isdigit():
                return last

        return None

    except Exception as e:
        xbmc.log(f"[f4mProxy] STREAM PARSE ERROR {e}", xbmc.LOGERROR)
        return None
def save_resume_id(stream_id, position):
    try:
        if position < 10 or not stream_id:
            return

        file_path = get_resume_file(stream_id)

        with open(file_path, "w") as f:
            f.write(str(int(position)))

    except Exception as e:
        xbmc.log(f"[f4mProxy] SAVE ERROR {e}", xbmc.LOGERROR)

def load_resume(stream_id):
    try:
        file_path = get_resume_file(stream_id)

        if not os.path.exists(file_path):
            return None

        with open(file_path, "r") as f:
            return int(f.read())

    except Exception as e:
        xbmc.log(f"[f4mProxy] LOAD ERROR {e}", xbmc.LOGERROR)

    return None

##def ask_resume(current_url):
##
##    saved_id, pos = load_resume()
##
##    if not pos or not saved_id:
##        return 0
##
##    current_url = normalize_url(current_url)
##    current_id = get_stream_id(current_url)
##
##    xbmc.log(f"[f4mProxy] ID saved={saved_id}", xbmc.LOGINFO)
##    xbmc.log(f"[f4mProxy] ID curr ={current_id}", xbmc.LOGINFO)
##
##    # ✅ jeśli ID się zgadza → normalne resume
##    if current_id and saved_id == current_id and pos > 10:
####        choice = dialog_.select(
####            "Wznów odtwarzanie",
####            [
####                f"Wznów od {pos//60}:{pos%60:02d}",
####                "Wpisz",
####                "Odtwarzaj od początku"
####            ]
####        )
##
##        choice = dialog_.contextmenu([
##            f"Wznów od {pos//60}:{pos%60:02d}",
##            "Wpisz czas",
##            "Od początku"
##        ])
##
##        if choice == 0:
##            return pos
##        if choice == 1:
##            poswp = dialog_.numeric(0, 'Ilość minut')
##            if poswp:
##                return int(poswp) * 60
##
##    # ❗ NOWE: gdy ID się NIE zgadza → nadal daj opcję ręczną
##    else:
##        choice = dialog_.contextmenu([
##
##            "Wpisz czas",
##            "Odtwarzaj od początku"
##        ])
##
##        if choice == 0:
##            poswp = dialog_.numeric(0, 'Ilość minut')
##            if poswp:
##                return int(poswp) * 60
##
##    return 0

def ask_resume(current_url):

    current_id = get_stream_id(current_url)
    pos = load_resume(current_id)

    if pos:
        choice = dialog_.contextmenu([
            f"Wznów od {pos//60}:{pos%60:02d}",
            "Wpisz czas",
            "Od początku"
        ])

        if choice == 0:
            return pos
        if choice == 1:
            poswp = dialog_.numeric(0, 'Ilość minut')
            if poswp:
                return int(poswp) * 60

    else:
        choice = dialog_.contextmenu([
            "Wpisz czas",
            "Odtwarzaj od początku."
        ])

        if choice == 0:
            poswp = dialog_.numeric(0, 'Ilość minut')
            if poswp:
                return int(poswp) * 60

    return 0




def m3u8_to_ts(url):
    if '.m3u8' in url and '/live/' in url and int(url.count("/")) > 5:
        url = url.replace('/live', '').replace('.m3u8', '')
    return url

def dialog(msg):
    dialog = xbmcgui.Dialog()
    dialog.ok(addonName, msg)

def infoDialog(message, iconimage='', time=3000, sound=False):
    heading = addonName
    if iconimage == '':
        iconimage = addonIcon
    elif iconimage == 'INFO':
        iconimage = xbmcgui.NOTIFICATION_INFO
    elif iconimage == 'WARNING':
        iconimage = xbmcgui.NOTIFICATION_WARNING
    elif iconimage == 'ERROR':
        iconimage = xbmcgui.NOTIFICATION_ERROR
    dialog_.notification(heading, message, iconimage, time, sound=sound)

def select(name,items):
    op = dialog_.select(name, items)
    return op


def basename(p):
    """Returns the final component of a pathname"""
    i = p.rfind('/') + 1
    return p[i:]

def convert_to_m3u8(url):
    if '|' in url:
        url = url.split('|')[0]
    elif '%7C' in url:
        url = url.split('%7C')[0]
    if not '.m3u8' in url and not '/hl' in url and int(url.count("/")) > 4 and not '.mp4' in url and not '.avi' in url:
        parsed_url = urlparse(url)
        try:
            host_part1 = '%s://%s'%(parsed_url.scheme,parsed_url.netloc)
            host_part2 = url.split(host_part1)[1]
            url = host_part1 + '/live' + host_part2
            file = basename(url)
            if '.ts' in file:
                file_new = file.replace('.ts', '.m3u8')
                url = url.replace(file, file_new)
            else:
                url = url + '.m3u8'
                # file_new = file + '.m3u8'
                # new_url = url.replace(file, file_new)
        except:
            pass
    return url
def player_auto(name, url, iconimage, description):

    xbmc.log(f"[f4mProxy] AUTO URL={url}", xbmc.LOGINFO)

    url = unquote_plus(url)

    # 🔥 ROZDZIEL URL I HEADERS (ZAMIAST UCINAĆ)
    if '|' in url:
        stream_url, headers = url.split('|', 1)
    else:
        stream_url = url
        headers = ""

    # 🔥 DETEKCJA TRYBU (dodany TS)
    if ".m3u8" in stream_url:
        mode = "HLS"
    elif "extension=ts" in stream_url or ".ts" in stream_url:
        mode = "TS"
    else:
        mode = "HTTP"

    xbmc.log(f"[f4mProxy] MODE={mode}", xbmc.LOGINFO)

    real_url = None
    name = name + " " + mode

    try:
        for _ in range(20):
            r = requests.get(f"http://127.0.0.1:{PORT}/final", timeout=1)
            real_url = r.json().get("url")
            if real_url:
                xbmc.log(f"[f4mProxy] REAL URL={real_url}", xbmc.LOGINFO)
                break
            xbmc.sleep(300)
    except Exception as e:
        xbmc.log(f"[f4mProxy] FINAL URL ERROR {e}", xbmc.LOGERROR)

    # 🔥 WAŻNE: jeśli proxy nie zwróci URL → użyj ORYGINAŁU (z headers!)
    final = real_url if real_url else stream_url

    if mode == "TS":
        start = 0

    else:
        start = ask_resume(final)

    li = xbmcgui.ListItem(name)
    li.setArt({"icon": "DefaultVideo.png", "thumb": iconimage})

    # 🔥 PRZEKAŻ HEADERSY DO PLAYERA
    if headers:
        xbmc.log(f"[f4mProxy] HEADERS={headers}", xbmc.LOGINFO)

        li.setProperty("inputstream.adaptive.stream_headers", headers)
        li.setProperty("inputstream.ffmpegdirect.headers", headers)

    # 🔥 WYMUSZENIE LEPSZEGO PLAYERA DLA TS
    if mode == "TS":

##        li.setProperty("inputstream", "inputstream.ffmpegdirect")
##        li.setProperty("inputstream.ffmpegdirect.stream_mode", "default")
##        li.setProperty("inputstream.ffmpegdirect.seekable", "true")

        li.setProperty("inputstream", "inputstream.ffmpegdirect")
        li.setProperty("inputstream.ffmpegdirect.stream_mode", "default")
        li.setProperty("inputstream.ffmpegdirect.reconnect", "true")
        li.setProperty("inputstream.ffmpegdirect.reconnect_streamed", "true")
        li.setProperty("inputstream.ffmpegdirect.reconnect_delay_max", "5")
        li.setProperty("inputstream.ffmpegdirect.buffer_size", "20971520")  # 20MB   "52428800"  # 50MB


    if start > 0:
        li.setProperty("StartOffset", str(start))

    player.play(item=final, listitem=li)
##    li.setPath(final)
##    xbmcplugin.setResolvedUrl(handle, True, li)


    # fallback seek
    if start > 0:
        xbmc.sleep(1500)
        try:
            player.seekTime(start)
        except Exception as e:
            xbmc.log(f"[f4mProxy] SEEK ERROR {e}", xbmc.LOGERROR)
    xbmc.executebuiltin('Dialog.Close(busydialog)')
def player_hlsretry(name,url,iconimage,description):
    xbmc.log(f"[f4mProxy] HLSRETRY URL={url}", xbmc.LOGINFO)
    if name:
        name = 'F4MTESTER - HLSRETRY - ' + name
    else:
        name = 'F4MTESTER - HLSRETRY'
    url = unquote_plus(url)
    url = url.split('%7C')[0] if '%7C' in url else url
    url = url.split('|')[0] if '|' in url else url
    url = convert_to_m3u8(url)
    url = URL_HLSRETRY + quote(url)
    li=xbmcgui.ListItem(name)
    iconimage = iconimage if iconimage else ''
    li.setArt({"icon": "DefaultVideo.png", "thumb": iconimage})
    if kversion > 19:
        info = li.getVideoInfoTag()
        info.setTitle(name)
        info.setPlot(description)
    else:
        li.setInfo(type="Video", infoLabels={"Title": name, "Plot": description})

    player.play(item=url, listitem=li)

def player_tsdownloader(name,url,iconimage,description):
    xbmc.log(f"[f4mProxy] TSDOWNLOADER URL={url}", xbmc.LOGINFO)
    if name:
        name = 'F4MTESTER - TSDOWNLOADER - ' + name
    else:
        name = 'F4MTESTER - TSDOWNLOADER'
    url = unquote_plus(url)
    url = url.split('%7C')[0] if '%7C' in url else url
    url = url.split('|')[0] if '|' in url else url
    url = url.replace('live/', '').replace('.m3u8', '')
    url = URL_TS_DOWNLOADER + quote(url)
    li=xbmcgui.ListItem(name)
    iconimage = iconimage if iconimage else ''
    li.setArt({"icon": "DefaultVideo.png", "thumb": iconimage})
    if kversion > 19:
        info = li.getVideoInfoTag()
        info.setTitle(name)
        info.setPlot(description)
    else:
        li.setInfo(type="Video", infoLabels={"Title": name, "Plot": description})
    player.play(item=url, listitem=li)


def player_http(name,url,iconimage,description):
    xbmc.log(f"[f4mProxy] HTTP URL={url}", xbmc.LOGINFO)

    if name:
        name = 'F4MTESTER - HTTP - ' + name
    else:
        name = 'F4MTESTER - HTTP'

    url = unquote_plus(url)
    url = url.split('|')[0] if '|' in url else url

    start = ask_resume(url)

    if start > 0:
        sep = "&" if "?" in url else "?"
##        url += f"{sep}start={start}"
        url=url


    li = xbmcgui.ListItem(name)
    li.setArt({"icon": "DefaultVideo.png", "thumb": iconimage})
    li.setProperty("inputstream", "inputstream.ffmpegdirect")
    li.setProperty("inputstream.ffmpegdirect.stream_mode", "default")
    li.setProperty("inputstream.ffmpegdirect.seekable", "true")

    player.play(item=url, listitem=li)

    # 🔥 SEEK po starcie

    if start > 0:
        xbmc.log("[f4mProxy] WAIT FOR STABLE PLAYBACK", xbmc.LOGINFO)

        progress = xbmcgui.DialogProgress()
        progress.create("Wznawianie", "Przygotowanie odtwarzania...")

        for i in range(40):
            if player.isPlaying():
                try:
                    t = player.getTime()

                    if t > 4:
                        xbmc.log(f"[f4mProxy] READY t={t} -> SEEK {start}", xbmc.LOGINFO)

                        progress.update(200, "Wznawiam odtwarzanie...")

                        xbmc.sleep(1000)  # 🔥 kluczowy moment
                        player.seekTime(start)

                        break

                except Exception as e:
                    xbmc.log(f"[f4mProxy] SEEK ERROR {e}", xbmc.LOGERROR)

            xbmc.sleep(300)
            progress.update(int(i * 2.5), "Buforowanie...")

        progress.close()
def player_mp4_hls(name, url, iconimage, description):

    xbmc.log(f"[f4mProxy] MP4HLS URL={url}", xbmc.LOGINFO)

    if name:
        name = 'F4MTESTER - MP4→HLS - ' + name
    else:
        name = 'F4MTESTER - MP4→HLS'

    url = unquote_plus(url)
    url = url.split('|')[0] if '|' in url else url

    start = ask_resume(url)

    if start > 0:
        sep = "&" if "?" in url else "?"
##        url += f"{sep}start={start}"
        url=url


    li = xbmcgui.ListItem(name)
    li.setArt({"icon": "DefaultVideo.png", "thumb": iconimage})
    player.play(item=url, listitem=li)

    if start > 0:
        xbmc.log("[f4mProxy] WAIT FOR STABLE PLAYBACK", xbmc.LOGINFO)

        progress = xbmcgui.DialogProgress()
        progress.create("Wznawianie", "Przygotowanie odtwarzania...")

        for i in range(40):
            if player.isPlaying():
                try:
                    t = player.getTime()

                    if t > 4:
                        xbmc.log(f"[f4mProxy] READY t={t} -> SEEK {start}", xbmc.LOGINFO)

                        progress.update(200, "Wznawiam odtwarzanie...")

                        xbmc.sleep(1000)  # 🔥 kluczowy moment
                        player.seekTime(start)

                        break

                except Exception as e:
                    xbmc.log(f"[f4mProxy] SEEK ERROR {e}", xbmc.LOGERROR)

            xbmc.sleep(300)
            progress.update(int(i * 2.5), "Buforowanie...")

        progress.close()
def reset_mag():
    try:
        r = requests.get(f"http://127.0.0.1:{PORT}/reset", timeout=3)
        if r.status_code == 200:
            xbmcgui.Dialog().notification("PROXY", "RESET OK", xbmcgui.NOTIFICATION_INFO, 2000)
        else:
            xbmcgui.Dialog().notification("PROXY", "RESET FAIL", xbmcgui.NOTIFICATION_WARNING, 2000)
    except Exception:
        xbmcgui.Dialog().notification("PROXY", "RESET ERROR", xbmcgui.NOTIFICATION_ERROR, 2000)

def ask_user_url():
    keyboard = xbmc.Keyboard('', 'Wpisz URL streamu')
    keyboard.doModal()

    if keyboard.isConfirmed():
        text = keyboard.getText().strip()
        if text:
            return text
    return None
#### run addon ####
def run(params):
    xbmc.log(f"[f4mProxy] RUN params={params}", xbmc.LOGINFO)
##    xbmcgui.Dialog().textviewer('params', str(params))
    stream_type = params.get('streamtype', None)
    xbmc.log(f"[f4mProxy] stream_type={stream_type}", xbmc.LOGINFO)
    iconimage = params.get('iconImage', params.get('thumbnailImage', addonIcon))
    name = params.get('name', 'F4mTester')
    url = params.get('url', '')
    description = params.get('description', '')
    if not stream_type:
        url = ask_user_url()

        if not url:
            xbmcplugin.endOfDirectory(int(sys.argv[1]))
##            xbmc.executebuiltin('Action(Back)')
            xbmc.executebuiltin('Action(ParentDir)')

            return

        # 🔥 symulujemy parametry jak z innej wtyczki
        name = "Custom URL"
        iconimage = addonIcon
        description = url

        op = select('SELECT PLAYER', [
            'AUTO (zalecane)',
            'PROXY - HLSRETRY',
            'PROXY - TSDOWNLOADER',
            'PROXY - HTTP (VOD)',
            'PROXY - MP4 → HLS',
            '---------------------------',
            'RESET SESJI IPTV'
        ])

        if op == 0:
            player_auto(name, url, iconimage, description)

            xbmcplugin.endOfDirectory(int(sys.argv[1]))
            xbmc.executebuiltin('Dialog.Close(busydialog)')
            return
        elif op == 1:
            player_hlsretry(name, url, iconimage, description)
            xbmcplugin.endOfDirectory(int(sys.argv[1]))
            xbmc.executebuiltin('Dialog.Close(busydialog)')
            return
        elif op == 2:
            player_tsdownloader(name, url, iconimage, description)
            xbmcplugin.endOfDirectory(int(sys.argv[1]))
            xbmc.executebuiltin('Dialog.Close(busydialog)')
            return
        elif op == 3:
            player_http(name, url, iconimage, description)
            xbmcplugin.endOfDirectory(int(sys.argv[1]))
            xbmc.executebuiltin('Dialog.Close(busydialog)')
            return
        elif op == 4:
            player_mp4_hls(name, url, iconimage, description)
            xbmcplugin.endOfDirectory(int(sys.argv[1]))
            xbmc.executebuiltin('Dialog.Close(busydialog)')
            return
        elif op == 6:
            xbmcplugin.endOfDirectory(int(sys.argv[1]))
            xbmc.executebuiltin('Dialog.Close(busydialog)')
            reset_mag()

        return

    elif stream_type !=None:

        if url:
            op = select('SELECT PLAYER', [
                'AUTO (zalecane)',
                'PROXY - HLSRETRY',
                'PROXY - TSDOWNLOADER',
                'PROXY - HTTP (VOD)',
                'PROXY - MP4 → HLS',
                '---------------------------',
                'RESET SESJI IPTV'
            ])
##            if op == -1:
##                return
            if op == 0:
                player_auto(name, url, iconimage, description)
            elif op == 1:
                player_hlsretry(name,url,iconimage,description)
            elif op == 2:
                player_tsdownloader(name,url,iconimage,description)
            elif op == 3:
                player_http(name,url,iconimage,description)
            elif op == 4:
                 player_mp4_hls(name,url,iconimage,description)

            elif op == 6:
                reset_mag()

class ResumePlayer(xbmc.Player):
    def __init__(self):
        super().__init__()
        self.url = None
        self.stream_id = None
        self.running = False

    def onAVStarted(self):
        xbmc.log("[f4mProxy] AV STARTED", xbmc.LOGINFO)

        xbmc.sleep(1000)  # 🔥 daj Kodi czas

##        self._update_final_url()  # 🔥 KLUCZ

        if getattr(self, "seek_to", 0) > 0:
            xbmc.sleep(1200)

            try:
                self.seekTime(self.seek_to)
                xbmc.log(f"[f4mProxy] SEEK (event) {self.seek_to}", xbmc.LOGINFO)
            except Exception as e:
                xbmc.log(f"[f4mProxy] SEEK ERROR {e}", xbmc.LOGERROR)

    def _monitor_playback(self):

        def loop():
            while self.running:
                if self.isPlaying():
                    try:
                        pos = int(self.getTime())   # 🔥 TO MUSI BYĆ
                        save_resume_id(self.stream_id, pos)
                    except Exception as e:
                        xbmc.log(f"[f4mProxy] MONITOR ERROR {e}", xbmc.LOGERROR)

                xbmc.sleep(5000)

        import threading
        threading.Thread(target=loop, daemon=True).start()

##    def _update_final_url(self):
##        try:
##            li = self.getPlayingItem()
##            if li:
##                path = li.getPath()
##                if path:
##                    self.url = path
##                    xbmc.log(f"[f4mProxy] FINAL URL (Kodi) = {self.url}", xbmc.LOGINFO)
##        except Exception as e:
##            xbmc.log(f"[f4mProxy] GET PATH ERROR {e}", xbmc.LOGERROR)
    def onPlayBackStopped(self):
        xbmc.log("[f4mProxy] STOP", xbmc.LOGINFO)
        self.running = False

    def onPlayBackEnded(self):
        xbmc.log("[f4mProxy] END", xbmc.LOGINFO)
        self.running = False
        try:
            save_resume(self.url, 0)
        except:
            pass

    def play(self, item="", listitem=None, windowed=False, startpos=-1):

        if "?url=" in item:
            self.url = unquote(item.split("?url=")[-1].split("&")[0])
        else:
            self.url = item

        # 🔥 KLUCZOWE: licz ID tylko raz
        self.stream_id = get_stream_id(self.url)

        xbmc.log(f"[f4mProxy] PLAY START url={self.url} id={self.stream_id}", xbmc.LOGINFO)

        super().play(item, listitem, windowed, startpos)

        self.running = True
        self._monitor_playback()

player = ResumePlayer()