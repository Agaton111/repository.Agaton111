import xbmc
import xbmcgui
import xbmcaddon
import urllib.request

BASE_URL = "https://raw.githubusercontent.com/Agaton111/repository.Agaton111/main/repo/tools/"
LIST_URL = BASE_URL + "list.txt"

dialog = xbmcgui.Dialog()

# pobierz listę
response = urllib.request.urlopen(LIST_URL)
lines = response.read().decode("utf-8").splitlines()

addons = []
display = []

for line in lines:
    if "|" in line:
        addon_id, zip_name = line.strip().split("|")

        # sprawdź czy zainstalowany
        try:
            xbmcaddon.Addon(addon_id)
            status = "✔"
        except:
            status = "❌"

        display.append(f"{status} {addon_id}")
        addons.append((addon_id, zip_name))

choice = dialog.select("Tools", display)

if choice >= 0:
    addon_id, zip_name = addons[choice]

    try:
        xbmcaddon.Addon(addon_id)
        dialog.ok("Tools", "Już zainstalowane")
    except:
        zip_url = BASE_URL + zip_name
        xbmc.executebuiltin(f'InstallAddon({zip_url})')
        dialog.ok("Tools", "Instalacja zakończona")