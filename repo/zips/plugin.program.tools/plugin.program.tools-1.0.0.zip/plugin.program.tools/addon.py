import xbmc
import xbmcgui
import xbmcaddon
import xbmcvfs
import requests
import zipfile
import os

dialog = xbmcgui.Dialog()

# === API ===
TOOLS_API = "https://api.github.com/repos/Agaton111/repository.Agaton111/contents/repo/tools"
TOOLS_RAW = "https://raw.githubusercontent.com/Agaton111/repository.Agaton111/main/repo/tools/"

TRANS_API = "https://api.github.com/repos/Agaton111/repository.Agaton111/contents/repo/translations"
TRANS_RAW = "https://raw.githubusercontent.com/Agaton111/repository.Agaton111/main/repo/translations/"


# ========================
# MENU GŁÓWNE
# ========================
choice = dialog.select(
    "Co pobrać lub zainstalować ?",
    [
        "Pliki różne do pobrania",
        "Translations PL",
        "Zależnoci (instalacja tego, co ma w nazwie moduł)"
    ]
)
if choice == -1:
    exit()

if choice == 0:
    try:
        r = requests.get(TOOLS_API, timeout=10)
        data = r.json()

    except Exception as e:
        dialog.ok("Pliki ", f"Błąd:\n{e}")
        exit()

    addons = []
    display = []

    for item in data:
        if item["name"].endswith(".zip"):
            zip_name = item["name"]
            addon_id = zip_name.split("-")[0]

            display.append(f"{addon_id}")
            addons.append((addon_id, zip_name))

    if not addons:
        dialog.ok("Pliki różne ", "Brak ZIP")
        exit()

    sel = dialog.select("Do pobrania (instrrukcje,opisy i inne zipy)", display)
    if sel == -1:
       exit()

    if sel >= 0:

        addon_id, zip_name = addons[sel]

        # ścieżki
        zip_url = TOOLS_RAW + zip_name
        temp_zip = xbmcvfs.translatePath(f"special://temp/temp/{zip_name}")

        # pobierz ZIP
        try:
            r = requests.get(zip_url, timeout=15)
            with open(temp_zip, "wb") as f:
                f.write(r.content)
        except Exception as e:
            dialog.ok("Pliki", f"Błąd pobierania:\n{e}")
            exit()
    dialog.ok("INFO","Pliki zapisano w: Kodi cache temp\nJak używasz -script.ezmaintenance- to można usuwać pobrane pliki z automatu. Inaczej ręcznie.")


if choice == 1:
    try:
        r = requests.get(TRANS_API, timeout=10)
        data = r.json()
    except Exception as e:
        dialog.ok("Translations PL", f"Błąd:\n{e}")
        exit()

    addons = []
    display = []

    for item in data:
        name = item.get("name", "")

        if not name.endswith(".zip"):
            continue

        addon_id = name.replace(".zip", "")

        status = "[???]"

        try:
            addon = xbmcaddon.Addon(addon_id)
            addon_path = addon.getAddonInfo('path')

            lang_file = os.path.join(
                addon_path,
                "resources",
                "language",
                "resource.language.pl_pl",
                "strings.po"
            )

            if xbmcvfs.exists(lang_file):
                status = "[PL OK]"
            else:
                status = "[BRAK PL]"

        except Exception:
            status = "[BRAK ADDONU]"

        display.append(f"{addon_id} {status}")
        addons.append((addon_id, name))
    if not addons:
        dialog.ok("Translations PL", "Brak ZIP")
        exit()

    sel = dialog.select("Zainstalować plik językowy dla dodatku ?", display)

    if sel < 0:
        exit()

    addon_id, zip_name = addons[sel]

    # sprawdź addon
    try:
        addon = xbmcaddon.Addon(addon_id)
        addon_path = addon.getAddonInfo('path')
    except:
        dialog.ok("Translations PL", "Nie masz tego dodatku")
        exit()

    # ścieżki
    zip_url = TRANS_RAW + zip_name
    temp_zip = xbmcvfs.translatePath(f"special://temp/{zip_name}")
    temp_dir = xbmcvfs.translatePath("special://temp/reslangpl/")

    # pobierz ZIP
    try:
        r = requests.get(zip_url, timeout=15)
        with open(temp_zip, "wb") as f:
            f.write(r.content)
    except Exception as e:
        dialog.ok("Translations PL", f"Błąd pobierania:\n{e}")
        exit()

    # rozpakuj
    try:
        if not os.path.exists(temp_dir):
            os.makedirs(temp_dir)

        with zipfile.ZipFile(temp_zip, 'r') as zip_ref:
            zip_ref.extractall(temp_dir)
    except Exception as e:
        dialog.ok("Translations PL", f"Błąd ZIP:\n{e}")
        exit()

    # kopiowanie
# === ZNAJDŹ strings.po ===
    source_file = None

    for root, dirs, files in os.walk(temp_dir):
        if "strings.po" in files:
            source_file = os.path.join(root, "strings.po")
            break

    if not source_file:
        dialog.ok("Translations PL", "Nie znaleziono strings.po w ZIP")
        exit()

    # === ŚCIEŻKA DOCELOWA ===
    dest_dir = os.path.join(
        addon_path,
        "resources",
        "language",
        "resource.language.pl_pl"
    )

    dest_file = os.path.join(dest_dir, "strings.po")

    try:
        # utwórz katalogi
        if not xbmcvfs.exists(dest_dir):
            xbmcvfs.mkdirs(dest_dir)

        # usuń stary plik
        if xbmcvfs.exists(dest_file):
            xbmcvfs.delete(dest_file)

        # kopiuj plik
        if not xbmcvfs.copy(source_file, dest_file):
            dialog.ok("Translations PL", "Błąd: copy() zwrócił False")
            exit()

    except Exception as e:
        dialog.ok("Translations PL", f"Błąd kopiowania:\n{e}")
        exit()
    dialog.ok(
        "Translations PL",
        "Tłumaczenie zainstalowane.\n\n"
        "Jeśli nie widać zmian:\n"
        "- uruchom ponownie Kodi\n"
        "- lub przeładuj dodatek"
    )
# ========================
# YT-DLP INSTALLER
# ========================
if choice == 2:

    ADDONS_XML_URL = "https://raw.githubusercontent.com/Agaton111/repository.Agaton111/main/addons.xml"

    import xml.etree.ElementTree as ET

    # ========================
    # POBIERZ addons.xml
    # ========================
    try:
        r = requests.get(ADDONS_XML_URL, timeout=10)
        xml_data = r.text
    except Exception as e:
        dialog.ok("Moduły", f"Błąd pobierania addons.xml:\n{e}")
        exit()

    # ========================
    # PARSOWANIE XML
    # ========================
    try:
        root = ET.fromstring(xml_data)
    except Exception as e:
        dialog.ok("Moduły", f"Błąd XML:\n{e}")
        exit()

    modules = []
    display = []

    for addon in root.findall("addon"):
        addon_id = addon.attrib.get("id")
        name = addon.attrib.get("name", addon_id)

        for ext in addon.findall("extension"):
            if ext.attrib.get("point") == "xbmc.python.module":

                # status instalacji
                try:
                    xbmcaddon.Addon(addon_id)
                    status = "[OK]"
                except:
                    status = "[BRAK]"

                display.append(f"{name} {status}")
                modules.append((addon_id, name))
                break

    if not modules:
        dialog.ok("Moduły", "Brak modułów w repo")
        exit()

    # ========================
    # WYBÓR
    # ========================
    sel = dialog.select("Moduły zależności", display)

    if sel < 0:
        exit()

    addon_id, name = modules[sel]

    # ========================
    # INSTALACJA
    # ========================
    xbmc.executebuiltin(f'InstallAddon({addon_id})')

    dialog.ok(
        name,
        "Instalacja uruchomiona.\n"
        "Jeśli nie działa → sprawdź repo / restart Kodi"
    )