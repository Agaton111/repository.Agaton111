import xbmc
import xbmcgui
import xbmcaddon
import requests
#
API_URL = "https://api.github.com/repos/Agaton111/repository.Agaton111/contents/repo/tools"
RAW_BASE = "https://raw.githubusercontent.com/Agaton111/repository.Agaton111/main/repo/tools/"

dialog = xbmcgui.Dialog()

try:
    r = requests.get(API_URL, timeout=10)
    data = r.json()
except Exception as e:
    dialog.ok("Tools To mogą być pakiety z moimi zmianami (nie odpowiadam za szkody)", f"Błąd:\n{e}")
    exit()

addons = []
display = []

for item in data:
    if item["name"].endswith(".zip"):
        zip_name = item["name"]
        addon_id = zip_name.split("-")[0]

        try:
            xbmcaddon.Addon(addon_id)
            status = "✔"
        except:
            status = "❌"

        display.append(f"{status} {addon_id}")
        addons.append((addon_id, zip_name))

if not addons:
    dialog.ok("Tools", "Brak ZIP w folderze")
    exit()

choice = dialog.select("Tools To mogą być pakiety z moimi zmianami (nie odpowiadam za szkody)", display)

if choice >= 0:
    addon_id, zip_name = addons[choice]

    try:
        xbmcaddon.Addon(addon_id)
        dialog.ok("Tools", "Już zainstalowane")
    except:
        zip_url = RAW_BASE + zip_name
        xbmc.executebuiltin(f'InstallAddon({zip_url})')
        dialog.ok("Tools", "Instalacja zakończona")