import xbmc
import xbmcgui
import xbmcaddon
import xbmcvfs
import requests
import zipfile
import os

dialog = xbmcgui.Dialog()

# === API ===
TOOLS_API = "https://api.github.com/repos/Agaton111/repository.Agaton111/contents/repo/tools"
TOOLS_RAW = "https://raw.githubusercontent.com/Agaton111/repository.Agaton111/main/repo/tools/"

TRANS_API = "https://api.github.com/repos/Agaton111/repository.Agaton111/contents/repo/translations"
TRANS_RAW = "https://raw.githubusercontent.com/Agaton111/repository.Agaton111/main/repo/translations/"


# ========================
# MENU GŁÓWNE
# ========================
choice = dialog.select("ResLangPL", ["Tools", "Translations"])

if choice == -1:
    exit()

# ========================
# TOOLS (TWÓJ KOD)
# ========================
if choice == 0:
    try:
        r = requests.get(TOOLS_API, timeout=10)
        data = r.json()
    except Exception as e:
        dialog.ok("Tools", f"Błąd:\n{e}")
        exit()

    addons = []
    display = []

    for item in data:
        if item["name"].endswith(".zip"):
            zip_name = item["name"]
            addon_id = zip_name.split("-")[0]

            try:
                xbmcaddon.Addon(addon_id)
                status = "✔"
            except:
                status = "❌"

            display.append(f"{status} {addon_id}")
            addons.append((addon_id, zip_name))

    if not addons:
        dialog.ok("Tools", "Brak ZIP")
        exit()

    sel = dialog.select("To mogą być pakiety ze zmianami (nie odpowiadam za szkody)", display)
    if sel >= 0:
        addon_id, zip_name = addons[sel]

        try:
            xbmcaddon.Addon(addon_id)
            dialog.ok("Tools", "Już zainstalowane")
        except:
            xbmc.executebuiltin(f'InstallAddon({TOOLS_RAW + zip_name})')
            dialog.ok("Tools", "Instalacja OK")

# ========================
# TRANSLATIONS (NOWE)
# ========================
if choice == 1:
    try:
        r = requests.get(TRANS_API, timeout=10)
        data = r.json()
    except Exception as e:
        dialog.ok("Translations PL", f"Błąd:\n{e}")
        exit()

    addons = []
    display = []

    for item in data:
        if item["name"].endswith(".zip"):
            zip_name = item["name"]
            addon_id = zip_name.replace(".zip", "")

            try:
                xbmcaddon.Addon(addon_id)
                status = "✔"
            except:
                status = "❌"

            display.append(f"{status} {addon_id}")
            addons.append((addon_id, zip_name))

    if not addons:
        dialog.ok("Translations PL", "Brak ZIP")
        exit()

    sel = dialog.select("Translations PL", display)

    if sel < 0:
        exit()

    addon_id, zip_name = addons[sel]

    # sprawdź addon
    try:
        addon = xbmcaddon.Addon(addon_id)
        addon_path = addon.getAddonInfo('path')
    except:
        dialog.ok("Translations", "Nie masz tego dodatku")
        exit()

    # ścieżki
    zip_url = TRANS_RAW + zip_name
    temp_zip = xbmcvfs.translatePath(f"special://temp/{zip_name}")
    temp_dir = xbmcvfs.translatePath("special://temp/reslangpl/")

    # pobierz ZIP
    try:
        r = requests.get(zip_url, timeout=15)
        with open(temp_zip, "wb") as f:
            f.write(r.content)
    except Exception as e:
        dialog.ok("Translations", f"Błąd pobierania:\n{e}")
        exit()

    # rozpakuj
    try:
        if not os.path.exists(temp_dir):
            os.makedirs(temp_dir)

        with zipfile.ZipFile(temp_zip, 'r') as zip_ref:
            zip_ref.extractall(temp_dir)
    except Exception as e:
        dialog.ok("Translations", f"Błąd ZIP:\n{e}")
        exit()

    # kopiowanie
    source = os.path.join(temp_dir, "resource.language.pl_pl")
    dest = os.path.join(addon_path, "resources", "resource.language.pl_pl")

    try:
        if xbmcvfs.exists(dest):
            xbmcvfs.rmdir(dest, True)

        xbmcvfs.copy(source, dest)
    except Exception as e:
        dialog.ok("Translations", f"Błąd kopiowania:\n{e}")
        exit()

    dialog.ok("Translations", "Tłumaczenie zainstalowane ✅")