# -*- coding: utf-8 -*-
import os,sys
import xbmc
import pyxbmct
try:

    from urllib.request import Request as urllib_Request
    from urllib.request import urlopen

    from urllib.parse import urlencode, quote_plus, unquote, parse_qsl, parse_qs

except ImportError:

    from urllib2 import Request as urllib_Request
    from urllib2 import urlopen

    from urllib import urlencode, quote_plus, unquote
    from urlparse import parse_qsl, parse_qs

import xbmcvfs
import xbmcaddon
import re
import xbmcplugin
import time
import xbmcgui
import requests
from requests.utils import requote_uri

mysettings = xbmcaddon.Addon(id = 'script.epgagaton19')
home = mysettings.getAddonInfo('path')
fotka1 = xbmcvfs.translatePath(os.path.join(home, 'resources/media/saturn.jpg'))
fotka2 = xbmcvfs.translatePath(os.path.join(home, 'resources/media/icon.png'))
fotka3 = xbmcvfs.translatePath(os.path.join(home, 'resources/media/cube.jpg'))
url1 = 'https://www.themoviedb.org/search?language=pl-PL&query='
url2='https://www.themoviedb.org'
path = xbmc.getInfoLabel('ListItem.FileNameAndPath')


API_KEY = xbmcaddon.Addon().getSetting("api_key")

if not API_KEY:
    xbmcgui.Dialog().ok("Błąd ", " Załóż darmowe konto na : https://www.themoviedb.org/settings/api .Pobierz API KEY i wpisz w ustawieniach dodatku")
    sys.exit()
def get_title():
    title = xbmc.getInfoLabel("ListItem.Title") if xbmc.getInfoLabel("ListItem.Title") else xbmc.getInfoLabel("ListItem.Label")
    return title

title1 = get_title()
xbmcgui.Dialog().notification(heading='Otwieram',message='Proszę czekać..',
            icon=xbmcgui.NOTIFICATION_WARNING,time=2500,sound=False)
title1 = re.sub(r'^\s*PL\s*-\s*', '', title1, flags=re.IGNORECASE)
title1 = re.sub(r'(dubbing|lektor|\(\d{4}\))', '', title1, flags=re.IGNORECASE)
title1 = re.sub(r'\s+', ' ', title1).strip()

if '[/COLOR' in title1:
    title1 = re.sub('[[](.+?)[]]', "", title1)


if '|' in title1:
    if len (title1)>20:
        title1= title1.split("|")
        title1=(title1[1])
        title1=str (title1)
    else:
        title1 =title1.replace('|',' ')

if re.search( r'\d\d:\d\d:\d\d', title1):
    title1 = re.sub(r'\d\d:\d\d:\d\d', "", title1)

b=title1.startswith("(")
if b == True:
    title1= title1.split(")")
    title=(title1[1])+' '+(title1[0])+')'
    try:
       matchObj =re.search(r'(?P<left>[0-9]+ )(?P<middle>[\D\d\]+ )(?P<right>\([0-9]+)', title, re.I)
       title =((matchObj.group('left'))+matchObj.group('middle'))+'y:'+(matchObj.group('right'))
       title =title.replace('(','')
    except:
       title=title.replace(')','').replace('(','y:')
else:
    title =str (title1)


#title3=requests.utils.quote(title)

url =url1 +title
url=requote_uri(url)

def make_request(url):
    req = urllib_Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0')
    response = urlopen(req)
    link = response.read()
    response.close()
    link = link.decode(encoding='utf-8', errors='strict')
    return link


def nowelinki(proba=0):
    global title

    # 🔴 limit prób (max 2)
    if proba >= 2:
        xbmcgui.Dialog().ok("Brak wyników", f"Nie znaleziono:\n{title}")
        sys.exit()

    url_api = f"https://api.themoviedb.org/3/search/movie?api_key={API_KEY}&query={quote_plus(title)}"
    data = requests.get(url_api).json()
    results = data.get("results", [])

    if results:
        lista = []
        for r in results[:10]:
            nazwa = r.get("title", "Brak")
            rok = r.get("release_date", "")[:4] if r.get("release_date") else ""
            lista.append(f"{nazwa} ({rok})")

        # jeśli tylko 1 wynik → pomiń okno wyboru
        if len(lista) == 1:
            return results[0]["id"]

        dialog = xbmcgui.Dialog()
        wybor = dialog.select("Wybierz film", lista)

        if wybor != -1:
            return results[wybor]["id"]

    # brak wyników → poprawka
    keyboard = xbmc.Keyboard(title, "Popraw tytuł")
    keyboard.doModal()

    if keyboard.isConfirmed():
        title = keyboard.getText().strip()
        return nowelinki(proba + 1)

    sys.exit()

movie_id = nowelinki()

url_api = f"https://api.themoviedb.org/3/movie/{movie_id}?api_key={API_KEY}&append_to_response=credits&language=pl-PL"
data2 = requests.get(url_api).json()

opis2 = data2.get("overview", "Brak opisu")

poster_path = data2.get("poster_path")
plakat3 = "https://image.tmdb.org/t/p/w500" + poster_path if poster_path else fotka1

tytulfil2 = data2.get("title", title)

runtime = data2.get("runtime")
czastrw2 = str(runtime) + " min" if runtime else "Brak"

genres = data2.get("genres", [])
gatunek22 = " - " + ", ".join([g["name"] for g in genres])

cast = data2.get("credits", {}).get("cast", [])
obsada11 = cast[0]["name"] if len(cast)>0 else "Brak"
obsada22 = cast[1]["name"] if len(cast)>1 else "Brak"
obsada33 = cast[2]["name"] if len(cast)>2 else "Brak"
obsada44 = cast[3]["name"] if len(cast)>3 else "Brak"

def actor_img(i):
    if len(cast) > i and cast[i].get("profile_path"):
        return "https://image.tmdb.org/t/p/w200" + cast[i]["profile_path"]
    return fotka2

fotoaktor11 = actor_img(0)
fotoaktor22 = actor_img(1)
fotoaktor33 = actor_img(2)
fotoaktor44 = actor_img(3)

###########################################################################################
def aktor_opis(i):
    if len(cast) > i:
        actor_id = cast[i]["id"]
        url = f"https://api.themoviedb.org/3/person/{actor_id}?api_key={API_KEY}&language=pl-PL"
        data = requests.get(url).json()
        return data.get("biography", "Brak opisu")
    return "Brak opisu"

opakt1 = aktor_opis(0)
opakt2 = aktor_opis(1)
opakt3 = aktor_opis(2)
opakt4 = aktor_opis(3)


#####################################################################################

ACTION_PREVIOUS_MENU = 10
ACTION_MOUSE_LEFT_CLICK = 100
ACTION_NAV_BACK = 92
ACTION_SELECT_ITEM = 7
ACTION_MOVE_LEFT = 1
ACTION_MOVE_RIGHT = 2
ACTION_PAGE_DOWN = 6
ACTION_MOVE_UP = 3
ACTION_MOVE_DOWN = 4
ACTION_PAGE_UP = 5
ACTION_FIRST_PAGE  = 159
ACTION_LAST_PAGE  = 160

# Create a class for our UI
class MyAddon(pyxbmct.AddonDialogWindow):

    def __init__(self, title=''):
         super(MyAddon, self).__init__(title)
         self.setGeometry(1000, 650, 15, 7)
         self.set_info_controls()
         self.set_active_controls()
         self.set_navigation()
         self.connect(pyxbmct.ACTION_NAV_BACK, self.close,)
    def set_info_controls(self):

        # Image1 plakat
        self.image = pyxbmct.Image('',aspectRatio=2)
        self.placeControl(self.image, 0, 4, 14, 3)
        self.image.setImage(str(plakat3))
        # Image2
        self.image2 = pyxbmct.Image('',aspectRatio=2)
        self.placeControl(self.image2, 9, 0, 5, 1)
        self.image2.setImage(str(fotoaktor11))
        # Image3
        self.image3 = pyxbmct.Image('',aspectRatio=2)
        self.placeControl(self.image3, 9, 1, 5, 1)
        self.image3.setImage(str(fotoaktor22))
        # Image4
        self.image4 = pyxbmct.Image('',aspectRatio=2)
        self.placeControl(self.image4, 9, 2, 5, 1)
        self.image4.setImage(str(fotoaktor33))
        # Image4
        self.image6 = pyxbmct.Image('',aspectRatio=2)
        self.placeControl(self.image6, 9, 3, 5, 1)
        self.image6.setImage(str(fotoaktor44))
        # Image5 TextBox
        self.image5 = pyxbmct.Image('',aspectRatio=1)
        self.placeControl(self.image5, 0, 0, 9, 4)
        self.image5.setImage(str(fotka3))
        # Textbox
        self.textbox = pyxbmct.TextBox(font ='font15',textColor='0xffffe4b5')
#        self.textbox = pyxbmct.TextBox(font ='font15',textColor='0xff76defa')
        self.placeControl(self.textbox, 1, 0, 8, 4)
        self.textbox.setText(opis2)
        self.textbox.autoScroll(8000, 2000, 2000)

        self.fade_label = pyxbmct.FadeLabel()
        self.placeControl(self.fade_label, 0, 0, 2, 4)
        self.fade_label.addLabel(gatunek22 + '   Czas : ' +czastrw2)

    def set_active_controls(self):
        int_label = pyxbmct.Label
        # Button
        self.button = pyxbmct.Button('Close ')
        self.placeControl(self.button, 14, 6)

        self.button7 = pyxbmct.Button('Play (tylko gdy z innej wtyczki)')
        self.placeControl(self.button7, 14, 5)
        self.connect(self.button7, self.button7_update)

        self.button2 = pyxbmct.Button(obsada22)
        self.placeControl(self.button2, 14, 1)
        self.connect(self.button2, self.button2_update)

        self.button3 = pyxbmct.Button(obsada33)
        self.placeControl(self.button3, 14, 2)
        self.connect(self.button3, self.button3_update)

        self.button4 = pyxbmct.Button('Opis film')
        self.placeControl(self.button4, 14, 4)
        self.connect(self.button4, self.button4_update)

        self.button5 = pyxbmct.Button(obsada11)
        self.placeControl(self.button5, 14, 0)
        self.connect(self.button5, self.button5_update)

        self.button6 = pyxbmct.Button(obsada44)
        self.placeControl(self.button6, 14, 3)
        self.connect(self.button6, self.button6_update)
        # Connect control .
        self.connect(self.button, self.close)
        self.connect(ACTION_MOVE_LEFT, self.navigat)
        self.connect(ACTION_MOVE_RIGHT, self.navigat2)

    def button2_update(self):
        self.textbox.setText(opakt2)
        self.image.setImage('')
        self.image.setImage(fotoaktor22)
        self.fade_label.reset()
        self.fade_label.addLabel(obsada22)

    def button3_update(self):
        self.textbox.setText(opakt3)
        self.image.setImage('')
        self.image.setImage(fotoaktor33)
        self.fade_label.reset()
        self.fade_label.addLabel(obsada33)

    def button4_update(self):
        self.textbox.setText(opis2)
        self.image.setImage('')
        self.image.setImage(plakat3)
        self.fade_label.reset()
        self.fade_label.addLabel(gatunek22 + '   Czas : ' +czastrw2)

    def button5_update(self):
        self.textbox.setText(opakt1)
        self.image.setImage('')
        self.image.setImage(fotoaktor11)
        self.fade_label.reset()
        self.fade_label.addLabel(obsada11)

    def button6_update(self):
        self.textbox.setText(opakt4)
        self.image.setImage('')
        self.image.setImage(fotoaktor44)
        self.fade_label.reset()
        self.fade_label.addLabel(obsada44)

    def button7_update(self):
        xbmc.Player().play(path)
        xbmc.sleep(100)
        self.close()

    def set_navigation(self):
        self.setFocus(self.button)

    def navigat(self):
       self.setFocus(self.button)

    def navigat2(self):
        try:
            if self.getFocus() == self.button5:
               self.setFocus(self.button2)
            if self.getFocus() == self.button2:
               self.setFocus(self.button3)
            if self.getFocus() == self.button3:
               self.setFocus(self.button6)
            if self.getFocus() == self.button6:
               self.setFocus(self.button4)
            if self.getFocus() == self.button4:
               self.setFocus(self.button7)
            if self.getFocus() == self.button7:
               self.setFocus(self.button)
            if self.getFocus() == self.button:
               self.setFocus(self.button5)
        except:
            pass

    def setAnimation(self, control):
        # Set fade animation for all add-on window controls
        control.setAnimations([('WindowOpen', 'effect=fade start=0 end=100 time=500',),
                                ('WindowClose', 'effect=fade start=100 end=0 time=500',)])

if __name__ == '__main__':
    myaddon = MyAddon('Film  "'+tytulfil2+'"       opis pobrano z TMDB')
    myaddon.doModal()
    del myaddon
