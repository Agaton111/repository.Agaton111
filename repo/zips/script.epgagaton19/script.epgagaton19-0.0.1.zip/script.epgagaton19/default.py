## -*- coding: utf-8 -*-
import os,sys

try:

    from urllib.request import Request as urllib_Request
    from urllib.request import urlopen

    from urllib.parse import urlencode, quote_plus, unquote, parse_qsl, parse_qs

except ImportError:

    from urllib2 import Request as urllib_Request
    from urllib2 import urlopen

    from urllib import urlencode, quote_plus, unquote
    from urlparse import parse_qsl, parse_qs

import xbmcvfs
import xbmcaddon
import re
import xbmcplugin
import pyxbmct
import time
import xbmcgui
import requests
from requests.utils import requote_uri
try:
 from cmf3 import parseDOM
except:
 from cmf2 import parseDOM
#xbmc.log ( 'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx  wiadomość', xbmc.LOGNOTICE)
#pyxbmct.skin.estuary = False  # False:użyj starego projektu

mysettings = xbmcaddon.Addon(id = 'script.epgagaton19')
home = mysettings.getAddonInfo('path')
fotka1 = xbmcvfs.translatePath(os.path.join(home, 'resources/saturn.jpg'))
fotka2 = xbmcvfs.translatePath(os.path.join(home, 'resources/icon.png'))
fotka3 = xbmcvfs.translatePath(os.path.join(home, 'resources/cube.jpg'))
url1 = 'https://www.themoviedb.org/search?language=pl-PL&query='
url2='https://www.themoviedb.org'
path = xbmc.getInfoLabel('ListItem.FileNameAndPath')
##file = open(r'C:\Users\Grzegorz\Desktop\path.txt', 'w')
##file.write(str(path))
##file.close()

def get_title():
    title = xbmc.getInfoLabel("ListItem.Title") if xbmc.getInfoLabel("ListItem.Title") else xbmc.getInfoLabel("ListItem.Label")
    return title

title1 = get_title()
xbmcgui.Dialog().notification(heading='Otwieram',message='Proszę czekać..',
            icon=xbmcgui.NOTIFICATION_WARNING,time=2500,sound=False)
if '[/COLOR' in title1:
    title1 = re.sub('[[](.+?)[]]', "", title1)
if '|' in title1:
    if len (title1)>20:
        title1= title1.split("|")
        title1=(title1[1])
        title1=str (title1)
    else:
        title1 =title1.replace('|',' ')

if re.search( r'\d\d:\d\d:\d\d', title1):
    title1 = re.sub(r'\d\d:\d\d:\d\d', "", title1)

b=title1.startswith("(")
if b == True:
    title1= title1.split(")")
    title=(title1[1])+' '+(title1[0])+')'
    try:
       matchObj =re.search(r'(?P<left>[0-9]+ )(?P<middle>[\D\d\]+ )(?P<right>\([0-9]+)', title, re.I)
       title =((matchObj.group('left'))+matchObj.group('middle'))+'y:'+(matchObj.group('right'))
       title =title.replace('(','')
    except:
       title=title.replace(')','').replace('(','y:')
else:
    title =str (title1)

#title3=requests.utils.quote(title)

url =url1 +title
url=requote_uri(url)

def make_request(url):
    req = urllib_Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0')
    response = urlopen(req)
    link = response.read()
    response.close()
    link = link.decode(encoding='utf-8', errors='strict')
    return link


def PLchar(char):
    if type(char) is not str:
        char=char.encode('utf-8')
    char = char.replace('\\u0105','\xc4\x85').replace('\\u0104','\xc4\x84')
    char = char.replace('\\u0107','\xc4\x87').replace('\\u0106','\xc4\x86') #E9
    char = char.replace('\\u00e9','\xc3\xa9').replace('\\u00C9','\xc3\x89') #E9
    char = char.replace('\\u0119','\xc4\x99').replace('\\u0118','\xc4\x98')
    char = char.replace('\\u0142','\xc5\x82').replace('\\u0141','\xc5\x81')
    char = char.replace('\\u0144','\xc5\x84').replace('\\u0144','\xc5\x83')
    char = char.replace('\\u00f3','\xc3\xb3').replace('\\u00d3','\xc3\x93')
    char = char.replace('\\u015b','\xc5\x9b').replace('\\u015a','\xc5\x9a')
    char = char.replace('\\u017a','\xc5\xba').replace('\\u0179','\xc5\xb9')
    char = char.replace('\\u017c','\xc5\xbc').replace('\\u017b','\xc5\xbb')
    char = char.replace('&#8217;',"'")
    char = char.replace('&#8211;',"-")
    char = char.replace('&#8230;',"...")
    char = char.replace('&#8222;','"').replace('&#8221;','"')
    char = char.replace('[&hellip;]',"...")
    char = char.replace('&#038;',"&").replace('&ndash;','-').replace('&quot;','-')
    char = char.replace('&nbsp;',".").replace('&amp;','&').replace('&oacute;','ó').replace('<br/>','')
    return char


def nowelinki():
    dootwar = url
    data =''
    data1 = ''
    nowlink2 =''
    data1 = make_request(dootwar)
    data = parseDOM(data1,'div', attrs={'class': "poster" })
    nlinki = parseDOM(data, 'a',ret = "href")

    if  len (nlinki) > 0:
        nowlink = nlinki[0]
        nowlink2 ='https://www.themoviedb.org'+ nowlink
        return  nowlink2;
    else:
        tak =xbmcgui.Dialog().yesno('Wynik','Niewyszukano \nCzy szukać dalej ?')
        if tak :
            keyboard = xbmc.Keyboard()
            keyboard.setHeading('[COLOR lime][B] Możesz użyć "y:" do wyszukiwania według roku. np: gwiezdne wojny y:1977. [/B][/COLOR]')
            keyboard.doModal()
            if keyboard.isConfirmed():
               global title
               title = keyboard.getText().strip()
               dootwar = url1 + title
               dootwar=requote_uri(dootwar)
               data =''
               data1 = ''
               nowlink2 =''
               data1 = make_request(dootwar)
               data = parseDOM(data1,'div', attrs={'class': "poster" })
               nlinki = parseDOM(data, 'a',ret = "href")
               if  len (nlinki) > 0:
                  nowlink = nlinki[0]
                  nowlink2 ='https://www.themoviedb.org'+ nowlink
                  return  nowlink2;
               else:
                  xbmcgui.Dialog().ok('Wynik','Niewyszukano tytułu:  '+title)
                  sys.exit()
        else:
            sys.exit()

nowlink2=nowelinki()
#xbmcgui.Dialog().textviewer('nowlink2 ', str(nowlink2))
#########################################################################################

dootwar2 = nowlink2
data2 = ''
data2 = make_request(dootwar2)

fragment = parseDOM(data2,'div', attrs={'class': "header_info" })
opis = parseDOM(fragment, 'div', attrs={'class': "overview" })
opis1 =PLchar(opis[0])
opis2 =str(opis1)
opis2 = opis2.replace ("<p>","").replace("</p>","")

plakat = parseDOM(data2,'meta property="og:image"' ,ret ='content')
if  len (plakat) > 0 :
    plakat1 =plakat [0]
    plakat2=str(plakat1)
    plakat3 =url2+plakat2
else:
    plakat3=fotka1

fragment2 = parseDOM(data2,'section', attrs={'class': "header poster" })
fragment3 = parseDOM(data2,'div', attrs={'class': "content_wrapper" })
fragment4 =parseDOM (fragment3, 'a')
fragment5 =parseDOM (fragment3, 'li',attrs={'class': "card" })
stronaktor =parseDOM (fragment5,'p')
stronaktor1 =parseDOM (stronaktor,'a',ret ='href')
obsada=parseDOM (stronaktor,'a')
fotoaktor =parseDOM (fragment4,'img loading="lazy"',ret='src')

##xbmcgui.Dialog().textviewer('fotoaktor ',str  (fotoaktor))
##file = open('C:\Users\Grzegorz\Desktop\or.txt', 'w')
##file.write(str(fotoaktor))
##file.close()

if  len (stronaktor1) >= 4 :
    stronaktor11 =stronaktor1 [0]
    stronaktor111=str(stronaktor11)
    stronaktor1111 =url2+stronaktor111
    stronaktor22 =stronaktor1 [1]
    stronaktor222=str(stronaktor22)
    stronaktor2222 =url2+stronaktor222
    stronaktor33 =stronaktor1 [2]
    stronaktor333=str(stronaktor33)
    stronaktor3333 =url2+stronaktor333
    stronaktor44 =stronaktor1 [3]
    stronaktor444=str(stronaktor44)
    stronaktor4444 =url2+stronaktor444

elif  len (stronaktor1) == 3 :
    stronaktor11 =stronaktor1 [0]
    stronaktor111=str(stronaktor11)
    stronaktor1111 =url2+stronaktor111
    stronaktor22 =stronaktor1 [1]
    stronaktor222=str(stronaktor22)
    stronaktor2222 =url2+stronaktor222
    stronaktor33 =stronaktor1 [2]
    stronaktor333=str(stronaktor33)
    stronaktor3333 =url2+stronaktor333
    stronaktor4444 =url2

elif  len (stronaktor1) == 2 :
    stronaktor11 =stronaktor1 [0]
    stronaktor111=str(stronaktor11)
    stronaktor1111 =url2+stronaktor111
    stronaktor22 =stronaktor1 [1]
    stronaktor222=str(stronaktor22)
    stronaktor2222 =url2+stronaktor222
    stronaktor3333 =url2
    stronaktor3333 =url2
    stronaktor4444 =url2

elif  len (stronaktor1) == 1 :
    stronaktor11 =stronaktor1 [0]
    stronaktor111=str(stronaktor11)
    stronaktor1111 =url2+stronaktor111
    stronaktor2222 =url2
    stronaktor3333 =url2
    stronaktor4444 =url2

else:
    stronaktor1111=url2
    stronaktor2222=url2
    stronaktor3333=url2
    stronaktor4444=url2
#******************    ------------------ ////////////////
if  len (obsada) > 3 :
    obsada1 =obsada [0]
    obsada11=str(obsada1)
    obsada2 =obsada [1]
    obsada22=str(obsada2)
    obsada3 =obsada [2]
    obsada33=str(obsada3)
    obsada4 =obsada [3]
    obsada44=str(obsada4)
else:
    obsada11=''
    obsada22=''
    obsada33=''
    obsada44=''

if  len (fotoaktor) > 3 :
    fotoaktor1=(fotoaktor[0])
    fotoaktor11=str(fotoaktor1)
    if 'https:'in fotoaktor11:
        fotoaktor11=fotoaktor11
    else:
        fotoaktor11 =url2+fotoaktor11
    fotoaktor2=(fotoaktor[1])
    fotoaktor22=str(fotoaktor2)
    if 'https:'in fotoaktor22:
        fotoaktor22=fotoaktor22
    else:
        fotoaktor22 =url2+fotoaktor22
    fotoaktor3=(fotoaktor[2])
    fotoaktor33=str(fotoaktor3)
    if 'https:'in fotoaktor33:
        fotoaktor33=fotoaktor33
    else:
        fotoaktor33 =url2+fotoaktor33
    fotoaktor4=(fotoaktor[3])
    fotoaktor44=str(fotoaktor4)
    if 'https:'in fotoaktor44:
        fotoaktor44=fotoaktor44
    else:
        fotoaktor44 =url2+fotoaktor44

else:
    fotoaktor11=fotka2
    fotoaktor22=fotka2
    fotoaktor33=fotka2
    fotoaktor44=fotka2

tytul = parseDOM(fragment2,'h2')
tytulfil = parseDOM(tytul,'a')

if  len (tytulfil) > 0 :
    tytulfil1 =PLchar(tytulfil[0])
    tytulfil2=str(tytulfil1)

else:
    tytulfil2=title

czastrw= parseDOM(fragment2, 'span',attrs={'class': "runtime"})
if  len (czastrw) > 0 :
    czastrw1=(czastrw[0])
    czastrw2=str(czastrw1)
else:
    czastrw2='Brak '

gatundlugi = parseDOM(fragment2, 'span',attrs={'class': "genres"})
gatunek = parseDOM(gatundlugi, 'a')
gatunek2 = str (gatunek)
gatunek22=gatunek2.replace('[',' - ').replace("u'",'').replace("]",'').replace("'",'')
gatunek22=PLchar(gatunek22)
###########################################################################################
def opisakto(strpobr):
    fragment = parseDOM(strpobr,'meta property="og:description"',ret ='content')
    if len (fragment) > 0:
        fragment1=PLchar(fragment[0])
        fragment2 =str(fragment1)
    else:
        fragment2=('Brak opisu')
        return fragment2

    if len (fragment2)==0:
        fragment2=('Brak opisu')
        return fragment2
    else:
        return fragment2

dootwar3 = stronaktor1111
data3 = ''
data3 = make_request(dootwar3)
strpobr=data3
opakt1=opisakto(strpobr)

dootwar3 = stronaktor2222
data4 = ''
data4 = make_request(dootwar3)
strpobr=data4
opakt2=opisakto(strpobr)

dootwar3 = stronaktor3333
data5 = ''
data5 = make_request(dootwar3)
strpobr=data5
opakt3=opisakto(strpobr)

dootwar3 = stronaktor4444
data6 = ''
data6 = make_request(dootwar3)
strpobr=data6
opakt4=opisakto(strpobr)

#xbmcgui.Dialog().textviewer('opakt2 ', str(opakt2))

#####################################################################################

ACTION_PREVIOUS_MENU = 10
ACTION_MOUSE_LEFT_CLICK = 100
ACTION_NAV_BACK = 92
ACTION_SELECT_ITEM = 7
ACTION_MOVE_LEFT = 1
ACTION_MOVE_RIGHT = 2
ACTION_PAGE_DOWN = 6
ACTION_MOVE_UP = 3
ACTION_MOVE_DOWN = 4
ACTION_PAGE_UP = 5
ACTION_FIRST_PAGE  = 159
ACTION_LAST_PAGE  = 160

# Create a class for our UI
class MyAddon(pyxbmct.AddonDialogWindow):

    def __init__(self, title=''):
         super(MyAddon, self).__init__(title)
         self.setGeometry(1000, 650, 15, 7)
         self.set_info_controls()
         self.set_active_controls()
         self.set_navigation()
         self.connect(pyxbmct.ACTION_NAV_BACK, self.close,)
    def set_info_controls(self):
        # Image1 plakat
        self.image = pyxbmct.Image('',aspectRatio=2)
        self.placeControl(self.image, 0, 4, 14, 3)
        self.image.setImage(str(plakat3))
        # Image2
        self.image2 = pyxbmct.Image('',aspectRatio=2)
        self.placeControl(self.image2, 9, 0, 5, 1)
        self.image2.setImage(str(fotoaktor11))
        # Image3
        self.image3 = pyxbmct.Image('',aspectRatio=2)
        self.placeControl(self.image3, 9, 1, 5, 1)
        self.image3.setImage(str(fotoaktor22))
        # Image4
        self.image4 = pyxbmct.Image('',aspectRatio=2)
        self.placeControl(self.image4, 9, 2, 5, 1)
        self.image4.setImage(str(fotoaktor33))
        # Image4
        self.image6 = pyxbmct.Image('',aspectRatio=2)
        self.placeControl(self.image6, 9, 3, 5, 1)
        self.image6.setImage(str(fotoaktor44))
        # Image5 TextBox
        self.image5 = pyxbmct.Image('',aspectRatio=1)
        self.placeControl(self.image5, 0, 0, 9, 4)
        self.image5.setImage(str(fotka3))
        # Textbox
        self.textbox = pyxbmct.TextBox(font ='font15',textColor='0xffffe4b5')
#        self.textbox = pyxbmct.TextBox(font ='font15',textColor='0xff76defa')
        self.placeControl(self.textbox, 1, 0, 8, 4)
        self.textbox.setText(opis2)
        self.textbox.autoScroll(8000, 2000, 2000)

        self.fade_label = pyxbmct.FadeLabel()
        self.placeControl(self.fade_label, 0, 0, 2, 4)
        self.fade_label.addLabel(gatunek22 + '   Czas : ' +czastrw2)

    def set_active_controls(self):
        int_label = pyxbmct.Label
        # Button
        self.button = pyxbmct.Button('Close ')
        self.placeControl(self.button, 14, 6)

        self.button7 = pyxbmct.Button('Play (tylko gdy z innej wtyczki)')
        self.placeControl(self.button7, 14, 5)
        self.connect(self.button7, self.button7_update)

        self.button2 = pyxbmct.Button(obsada22)
        self.placeControl(self.button2, 14, 1)
        self.connect(self.button2, self.button2_update)

        self.button3 = pyxbmct.Button(obsada33)
        self.placeControl(self.button3, 14, 2)
        self.connect(self.button3, self.button3_update)

        self.button4 = pyxbmct.Button('Opis film')
        self.placeControl(self.button4, 14, 4)
        self.connect(self.button4, self.button4_update)

        self.button5 = pyxbmct.Button(obsada11)
        self.placeControl(self.button5, 14, 0)
        self.connect(self.button5, self.button5_update)

        self.button6 = pyxbmct.Button(obsada44)
        self.placeControl(self.button6, 14, 3)
        self.connect(self.button6, self.button6_update)
        # Connect control .
        self.connect(self.button, self.close)
        self.connect(ACTION_MOVE_LEFT, self.navigat)
        self.connect(ACTION_MOVE_RIGHT, self.navigat2)

    def button2_update(self):
        self.textbox.setText(opakt2)
        self.image.setImage('')
        self.image.setImage(fotoaktor22)
        self.fade_label.reset()
        self.fade_label.addLabel(obsada22)

    def button3_update(self):
        self.textbox.setText(opakt3)
        self.image.setImage('')
        self.image.setImage(fotoaktor33)
        self.fade_label.reset()
        self.fade_label.addLabel(obsada33)

    def button4_update(self):
        self.textbox.setText(opis2)
        self.image.setImage('')
        self.image.setImage(plakat3)
        self.fade_label.reset()
        self.fade_label.addLabel(gatunek22 + '   Czas : ' +czastrw2)

    def button5_update(self):
        self.textbox.setText(opakt1)
        self.image.setImage('')
        self.image.setImage(fotoaktor11)
        self.fade_label.reset()
        self.fade_label.addLabel(obsada11)

    def button6_update(self):
        self.textbox.setText(opakt4)
        self.image.setImage('')
        self.image.setImage(fotoaktor44)
        self.fade_label.reset()
        self.fade_label.addLabel(obsada44)

    def button7_update(self):
        xbmc.Player().play(path)
        xbmc.sleep(100)
        self.close()

    def set_navigation(self):
        self.setFocus(self.button)

    def navigat(self):
       self.setFocus(self.button)

    def navigat2(self):
        try:
            if self.getFocus() == self.button5:
               self.setFocus(self.button2)
            if self.getFocus() == self.button2:
               self.setFocus(self.button3)
            if self.getFocus() == self.button3:
               self.setFocus(self.button6)
            if self.getFocus() == self.button6:
               self.setFocus(self.button4)
            if self.getFocus() == self.button4:
               self.setFocus(self.button7)
            if self.getFocus() == self.button7:
               self.setFocus(self.button)
            if self.getFocus() == self.button:
               self.setFocus(self.button5)
        except:
            pass

    def setAnimation(self, control):
        # Set fade animation for all add-on window controls
        control.setAnimations([('WindowOpen', 'effect=fade start=0 end=100 time=500',),
                                ('WindowClose', 'effect=fade start=100 end=0 time=500',)])

if __name__ == '__main__':
    myaddon = MyAddon('Film  "'+tytulfil2+'"       opis pobrano z TMDB')
    myaddon.doModal()
    del myaddon
