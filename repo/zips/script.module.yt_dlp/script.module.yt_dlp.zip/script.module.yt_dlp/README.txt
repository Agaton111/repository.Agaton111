===========================================
Instrukcja: Jak zbudować script.module.yt_dlp (czysty)
===========================================

1. Pobierz najnowszy release yt-dlp z GitHub:
   https://github.com/yt-dlp/yt-dlp/releases/latest

2. Rozpakuj archiwum (Source code .zip lub .tar.gz).

3. Znajdź katalog 'yt_dlp' w źródłach (powinien zawierać __init__.py, utils.py, extractor/, downloader/, ...).

4. Skopiuj cały katalog 'yt_dlp' do:
       script.module.yt_dlp/lib/yt_dlp/

   UWAGA: w tym szablonie folder lib/yt_dlp jest pusty. 
   Po wklejeniu, powinny być tam pliki jak __init__.py, update.py, utils.py oraz podfoldery.

5. (Opcjonalnie) Zaktualizuj plik addon.xml:
   - Zmień <version> na numer wersji yt-dlp (np. 2025.09.30)
   - W polu provider-name wpisz np. "yt-dlp developers".
   - Dodaj plik LICENSE z repozytorium yt-dlp do głównego folderu dodatku (to wymóg licencji MIT).

6. Spakuj cały folder script.module.yt_dlp jako ZIP:
   Nazwa pliku np. script.module.yt_dlp-2025.09.30.zip

7. W Kodi: Add-ons → Install from zip file → wybierz swój plik.

8. W swojej wtyczce dopisz w addon.xml:
   <import addon="script.module.yt_dlp" />

===========================================
UWAGA: Ten szablon NIE zawiera żadnych plików .dll ani .exe.
       yt-dlp to czysty Python i powinien działać w Kodi 20+ (Python 3.10+) i Kodi 21 (Python 3.11).
===========================================
