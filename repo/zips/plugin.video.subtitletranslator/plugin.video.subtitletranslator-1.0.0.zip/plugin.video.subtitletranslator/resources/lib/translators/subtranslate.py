# -*- coding: utf-8 -*-

import requests
import xbmc
import xbmcaddon

ADDON = xbmcaddon.Addon()

API_URL = "https://subtranslate.xyz/api"

session = requests.Session()

def translate_subtranslate(text, target_lang):

    payload = {
        "content": text,
        "filename": "translated.srt",
        "language": target_lang,
        "netflixFormat": False
    }

    session.get(
        "https://subtranslate.xyz/translate",
        timeout=10
    )

    try:

        response = session.post(
            API_URL,
            json=payload,
            timeout=200
        )

        xbmc.log(
            "[SubtitleTranslator] STATUS: %s" % response.status_code,
            xbmc.LOGINFO
        )

        if response.status_code != 200:
            return None

        raw = response.text

        lines = raw.splitlines()

        cleaned = []

        for line in lines:

            if line.startswith("__STATUS__:"):
                continue

            cleaned.append(line)

        final_text = "\n".join(cleaned).strip()

        return final_text

    except Exception as e:

        xbmc.log(
            "[SubtitleTranslator] SUBTRANSLATE ERROR: %s" % str(e),
            xbmc.LOGERROR
        )

        return None