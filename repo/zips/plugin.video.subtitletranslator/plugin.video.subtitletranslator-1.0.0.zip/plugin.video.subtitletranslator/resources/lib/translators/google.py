# -*- coding: utf-8 -*-
import requests
import xbmc
import xbmcaddon
import xbmcgui


ADDON = xbmcaddon.Addon()
LANG_MAP = {
    "Polish": "pl",
    "English": "en",
    "German": "de",
    "French": "fr",
    "Spanish": "es",
    "Italian": "it",
}

selected_language = ADDON.getSetting("target_lang")
target_lang = LANG_MAP.get(selected_language, "pl")

def translate_google(text, target_lang):


    api_key = ADDON.getSetting(
        "google_api"
    )

    try:

        # =====================================================
        # OFFICIAL API
        # =====================================================

        if api_key:

            url = (
                "https://translation.googleapis.com/"
                "language/translate/v2"
            )

            response = requests.post(
                url,
                params={
                    "key": api_key
                },
                json={
                    "q": text,
                    "target": target_lang,
                    "format": "text"
                },
                timeout=30
            )

            xbmc.log(
                "[SubtitleTranslator] GOOGLE API STATUS: %s"
                % response.status_code,
                xbmc.LOGINFO
            )

            xbmc.log(
                "[SubtitleTranslator] GOOGLE API RESPONSE: %s"
                % response.text[:500],
                xbmc.LOGINFO
            )

            if response.status_code == 200:

                data = response.json()

                return data["data"][
                    "translations"
                ][0][
                    "translatedText"
                ]

        # =====================================================
        # FREE FALLBACK
        # =====================================================

        url = (
            "https://translate.googleapis.com/"
            "translate_a/single"
        )

        params = {
            "client": "gtx",
            "sl": "auto",
            "tl": target_lang,
            "dt": "t",
            "q": text
        }

        response = requests.get(
            url,
            params=params,
            timeout=20
        )

        xbmc.log(
            "[SubtitleTranslator] GOOGLE STATUS: %s"
            % response.status_code,
            xbmc.LOGINFO
        )


        if response.status_code != 200:

            return text

        result = response.json()
        translated = "".join(
            item[0] for item in result[0] if item and item[0]
        )
        return translated

    except Exception as e:

        xbmc.log(
            "[SubtitleTranslator] GOOGLE ERROR: %s"
            % str(e),
            xbmc.LOGERROR
        )

        return text