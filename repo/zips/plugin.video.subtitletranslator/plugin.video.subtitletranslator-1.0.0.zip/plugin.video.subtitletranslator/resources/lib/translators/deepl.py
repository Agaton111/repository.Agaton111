# -*- coding: utf-8 -*-

import requests
import xbmc
import xbmcaddon

import time

ADDON = xbmcaddon.Addon()

LANG_MAP = {
    "Polish": "pl",
    "English": "en",
    "German": "de",
    "French": "fr",
    "Spanish": "es",
    "Italian": "it",
}

selected_language = ADDON.getSetting("target_lang")
target = LANG_MAP.get(selected_language, "pl")

def translate_deepl(text, target):

    api_key = ADDON.getSetting(
        "deepl_api"
    )

    if not api_key:

        xbmc.log(
            "[SubtitleTranslator] DEEPL: BRAK API KEY",
            xbmc.LOGERROR
        )

        return text

    url = "https://api-free.deepl.com/v2/translate"

    try:

        response = requests.post(
            url,
            data={
                "auth_key": api_key,
                "text": text,
                "target_lang": target.upper()
            },
            timeout=30
        )

        xbmc.log(
            "[SubtitleTranslator] DEEPL STATUS: %s"
            % response.status_code,
            xbmc.LOGINFO
        )

        xbmc.log(
            "[SubtitleTranslator] DEEPL RESPONSE: %s"
            % response.text[:500],
            xbmc.LOGINFO
        )

        if response.status_code != 200:

            return text

        result = response.json()

        if "translations" not in result:

            xbmc.log(
                "[SubtitleTranslator] DEEPL INVALID RESPONSE",
                xbmc.LOGERROR
            )

            return text

        return result["translations"][0]["text"]

    except Exception as e:

        xbmc.log(
            "[SubtitleTranslator] DEEPL ERROR: %s"
            % str(e),
            xbmc.LOGERROR
        )

        return text