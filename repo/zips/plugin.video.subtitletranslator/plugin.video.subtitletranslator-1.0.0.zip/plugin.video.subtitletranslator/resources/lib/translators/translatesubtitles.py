# -*- coding: utf-8 -*-
# googleweb.py

import requests
import json
import xbmc
import xbmcgui

GOOGLE_API_KEY = "AIzaSyATBXajvzQLTDHEQbcpq0Ihe0vWDHmO520"


def translate_subtitles(text, target_lang):

    url = "https://translate-pa.googleapis.com/v1/translateHtml"

    headers = {
        "X-goog-api-key": GOOGLE_API_KEY,
        "Content-Type": "application/json+protobuf"
    }

    payload = [[text, "auto", target_lang], "te"]

    try:

        r = requests.post(
            url,
            headers=headers,
            data=json.dumps(payload),
            timeout=20
        )

        xbmc.log(
            "[SubtitleTranslator] GOOGLE STATUS: %s" % r.status_code,
            xbmc.LOGINFO
        )

        xbmc.log(
            "[SubtitleTranslator] GOOGLE RESPONSE: %s" % r.text[:500],
            xbmc.LOGINFO
        )

        if r.status_code != 200:
            return None

        data = r.json()

        # Google zwraca:
        # [[["tekst"]], ...]
        translated = data[0][0]

        return translated

    except Exception as e:

        xbmc.log(
            "[SubtitleTranslator] GOOGLE ERROR: %s" % str(e),
            xbmc.LOGERROR
        )

        return None