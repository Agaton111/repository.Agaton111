# -*- coding: utf-8 -*-

import requests
import xbmc
import xbmcaddon
import time
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

ADDON = xbmcaddon.Addon()

LANG_MAP = {
    "Polish": "pl",
    "English": "en",
    "German": "de",
    "French": "fr",
    "Spanish": "es",
    "Italian": "it",
}

# fallbackowe instancje
LIBRE_URLS = [

    # działa najczęściej
    "https://lt.dialectapp.org/translate",

    # czasem działa
    "https://translate.terraprint.co/translate",

    # bywa niestabilny
    "https://libretranslate.de/translate",
]


def get_target_lang():

    selected = ADDON.getSetting("target_lang")

    return LANG_MAP.get(selected, "pl")


def translate_libre(text, target_lang=None):

    if not text:
        return text

    text = text.strip()

    if not text:
        return text

    if not target_lang:
        target_lang = get_target_lang()

    payload = {
        "q": text,
        "source": "en",
        "target": target_lang,
        "format": "text"
    }

    headers = {
        "Content-Type": "application/json",
        "Accept": "application/json",
        "User-Agent": "Mozilla/5.0"
    }

    for url in LIBRE_URLS:

        try:

            xbmc.log(
                "[SubtitleTranslator] TRY: %s"
                % url,
                xbmc.LOGINFO
            )

            # anty flood
            time.sleep(0.3)

            r = requests.post(
                url,
                json=payload,
                headers=headers,
                timeout=8,
                verify=False,
                allow_redirects=False
            )

##            xbmc.log(
##                "[SubtitleTranslator] STATUS: %s"
##                % r.status_code,
##                xbmc.LOGINFO
##            )

            if r.status_code != 200:
                continue

            content_type = r.headers.get(
                "Content-Type",
                ""
            ).lower()

##            xbmc.log(
##                "[SubtitleTranslator] CONTENT: %s"
##                % content_type,
##                xbmc.LOGINFO
##            )

            # HTML = śmieć
            if "application/json" not in content_type:
                continue

            data = r.json()

            translated = data.get(
                "translatedText",
                ""
            )

            if translated:
##
##                xbmc.log(
##                    "[SubtitleTranslator] OK",
##                    xbmc.LOGINFO
##                )

                return translated

        except Exception as e:

            xbmc.log(
                "[SubtitleTranslator] ERROR: %s"
                % str(e),
                xbmc.LOGERROR
            )

    xbmc.log(
        "[SubtitleTranslator] LIBRE FAILED",
        xbmc.LOGERROR
    )

    return None