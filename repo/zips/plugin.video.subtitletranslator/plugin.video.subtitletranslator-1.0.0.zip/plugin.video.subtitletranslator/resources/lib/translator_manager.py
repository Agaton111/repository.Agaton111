# -*- coding: utf-8 -*-

import xbmcaddon
import time
from resources.lib.translators.google import (
    translate_google
)

from resources.lib.translators.deepl import (
    translate_deepl
)

from resources.lib.translators.libre import (
    translate_libre
)

from resources.lib.translators.mymemory import (
    translate_mymemory
)

from resources.lib.translators.subtranslate import (
    translate_subtranslate
)

from resources.lib.translators.translatesubtitles import (
    translate_subtitles
)

addon = xbmcaddon.Addon()

# =====================================================
# TYPES
# =====================================================

TRANSLATOR_TYPES = {

    "Google": "line",
    "DeepL": "line",
    "LibreTranslate": "line",
    "SubTranslate": "srt",
    "TranslateSubtitles": "srt",
    "mymemory": "line"
}

def get_translator_type(name):

    return TRANSLATOR_TYPES.get(
        name,
        "line"
    )

# =====================================================
# MAIN
# =====================================================

def translate_text(text):

    translator = addon.getSetting(
        "translator"
    )

    target_lang = addon.getSetting(
        "target_lang"
    )

    # =========================
    # GOOGLE
    # =========================

    if translator == "Google":
        LANG_MAP = {
            "Polish": "pl",
            "English": "en",
            "German": "de",
            "French": "fr",
            "Spanish": "es",
            "Italian": "it",
        }
        selected_language = addon.getSetting("target_lang")
        target_lang = LANG_MAP.get(selected_language, "pl")


        return translate_google(
            text,
            target_lang
        )

    # =========================
    # DEEPL
    # =========================

    elif translator == "DeepL":
        LANG_MAP = {
            "Polish": "pl",
            "English": "en",
            "German": "de",
            "French": "fr",
            "Spanish": "es",
            "Italian": "it",
        }
        selected_language = addon.getSetting("target_lang")
        target_lang = LANG_MAP.get(selected_language, "pl")

        return translate_deepl(
            text,
            target_lang
        )

    # =========================
    # LIBRE
    # =========================

    elif translator == "LibreTranslate":
        LANG_MAP = {
            "Polish": "pl",
            "English": "en",
            "German": "de",
            "French": "fr",
            "Spanish": "es",
            "Italian": "it",
        }
        selected_language = addon.getSetting("target_lang")
        target_lang = LANG_MAP.get(selected_language, "pl")

        return translate_libre(
            text,
            target_lang
        )

    # =========================
    # SUBTRANSLATE.XYZ
    # =========================

    elif translator == "SubTranslate":

        return translate_subtranslate(
            text,
            target_lang
        )

    # =========================
    # TRANSLATE-SUBTITLES.COM
    # =========================

    elif translator == "TranslateSubtitles":

        return translate_subtitles(
            text,
            target_lang
        )

    # =========================
    # MYMEMORY
    # =========================

    elif translator == "mymemory":

        return translate_mymemory(
            text,
            target_lang
        )

    return text