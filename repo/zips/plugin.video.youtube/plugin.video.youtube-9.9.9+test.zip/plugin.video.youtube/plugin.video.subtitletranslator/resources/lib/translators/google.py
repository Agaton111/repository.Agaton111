# -*- coding: utf-8 -*-

##import requests
##import xbmc
##import json
##import xbmcaddon
##ADDON = xbmcaddon.Addon()
##
##LANGUAGE_MAP = {
##    "Polish": "pl",
##    "English": "en",
##    "German": "de",
##    "French": "fr",
##    "Spanish": "es",
##    "Italian": "it",
##    "Ukrainian": "uk",
##    "Russian": "ru"
##}
##selected_language = ADDON.getSetting("target_lang")
##
##lang_code = LANGUAGE_MAP.get(selected_language, "pl")
##def translate_google(text, lang_code):
##
##    url = (
##        "https://translate.googleapis.com/"
##        "translate_a/single"
##    )
##
##    headers = {
##        "User-Agent": (
##            "Mozilla/5.0 "
##            "(Windows NT 10.0; Win64; x64) "
##            "AppleWebKit/537.36 "
##            "(KHTML, like Gecko) "
##            "Chrome/124.0 Safari/537.36"
##        ),
##        "Accept": "*/*",
##        "Accept-Language": "en-US,en;q=0.9",
##        "Content-Type": (
##            "application/x-www-form-urlencoded;charset=UTF-8"
##        )
##    }
##
##    # LIMIT długości
##    text = text[:4000]
##
##    data = {
##        "client": "gtx",
##        "sl": "auto",
##        "tl": lang_code,
##        "dt": "t",
##        "q": text
##    }
##
##    try:
##
##        response = requests.post(
##            url,
##            data=data,
##            headers=headers,
##            timeout=30
##        )
##
##        xbmc.log(
##            "GOOGLE STATUS: " + str(response.status_code),
##            xbmc.LOGINFO
##        )
##
##        xbmc.log(
##            "GOOGLE RESPONSE: " + response.text[:500],
##            xbmc.LOGINFO
##        )
##
##        if response.status_code != 200:
##
##            raise Exception(
##                "HTTP ERROR: "
##                + str(response.status_code)
##            )
##
##        # zabezpieczenie
##        if not response.text.strip():
##
##            raise Exception(
##                "Pusta odpowiedź Google"
##            )
##
##        try:
##
##            result = response.json()
##
##        except Exception:
##
##            xbmc.log(
##                "JSON ERROR RESPONSE: "
##                + response.text[:1000],
##                xbmc.LOGERROR
##            )
##
##            raise Exception(
##                "Google zwrócił niepoprawny JSON"
##            )
##
##        translated = ""
##
##        for item in result[0]:
##
##            if item and len(item) > 0:
##                translated += item[0]
##
##        return translated
##
##    except Exception as e:
##
##        xbmc.log(
##            "GOOGLE TRANSLATE ERROR: "
##            + str(e),
##            xbmc.LOGERROR
##        )
##
##        # fallback
##        return text
##
# -*- coding: utf-8 -*-

import requests
import xbmc
import xbmcaddon

ADDON = xbmcaddon.Addon()

def translate_google(text, target_lang):

    api_key = ADDON.getSetting(
        "google_api"
    )

    try:

        # =====================================================
        # OFFICIAL API
        # =====================================================

        if api_key:

            url = (
                "https://translation.googleapis.com/"
                "language/translate/v2"
            )

            response = requests.post(
                url,
                params={
                    "key": api_key
                },
                json={
                    "q": text,
                    "target": target_lang,
                    "format": "text"
                },
                timeout=30
            )

            xbmc.log(
                "[SubtitleTranslator] GOOGLE API STATUS: %s"
                % response.status_code,
                xbmc.LOGINFO
            )

            xbmc.log(
                "[SubtitleTranslator] GOOGLE API RESPONSE: %s"
                % response.text[:500],
                xbmc.LOGINFO
            )

            if response.status_code == 200:

                data = response.json()

                return data["data"][
                    "translations"
                ][0][
                    "translatedText"
                ]

        # =====================================================
        # FREE FALLBACK
        # =====================================================

        url = (
            "https://translate.googleapis.com/"
            "translate_a/single"
        )

        params = {
            "client": "gtx",
            "sl": "auto",
            "tl": target_lang,
            "dt": "t",
            "q": text
        }

        response = requests.get(
            url,
            params=params,
            timeout=20
        )

        xbmc.log(
            "[SubtitleTranslator] GOOGLE STATUS: %s"
            % response.status_code,
            xbmc.LOGINFO
        )

        xbmc.log(
            "[SubtitleTranslator] GOOGLE RESPONSE: %s"
            % response.text[:500],
            xbmc.LOGINFO
        )

        if response.status_code != 200:

            return text

        result = response.json()

        translated = ""

        for item in result[0]:

            translated += item[0]

        return translated

    except Exception as e:

        xbmc.log(
            "[SubtitleTranslator] GOOGLE ERROR: %s"
            % str(e),
            xbmc.LOGERROR
        )

        return text