# -*- coding: utf-8 -*-
import re
import requests
import json
import xbmc
import xbmcaddon

ADDON = xbmcaddon.Addon()

GOOGLE_API_KEY = "AIzaSyATBXajvzQLTDHEQbcpq0Ihe0vWDHmO520"


def translate_subtitles(text, target_lang):

    LANGUAGE_MAP = {
        "Polish": "pl",
        "English": "en",
        "German": "de",
        "French": "fr",
        "Spanish": "es",
        "Italian": "it",
        "Ukrainian": "uk",
        "Russian": "ru"
    }

    selected_language = ADDON.getSetting("target_lang")
    lang_code = LANGUAGE_MAP.get(selected_language, "pl")

    url = "https://translate-pa.googleapis.com/v1/translateHtml"

    headers = {
        "X-goog-api-key": GOOGLE_API_KEY,
        "Content-Type": "application/json+protobuf"
    }

    try:

        # ===== PACK =====

        pattern = (
            r'(\d+)\s*\n'
            r'(\d{2}:\d{2}:\d{2},\d{3}\s*-->\s*'
            r'\d{2}:\d{2}:\d{2},\d{3})\s*\n'
            r'(.*?)(?=\n\d+\s*\n|\Z)'
        )

        matches = re.findall(pattern, text, re.DOTALL)

        packed_parts = []

        structure = []

        for idx, (number, timing, subtitle_text) in enumerate(matches):

            structure.append((number, timing))

            subtitle_text = subtitle_text.strip()

            packed_parts.append(
                "[[[BLOCK_%d]]]\n%s" % (
                    idx,
                    subtitle_text
                )
            )

        packed_text = "\n".join(packed_parts)

        # ===== TRANSLATE =====

        payload = [[packed_text, "auto", lang_code], "te"]

        r = requests.post(
            url,
            headers=headers,
            data=json.dumps(payload),
            timeout=30
        )

        if r.status_code != 200:
            return None

        data = r.json()

        translated_text = data[0][0]

        # ===== UNPACK =====

        translated_blocks = re.split(
            r'\[\[\[BLOCK_(\d+)\]\]\]',
            translated_text
        )

        result = []

        for i in range(1, len(translated_blocks), 2):

            block_index = int(translated_blocks[i])

            subtitle_text = translated_blocks[i + 1].strip()

            if block_index >= len(structure):
                continue

            number, timing = structure[block_index]

            result.append(
                "%s\n%s\n%s\n" % (
                    number,
                    timing,
                    subtitle_text
                )
            )

        translated = "\n".join(result).strip()

        return translated
    except Exception as e:

        xbmc.log(
            "[SubtitleTranslator] GOOGLE ERROR: %s" % str(e),
            xbmc.LOGERROR
        )

        return None