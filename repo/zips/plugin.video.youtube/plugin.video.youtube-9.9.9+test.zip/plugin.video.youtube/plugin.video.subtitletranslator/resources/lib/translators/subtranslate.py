# -*- coding: utf-8 -*-

import re
import requests
import concurrent.futures
import xbmc

API_URL = "https://subtranslate.xyz/api"


# =========================================================
# SRT PARSER (BLOCK-BASED, STABLE)
# =========================================================

def parse_srt(text):

    blocks = re.split(r'\n\s*\n', text.strip())

    entries = []

    for block in blocks:

        lines = block.splitlines()

        if len(lines) < 2:
            continue

        index = lines[0].strip()
        timing = lines[1].strip()
        content = "\n".join(lines[2:]).strip() if len(lines) > 2 else ""

        entries.append({
            "index": index,
            "timing": timing,
            "content": content
        })

    return entries


# =========================================================
# BUILD SRT
# =========================================================

def build_srt(entries):

    out = []

    for i, e in enumerate(entries, start=1):

        out.append(str(i))
        out.append(e["timing"])
        out.append(e["content"])
        out.append("")

    return "\n".join(out)


# =========================================================
# SPLIT INTO BLOCK CHUNKS (IMPORTANT)
# =========================================================

def split_blocks(entries, max_blocks=25):
    """
    NIE znakami. Tylko pełne subtitle blocks.
    """

    chunks = []

    for i in range(0, len(entries), max_blocks):
        chunks.append(entries[i:i + max_blocks])

    return chunks


# =========================================================
# TRANSLATE SINGLE CHUNK
# =========================================================

def translate_chunk(blocks, lang):

    # składamy SRT chunk
    srt_text = ""

    for i, b in enumerate(blocks, start=1):

        srt_text += f"{i}\n{b['timing']}\n{b['content']}\n\n"

    payload = {
        "content": srt_text.strip(),
        "filename": "translated.srt",
        "language": lang,
        "netflixFormat": False
    }

    try:

        session = requests.Session()

        r = session.post(
            API_URL,
            json=payload,
            timeout=(5, 40)
        )

        xbmc.log(
            "[SubtitleTranslator] CODE: %s" % r.status_code,
            xbmc.LOGERROR
        )

        xbmc.log(
            "[SubtitleTranslator] SENT BLOCKS: %s" % len(blocks),
            xbmc.LOGERROR
        )

        r.raise_for_status()

        text = re.sub(
            r'^__STATUS__:.*\n?',
            '',
            r.text,
            flags=re.MULTILINE
        ).strip()

        # fallback safety
        if not text:
            return [b["content"] for b in blocks]


        text = remove_duplicate_indexes(text)

        translated_blocks = re.split(r'\n\s*\n', text.strip())

        return translated_blocks

    except Exception as e:

        xbmc.log(
            "[SubtitleTranslator] ERROR: %s" % str(e),
            xbmc.LOGERROR
        )

        return [b["content"] for b in blocks]


# =========================================================
# MAIN TRANSLATION ENGINE
# =========================================================

def translate_parallel(text, lang, workers=1):  ####### w 1/2

    entries = parse_srt(text)

    chunks = split_blocks(entries, max_blocks=25)

    results = [None] * len(chunks)

    with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as executor:

        future_map = {
            executor.submit(translate_chunk, chunk, lang): i
            for i, chunk in enumerate(chunks)
        }

        for future in concurrent.futures.as_completed(future_map):

            i = future_map[future]

            try:
                results[i] = future.result()

            except Exception as e:

                xbmc.log(
                    "[SubtitleTranslator] FUTURE ERROR: %s" % str(e),
                    xbmc.LOGERROR
                )

                results[i] = [b["content"] for b in chunks[i]]

    # flatten
    translated = []
    for r in results:
        translated.extend(r)

    # safety check
    if len(translated) != len(entries):

        xbmc.log(
            "[SubtitleTranslator] FINAL MISMATCH -> fallback original",
            xbmc.LOGERROR
        )

        return build_srt(entries)

    # map back
    for i, entry in enumerate(entries):
        entry["content"] = extract_text(translated[i])
    return build_srt(entries)


# =========================================================
# KODI ENTRYPOINT
# =========================================================
def extract_text(block):

    lines = block.splitlines()

    cleaned = []

    for line in lines:

        line = line.strip()

        # pomiń indexy
        if line.isdigit():
            continue

        # pomiń timestampy
        if "-->" in line:
            continue

        cleaned.append(line)

    return "\n".join(cleaned).strip()
def remove_duplicate_indexes(text):

    # usuń:
    # 14
    # 00:00 --> 00:00
    text = re.sub(
        r'^\d+\s*\n(?=\d{2}:\d{2}:\d{2},\d{3}\s-->)',
        '',
        text,
        flags=re.MULTILINE
    )

    # usuń zduplikowane timestampy
    text = re.sub(
        r'^([0-9:,]+\s-->\s[0-9:,]+)\s*\n\1\s*$',
        r'\1',
        text,
        flags=re.MULTILINE
    )

    # bardziej agresywna wersja dla Twojego przypadku
    lines = text.splitlines()

    cleaned = []
    prev = None

    for line in lines:

        current = line.strip()

        # pomiń duplicate timestamp
        if "-->" in current and current == prev:
            continue

        cleaned.append(line)
        prev = current

    return "\n".join(cleaned)
def translate_subtranslate(text, target_lang):

    return translate_parallel(
        text,
        target_lang,
        workers=2
    )