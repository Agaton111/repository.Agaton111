# -*- coding: utf-8 -*-

def parse_srt(content):

    import re

    pattern = re.compile(
        r'(\d+)\s+'
        r'([\d:,\-\-> ]+)\s+'
        r'([\s\S]*?)(?=\n\d+\n|\Z)',
        re.MULTILINE
    )

    results = []

    for m in pattern.finditer(content):

        results.append({
            "index": m.group(1),
            "time": m.group(2).strip(),
            "text": m.group(3).strip()
        })

    return results


def rebuild_srt(items):

    out = []

    for item in items:

        text = item.get("text")

        # 🔥 KLUCZOWA NAPRAWA
        if text is None or text == "":
            text = "[...]"

        out.append(str(item["index"]))
        out.append(item["time"])
        out.append(str(text))
        out.append("")

    return "\n".join(out)