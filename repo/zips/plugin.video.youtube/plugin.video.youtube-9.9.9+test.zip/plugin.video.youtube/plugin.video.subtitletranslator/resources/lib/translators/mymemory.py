# -*- coding: utf-8 -*-

import requests
import urllib.parse
import xbmc
import xbmcaddon
ADDON = xbmcaddon.Addon()


LANGUAGE_MAP = {
    "Polish": "pl",
    "English": "en",
    "German": "de",
    "French": "fr",
    "Spanish": "es",
    "Italian": "it",
    "Ukrainian": "uk",
    "Russian": "ru"
}
selected_language = ADDON.getSetting("target_lang")

lang_code = LANGUAGE_MAP.get(selected_language, "pl")

def translate_mymemory(text, lang_code):

    try:

        q = urllib.parse.quote(text[:400])

        url = (
            "https://api.mymemory.translated.net/get"
            "?q=" + q +
            "&langpair=en|" + lang_code
        )

        r = requests.get(
            url,
            timeout=15
        )

        xbmc.log(
            "MYMEMORY STATUS: "
            + str(r.status_code),
            xbmc.LOGINFO
        )

        if r.status_code != 200:
            return text

        data = r.json()

        translated = data.get(
            "responseData",
            {}
        ).get(
            "translatedText"
        )

        if translated:
            return translated

        return text

    except Exception as e:

        xbmc.log(
            "MYMEMORY ERROR: "
            + str(e),
            xbmc.LOGERROR
        )

        return text