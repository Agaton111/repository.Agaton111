# -*- coding: utf-8 -*-
## libre.py ##

import requests
import xbmc
import xbmcaddon

addon = xbmcaddon.Addon()

def translate_libre(text, target_lang):

    url = addon.getSetting("libre_url")

    if not url:
        url = "https://translate.argosopentech.com/translate"

    api_key = addon.getSetting("libre_api")

    payload = {
        "q": text,
        "source": "auto",
        "target": target_lang,
        "format": "text"
    }

    # API key opcjonalny
    if api_key:
        payload["api_key"] = api_key

    try:

        r = requests.post(
            url,
            json=payload,
            timeout=20
        )

        xbmc.log(
            "[SubtitleTranslator] LIBRE STATUS: " + str(r.status_code),
            xbmc.LOGINFO
        )

        xbmc.log(
            "[SubtitleTranslator] LIBRE RESPONSE: " + r.text,
            xbmc.LOGINFO
        )

        if r.status_code != 200:
            return None

        data = r.json()

        # zabezpieczenie
        if "translatedText" not in data:
            return None

        return data["translatedText"]

    except Exception as e:

        xbmc.log(
            "[SubtitleTranslator] LIBRE ERROR: " + str(e),
            xbmc.LOGERROR
        )

        return None