# -*- coding: utf-8 -*-
## default
import os
import sys
import time
import xbmc
import xbmcgui
import xbmcaddon
import xbmcvfs
import threading

from urllib.parse import parse_qs
from resources.lib.srt_parser import (
    parse_srt,
    rebuild_srt
)

from resources.lib.translator_manager import (
    translate_text,
    get_translator_type
)

ADDON = xbmcaddon.Addon()
dialog = xbmcgui.Dialog()
show_settings = ADDON.getSettingBool(
    "show_settings_on_start"
)

if show_settings:
    ADDON.openSettings()
    xbmc.sleep(500)

translator = ADDON.getSetting("translator")
translator_type = get_translator_type(translator)
xbmcgui.Dialog().notification(heading='Wybór',message='Plik do tłumaczenia',
            icon=xbmcgui.NOTIFICATION_WARNING,time=8500,sound=False)
# =====================================================
# PARAMS
# =====================================================
params = parse_qs(sys.argv[2][1:])
source_file = params.get("source", [None])[0]
target_dir = params.get("target", [None])[0]
# =====================================================
# SOURCE FILE
# =====================================================
LANGUAGE_MAP = {
    "Polish": "pl",
    "English": "en",
    "German": "de",
    "French": "fr",
    "Spanish": "es",
    "Italian": "it",
    "Ukrainian": "uk",
    "Russian": "ru"
}
if source_file:
    local_path = xbmcvfs.translatePath(source_file)
else:
    subtitle_file = dialog.browseSingle(
        1,
        "Wybierz plik SRT",
        "files",
        ".srt"
    )
    if not subtitle_file:
        raise SystemExit
    local_path = xbmcvfs.translatePath(subtitle_file)
# =====================================================
# READ FILE
# =====================================================
try:
    with open(local_path, "r", encoding="utf-8") as f:
        content = f.read()
except:
    with open(local_path, "r", encoding="cp1250") as f:
        content = f.read()
original_text = content
final_srt = ""
# =====================================================
# LINE TRANSLATORS
# =====================================================
if translator_type == "line":
    subs = parse_srt(content)
    progress = xbmcgui.DialogProgress()
    progress.create(
        "Tłumaczenie",
        "Trwa tłumaczenie..."
    )

    translated = []
    total = len(subs)
    for i, item in enumerate(subs):
        if progress.iscanceled():
            progress.close()
            raise SystemExit
        percent = int(((i + 1) / total) * 100)
        progress.update(
            percent,
            "Tłumaczenie %d/%d" % (i + 1, total)
        )
        text = item["text"]
        translated_text = translate_text(text)
        time.sleep(1)
        if translated_text is None:
            translated_text = text

        translated.append({
            "index": item["index"],
            "time": item["time"],
            "text": translated_text
        })
    progress.close()
    final_srt = rebuild_srt(translated)
# =====================================================
# FULL SRT TRANSLATORS
# =====================================================
elif translator_type == "srt":
    progress = xbmcgui.DialogProgress()
    progress.create(
        "Tłumaczenie",
        "Wysyłanie do API..."
    )
    running = True
    # =====================================================
    # FAKE PROGRESS
    # =====================================================
    def fake_progress():
        percent = 0
        while running:
            if progress.iscanceled():
                break
            percent += 1
            if percent > 95:
                percent = 95
            progress.update(
                percent,
                f"Tłumaczenie... {percent}%"
            )
            time.sleep(1)
    t = threading.Thread(
        target=fake_progress
    )
    t.start()
    # =====================================================
    # REAL TRANSLATION
    # =====================================================
    final_srt = translate_text(
        original_text
    )
    # =====================================================
    # END
    # =====================================================
    running = False
    progress.update(
        100,
        "Gotowe"
    )
    time.sleep(0.3)
    progress.close()
# =====================================================
# VALIDATION
# =====================================================
if not final_srt or len(final_srt.strip()) == 0:
    dialog.ok(
        "Błąd",
        "Pusty wynik tłumaczenia"
    )
    raise SystemExit
# =====================================================
# TARGET DIRECTORY
# =====================================================
if target_dir:
    cache_dir = xbmcvfs.translatePath(target_dir)
else:
    cache_dir = ADDON.getSetting("save_path")
    if not cache_dir:

        cache_dir = xbmcvfs.translatePath(
            "special://home/cache/tlumacz/"
        )
# =====================================================
# CREATE DIRECTORY
# =====================================================
if not xbmcvfs.exists(cache_dir):
    xbmcvfs.mkdirs(cache_dir)
# =====================================================
# LANGUAGE
# =====================================================
selected_language = ADDON.getSetting("target_lang")

lang_code = LANGUAGE_MAP.get(
    selected_language,
    "pl"
)

if not lang_code:
    lang_code = "pl"
# =====================================================
# OUTPUT FILENAME
# =====================================================
base = os.path.splitext(
    os.path.basename(local_path)
)[0]

filename = f"{base}.{lang_code}.srt"
##filename = base + "." + target_lang + ".srt"
save_path = os.path.join(
    cache_dir,
    filename
)

# =====================================================
# SAVE
# =====================================================
with open(save_path, "w", encoding="utf-8") as f:
    f.write(final_srt)
# =====================================================
# END
# =====================================================
open_folder = dialog.yesno(
    "Tłumaczenie zakończone",
    "Zapisano tłumaczenie.\n" + save_path,
    "",
    "Otworzyć katalog?"
)

if open_folder:
    try:
        path = xbmcvfs.translatePath(cache_dir)
        os.startfile(path)
    except Exception as e:
        xbmc.log(
            "[SubtitleTranslator] OPEN DIR ERROR: " + str(e),
            xbmc.LOGERROR
        )

xbmc.executebuiltin('Dialog.Close(all,true)')
raise SystemExit