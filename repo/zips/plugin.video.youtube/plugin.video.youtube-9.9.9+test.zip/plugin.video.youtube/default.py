# -*- coding: utf-8 -*-

import sys
import urllib.parse
import xbmc
import re
import xbmcgui
import xbmcplugin
import os
import xbmcvfs
from yt_dlp import YoutubeDL
import json
import time

ADDON_NAME = "[YT Fake]"

def log(msg):
    xbmc.log(f"{ADDON_NAME} {msg}", xbmc.LOGINFO)

# PARAMETRY
# ============================================================
handle = int(sys.argv[1])
base_url = sys.argv[0]

params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
query_param = params.get("q")

action = params.get("action")
url = params.get("url")

win = xbmcgui.Window(10000)

CACHE_DIR = xbmcvfs.translatePath("special://profile/addon_data/plugin.video.youtube/youtube_subs/")
xbmcplugin.setContent(handle, 'episodes')

FAV_FILE = xbmcvfs.translatePath(
    "special://profile/addon_data/plugin.video.youtube/fav.json"
)

# utwórz folder jeśli nie istnieje
fav_dir = os.path.dirname(FAV_FILE)
if not os.path.exists(fav_dir):
    os.makedirs(fav_dir)



def get_cache(key):
    data = win.getProperty(key)
    return json.loads(data) if data else None

def set_cache(key, value):
    win.setProperty(key, json.dumps(value))


def cleanup_cache(max_size_mb=50):
    max_size = max_size_mb * 1024 * 1024
    files = []
    total_size = 0
    # =====================================================
    # ZBIERZ PLIKI
    # =====================================================
    for f in os.listdir(CACHE_DIR):
        path = os.path.join(CACHE_DIR, f)
        if not os.path.isfile(path):
            continue
        try:
            size = os.path.getsize(path)
            mtime = os.path.getmtime(path)
            total_size += size
            files.append({
                "path": path,
                "size": size,
                "mtime": mtime
            })
        except Exception as e:
            log(f"CACHE STAT ERROR: {e}")
    # =====================================================
    # LIMIT OK
    # =====================================================
    if total_size <= max_size:
        return
##    log(
##        f"CACHE LIMIT EXCEEDED: "
##        f"{total_size // 1024 // 1024}MB "
##        f"> {max_size_mb}MB"
##    )
    # =====================================================
    # SORTUJ OD NAJSTARSZYCH
    # =====================================================
    files.sort(
        key=lambda x: x["mtime"]
    )
    removed = 0
    # =====================================================
    # USUWAJ STOPNIOWO
    # =====================================================
    for item in files:
        try:
            os.remove(item["path"])
            total_size -= item["size"]
            removed += 1
##            log(
##                f"CACHE REMOVED: "
##                f"{os.path.basename(item['path'])}"
##            )
            # już poniżej limitu
            if total_size <= max_size:
                break
        except Exception as e:
            log(f"CACHE DELETE ERROR: {e}")
    log(
        f"CACHE CLEANUP DONE "
        f"(removed {removed} files)"
    )
#####################################################
def load_favs():
    if not os.path.exists(FAV_FILE):
        return []
    try:
        with open(FAV_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except:
        return []

def save_favs(data):
##    log("SAVING FAVS")
    with open(FAV_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

def add_fav(query):
    favs = load_favs()

    if query in favs:
        xbmcgui.Dialog().notification("Wyniki", "Już istnieje")
        return

    favs.append(query)
    save_favs(favs)
    xbmcgui.Dialog().notification("Wyniki", "Dodano")

def remove_fav(query):
    favs = load_favs()

    if query in favs:
        favs.remove(query)
        save_favs(favs)
        xbmcgui.Dialog().notification("Wyniki", "Usunięto")
        xbmc.executebuiltin("Container.Refresh")

def show_favs():
    favs = load_favs()
    for q in favs:
        li = xbmcgui.ListItem(label=q)
        url = (
            base_url
            + "?q=" + urllib.parse.quote_plus(q)
        )

        # menu kontekstowe (usuń)
        li.addContextMenuItems([
            ("Usuń z wyników Youtube",
             f"RunPlugin({base_url}?action=remove_fav&q={urllib.parse.quote_plus(q)})")
        ])

        xbmcplugin.addDirectoryItem(handle, url, li, True)
    xbmcplugin.endOfDirectory(handle)

# ============================================================
# WYSZUKIWANIE  #

# ============================================================
def search(initial_query=None):
    #  spróbuj pobrać ostatnie zapytanie
    last_query = win.getProperty("yt_fake_last_query")

    # jeśli wracamy z playera → użyj starego zapytania
    if not initial_query and last_query:
        show_results(last_query)
        return

    kb = xbmc.Keyboard(initial_query or "", "Szukaj w YouTube")
    kb.doModal()

    if not kb.isConfirmed():
        return
    query = kb.getText().strip()

    if not query:
        query ='.'

    #  zapisz zapytanie
    win.setProperty("yt_fake_last_query", query)
    show_results(query)

def detect_type(q):
    q = q.strip()
    # playlist
    if "list=" in q:
        return "playlist"

    # video
    if "watch?v=" in q or "youtu.be/" in q:
        return "video"

    # video ID
    if re.fullmatch(r"[a-zA-Z0-9_-]{11}", q):
        return "video"

    return "search"
# ============================================================
# 📋 LISTA WYNIKÓW
# ============================================================
def show_results(query):
    win.setProperty("yt_fake_last_query", query)
    cache_key = f"yt_cache_{query}"
    cached = get_cache(cache_key)
    mode = detect_type(query)
    # ======================================================
    # SEARCH / DATA
    # ======================================================
    if cached:
##        log("CACHE HIT")
        data = cached
    else:
##        log("CACHE MISS")

        with YoutubeDL({
            "quiet": True,
            "skip_download": True,
            "extract_flat": True,   # 🔥 tylko SEARCH
            "noplaylist": True,
            "geo_bypass": True,
            "extractor_args": {
                "youtube": {
                    "player_client": ["android"]
                }
            }
        }) as ydl:

            if mode == "search":
                data = ydl.extract_info(f"ytsearch30:{query}", download=False)

            elif mode == "video":
                info = ydl.extract_info(query, download=False)
                data = {"entries": [info]}

            elif mode == "playlist":
                data = ydl.extract_info(query, download=False)

        set_cache(cache_key, data)

    #  dodaj opcję zapisania wyszukiwania
    icon="DefaultMusicRecentlyAdded.png"
    li = xbmcgui.ListItem(label=f"[B]Dodaj wszystko, co, jest poniżej jako '{query[:8]}...' do wyników YouTube.[/B]")
    setArt={'thumb': icon, 'poster': icon, 'banner': '', 'icon': icon,}
    li.setArt(setArt)

    fav_url = (
        base_url
        + "?action=add_fav"
        + "&q=" + urllib.parse.quote_plus(query)
    )

    xbmcplugin.addDirectoryItem(handle, fav_url, li, False) ###

    # ======================================================
    #  LISTA
    # ======================================================
    for entry in data.get("entries", []):
        title = entry.get("title")
        video_id = entry.get("id")
        url = entry.get("webpage_url") or f"https://www.youtube.com/watch?v={video_id}"

        thumbs = entry.get("thumbnails") or []

        thumb = (
            entry.get("thumbnail")
            or (thumbs[0]["url"] if thumbs else "")
        )

        desc = entry.get("description") or entry.get("title") or ""

        li = xbmcgui.ListItem(label=title)
        download_url = (
            base_url
            + "?action=download"
            + "&url=" + urllib.parse.quote_plus(url)
        )

        li.addContextMenuItems([
            ("Pobierz video", f"RunPlugin({download_url})")
        ])
        li.setArt({"thumb": thumb})
        li.setProperty("IsPlayable", "true")
        li.setInfo("video", {"plot": desc})

        play_url = (
            base_url
            + "?action=play"
            + "&url=" + urllib.parse.quote_plus(url)
            + "&q=" + urllib.parse.quote_plus(query)
        )
        xbmcplugin.addDirectoryItem(handle, play_url, li, False)
    xbmcplugin.endOfDirectory(handle, cacheToDisc=True)

def get_info(url):

    with YoutubeDL({
        "quiet": True,
        "skip_download": True,
        "writesubtitles": True,
        "writeautomaticsub": True,
        "subtitlesformat": "srt/vtt/json3",
        "subtitleslangs": ["pl", "en"],
        "extract_flat": False,
        "geo_bypass": True,

        "extractor_args": {
            "youtube": {
                "player_client": ["android"]
            }
        }

    }) as ydl:

        info = ydl.extract_info(
            url,
            download=False
        )

        if "entries" in info:
            info = info["entries"][0]

        return info
###### STREAM
def get_stream(video_url):
    with YoutubeDL({
        "quiet": True,
        "skip_download": True,
        "geo_bypass": True,
        "extract_flat": False,
        "extractor_args": {
            "youtube": {
                "player_client": ["android"]
            }
        },
    }) as ydl:

        info = ydl.extract_info(video_url, download=False)

        if "entries" in info:
            info = info["entries"][0]

        #  najpierw HLS
        for f in info.get("formats", []):
            if f.get("protocol") == "m3u8_native" and f.get("manifest_url"):
                return f["manifest_url"]

        # fallback MP4 (bez inputstream)
        formats = [
            f for f in info.get("formats", [])
            if f.get("vcodec") != "none" and f.get("acodec") != "none"
        ]

        if not formats:
            return None

        best = max(formats, key=lambda x: x.get("height", 0))
        return best["url"] if best and best.get("url") else None

def json3_to_srt(data, path):
    j = json.loads(data)
    events = j.get("events", [])
    with open(path, "w", encoding="utf-8") as f:
        idx = 1
        for e in events:
            if "segs" not in e:
                continue
            text = "".join(
                seg.get("utf8", "")
                for seg in e["segs"]
            ).strip()

            if not text:
                continue
            start = e.get("tStartMs", 0)
            dur = e.get("dDurationMs", 1000)
            def ts(ms):
                s = ms // 1000
                return (
                    f"{s//3600:02}:"
                    f"{(s%3600)//60:02}:"
                    f"{s%60:02},"
                    f"{ms%1000:03}"
                )

            f.write(f"{idx}\n")
            f.write(f"{ts(start)} --> {ts(start+dur)}\n")
            f.write(text + "\n\n")
            idx += 1
    return path

def get_all_subs(video_id, info):

    base = os.path.join(CACHE_DIR, video_id)
    subs = {}

    # =====================================================
    # ZBIERZ SUBS
    # =====================================================

    for source in [
        info.get("subtitles") or {},
        info.get("automatic_captions") or {}
    ]:

        for lang, tracks in source.items():

            if lang not in subs:
                subs[lang] = []

            subs[lang].extend(tracks)

    preferred = [
        "pl",
        "pl-PL",
        "pl-orig",
        "a.pl",
        "pl-en",
        "en",
        "en-US",
        "en-orig",
        "en-pl",
        "a.en"
    ]

    results = []

    # =====================================================
    # PRZETWARZANIE
    # =====================================================

    for lang in preferred:

        tracks = subs.get(lang)

        if not tracks:
            continue

        selected = None

        # =================================================
        # PRIORITY
        # =================================================

        for t in tracks:
            if t.get("ext") == "srt":
                selected = t
                break

        if not selected:
            for t in tracks:
                if t.get("ext") == "vtt":
                    selected = t
                    break

        if not selected:
            for t in tracks:
                if t.get("ext") == "json3":
                    selected = t
                    break

        if not selected:
            continue

        sub_url = selected.get("url")
        ext = selected.get("ext")

        if not sub_url:
            continue

        # =================================================
        # PATH
        # =================================================

        if ext == "json3":
            path = f"{base}.{lang}.srt"
        else:
            path = f"{base}.{lang}.{ext}"

        # =================================================
        # CACHE HIT
        # =================================================

        if os.path.exists(path):

            try:

                if os.path.getsize(path) > 20:

                    with open(
                        path,
                        "r",
                        encoding="utf-8",
                        errors="ignore"
                    ) as f:

                        head = f.read(300)

                    if "<html" not in head.lower():

                        results.append(path)
                        continue

                    else:
                        os.remove(path)

            except Exception as e:
                log(f"SUB CACHE ERROR: {e}")

        # =================================================
        # DOWNLOAD
        # =================================================

        try:
            data = None

            for attempt in range(3):

                try:

                    with YoutubeDL({
                        "quiet": True,
                        "skip_download": True,
                        "nocheckcertificate": True,
                    }) as ydl:

                        response = ydl.urlopen(sub_url)

                        data = response.read()

                    break

                except Exception as e:

                    log(
                        f"SUB DOWNLOAD RETRY {attempt + 1}: {e}"
                    )

                    time.sleep(2)

            if not data:
                continue

            # =============================================
            # JSON3 -> SRT
            # =============================================

            if ext == "json3":

                text = data.decode(
                    "utf-8",
                    errors="ignore"
                )

                json3_to_srt(text, path)

                results.append(path)

                continue

            # =============================================
            # SAVE NORMAL
            # =============================================

            with open(path, "wb") as f:
                f.write(data)

            results.append(path)

        except Exception as e:

            log(f"SUB DOWNLOAD ERROR: {e}")

            continue

    # =====================================================
    # REMOVE DUPLICATES
    # =====================================================

    results = list(dict.fromkeys(results))

    return results

def play(url):

    # =====================================================
    # SINGLE REQUEST INFO
    # =====================================================

    with YoutubeDL({
        "quiet": True,
        "skip_download": True,
        "writesubtitles": True,
        "writeautomaticsub": True,
        "subtitlesformat": "srt/vtt/json3",
        "subtitleslangs": ["pl", "en"],
        "extract_flat": False,
        "geo_bypass": True,
        "extractor_args": {
            "youtube": {
                "player_client": ["android"]
            }
        }
    }) as ydl:

        info = ydl.extract_info(url, download=False)

    if "entries" in info:
        info = info["entries"][0]

    video_id = info.get("id")

    # =====================================================
    # STREAM
    # =====================================================

    stream_url = None

    for f in info.get("formats", []):

        if (
            f.get("protocol") == "m3u8_native"
            and f.get("manifest_url")
        ):
            stream_url = f["manifest_url"]
            break

    # fallback mp4
    if not stream_url:

        formats = [
            f for f in info.get("formats", [])
            if f.get("vcodec") != "none"
            and f.get("acodec") != "none"
        ]

        if formats:

            best = max(
                formats,
                key=lambda x: x.get("height", 0)
            )

            stream_url = best.get("url")

    if not stream_url:
        xbmcgui.Dialog().ok(
            "Błąd",
            "Brak streamu"
        )
        return

    # =====================================================
    # SUBTITLES
    # =====================================================

    subs = get_all_subs(video_id, info)
    subs = subs or []

    translated_sub = None

    if subs:

        for s in subs:

            name = os.path.basename(s)

            if ".en." in name.lower():

                base = os.path.splitext(name)[0]

                test = os.path.join(
                    CACHE_DIR,
                    f"{base}.pl.srt"
                )

                if os.path.exists(test):

                    translated_sub = test
                    break

        # =================================================
        # FIX NoneType
        # =================================================

        if translated_sub and os.path.exists(translated_sub):

            subs.append(translated_sub)

    subs = list(dict.fromkeys(subs))

    if not subs:
        subs = []

    # =====================================================
    # BRAK POLSKICH -> TRANSLATE
    # =====================================================

    has_pl = any(
        ".pl." in os.path.basename(x).lower()
        for x in subs
    )

    live = any(
        ".vtt" in os.path.basename(x).lower()
        for x in subs
    )

    if not has_pl and subs:

        if not live and subs:

            choice = xbmcgui.Dialog().select(
                "Brak napisów PL",
                [
                    "Nie tłumacz",
                    "Przetłumacz automatycznie (bardzo powolne)",
                    "Podaj ścieżkę do pliku napisów"
                ]
            )

            # =================================================
            # 0 = NIE TŁUMACZ
            # =================================================

            if choice == 0:
                pass

            # =================================================
            # 1 = AUTO TRANSLATE
            # =================================================

            elif choice == 1:

                source_sub = None

                for s in subs:

                    name = os.path.basename(s).lower()

                    if ".en." in name:
                        source_sub = s
                        break

                if not source_sub:
                    source_sub = subs[0]

                log(f"TRANSLATING: {source_sub}")

                target_dir = xbmcvfs.translatePath(
                    "special://userdata/addon_data/plugin.video.youtube/youtube_subs/"
                )

                if not xbmcvfs.exists(target_dir):
                    xbmcvfs.mkdirs(target_dir)

                # =============================================
                # BEFORE FILES
                # =============================================

                before = set(os.listdir(target_dir))

                encoded_source = urllib.parse.quote(source_sub)
                encoded_target = urllib.parse.quote(target_dir)

                xbmc.executebuiltin(
                    f'RunPlugin(plugin://plugin.video.subtitletranslator/'
                    f'?source={encoded_source}&target={encoded_target})'
                )

                timeout = 150

                while timeout > 0:

                    xbmc.sleep(1000)

                    after = set(os.listdir(target_dir))

                    new_files = after - before

                    found = False

                    for f in new_files:

                        if not f.lower().endswith(".srt"):
                            continue

                        full = os.path.join(target_dir, f)

                        try:

                            if os.path.getsize(full) > 0:

                                log(
                                    f"TRANSLATED FOUND: {full}"
                                )

                                subs.append(full)

                                subs = list(
                                    dict.fromkeys(subs)
                                )

                                found = True
                                break

                        except Exception as e:

                            log(
                                f"SUB CHECK ERROR: {e}"
                            )

                    if found:
                        break

                    timeout -= 1

                else:

                    log(
                        "TRANSLATION FAILED OR TIMEOUT"
                    )

            # =================================================
            # 2 = EXTERNAL FILE
            # =================================================

            elif choice == 2:

                external_sub = xbmcgui.Dialog().browse(
                    1,
                    "Wybierz napisy",
                    "files",
                    ".srt|.vtt"
                )

                if (
                    external_sub
                    and os.path.exists(external_sub)
                ):

                    subs.append(external_sub)

                    subs = list(
                        dict.fromkeys(subs)
                    )

                    xbmcgui.Dialog().notification(
                        "Napisy",
                        "Dodano plik"
                    )

    # =====================================================
    # PLAYER
    # =====================================================

    li = xbmcgui.ListItem(path=stream_url)

    li.setProperty("IsPlayable", "true")

    # =====================================================
    # INPUTSTREAM
    # =====================================================

    if (
        ".m3u8" in stream_url
        and "googlevideo" in stream_url
    ):

        li.setProperty(
            "inputstream",
            "inputstream.adaptive"
        )

    # =====================================================
    # SET SUBTITLES
    # =====================================================

    if subs:

        log(f"SET SUBS: {subs}")

        li.setSubtitles(subs)

    else:

        log("NO SUBS FOUND")

    xbmcplugin.setResolvedUrl(
        handle,
        True,
        li
    )
def download_video(url):

    download_dir = xbmcvfs.translatePath(
        "special://userdata/addon_data/plugin.video.youtube/downloads/"
    )

    os.makedirs(download_dir, exist_ok=True)
    dialog = xbmcgui.Dialog()
    quality = dialog.select(
        "Wybierz jakość",
        [
            "Najlepsza (HLS)",
            "720p (HLS)",
            "480p (HLS)",
##            "Audio"
        ]
    )
##
    if quality == -1:
        return

    format_map = {
        0: "best",
        1: "best[height<=720]/best",
        2: "best[height<=480]/best",
        3: "bestaudio"
    }

##    format_map = {
##        0: "22/18/best",
##        1: "22/18/best",
##        2: "18/best",
##        3: "bestaudio"
##    }
    progress = xbmcgui.DialogProgress()
    progress.create("YouTube", "Przygotowanie pobierania...")

    def hook(d):
        try:
            if d["status"] == "downloading":
                percent_str = d.get("_percent_str", "0%")
                percent_str = percent_str.replace("%", "").strip()
                try:
                    percent = float(percent_str)
                except:
                    percent = 0
                speed = d.get("_speed_str", "")
                eta = d.get("_eta_str", "")

                progress.update(
                    int(percent),
                    f"Pobieranie...\n"
                    f"{speed}\n"
                    f"ETA: {eta}"
                )

                if progress.iscanceled():
                    raise Exception("ANULOWANO")
            elif d["status"] == "finished":
                progress.update(
                    100,
                    "Kończenie pliku..."
                )

        except Exception:
            pass

    ydl_opts = {

        "outtmpl": os.path.join(
            download_dir,
            "%(title)s.%(ext)s"
        ),

        "format": format_map.get(
            quality,
            "18/22/best"
        ),

        "quiet": False,
        "geo_bypass": True,
        "noplaylist": True,
        "nocheckcertificate": True,
        "extractor_args": {
            "youtube": {
                "player_client": ["android"]
            }
        },

        "http_headers": {
            "User-Agent": (
                "com.google.android.youtube/"
                "19.09.37 (Linux; Android 11)"
            )
        },

        "progress_hooks": [hook],
    }

##    # AUDIO MP3
##    if quality == 3:
##        ydl_opts.update({
##            "postprocessors": [{
##                "key": "FFmpegExtractAudio",
##                "preferredcodec": "mp3",
##                "preferredquality": "192",
##            }]
##        })


    try:
        with YoutubeDL(ydl_opts) as ydl:

            info = ydl.extract_info(
                url,
                download=True
            )

            filename = ydl.prepare_filename(info)
        progress.close()
        xbmcgui.Dialog().notification(
            "YouTube",
            "Pobieranie zakończone zapisane w:\nuserdata/addon_data/plugin.video.youtube/downloads/",
            xbmcgui.NOTIFICATION_INFO,
            8000
        )
        log(f"DOWNLOADED: {filename}")
    except Exception as e:
        progress.close()
        log(f"DOWNLOAD ERROR: {e}")
        xbmcgui.Dialog().ok(
            "Błąd pobierania",
            str(e)
        )

def show_root():
    icon2='DefaultAddonsSearch.png'
    icon='DefaultAddonVideo.png'
    setArt={'thumb': icon, 'poster': icon, 'banner': '', 'icon': icon,}
    li = xbmcgui.ListItem(label="Wyniki wyszukiwania")
    li.setArt(setArt)

    xbmcplugin.addDirectoryItem(
        handle,
        base_url + "?action=favs",
        li,
        True
    )
    setArt={'thumb': icon2, 'poster': icon2, 'banner': '', 'icon': icon2,}
    li = xbmcgui.ListItem(label="Szukaj")
    li.setArt(setArt)

    xbmcplugin.addDirectoryItem(
        handle,
        sys.argv[0] + "?url=search",
        li,
        True
    )

    xbmcplugin.endOfDirectory(handle)
    win.clearProperty("yt_fake_last_query")
# ========================================================
# START
if action == "play" and url:
    play(urllib.parse.unquote_plus(url))

elif action == "add_fav" and query_param:
    add_fav(query_param)

elif action == "remove_fav" and query_param:
    remove_fav(query_param)

elif action == "favs":
    show_favs()

elif url == "search":
    search(query_param)

elif query_param:
    show_results(query_param)

elif action == "download" and url:
    download_video(
        urllib.parse.unquote_plus(url)
    )
else:
    show_root()