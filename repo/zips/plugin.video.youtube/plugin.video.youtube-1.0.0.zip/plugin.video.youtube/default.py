# -*- coding: utf-8 -*-
import sys
import urllib.parse
import xbmc
import re
import xbmcgui
import xbmcplugin
from yt_dlp import YoutubeDL

ADDON_NAME = "[YT Fake]"

def log(msg):
    xbmc.log(f"{ADDON_NAME} {msg}", xbmc.LOGINFO)

# 📥 PARAMETRY
# ============================================================
handle = int(sys.argv[1])
base_url = sys.argv[0]

params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
query_param = params.get("q")

action = params.get("action")
url = params.get("url")

win = xbmcgui.Window(10000)
session = win.getProperty("yt_session")

def get_cache(key):
    data = win.getProperty(key)
    return eval(data) if data else None

def set_cache(key, value):
    win.setProperty(key, repr(value))

# ============================================================
# 🎬 WYBÓR STREAMU
# ============================================================
def get_best_youtube_stream(video_url):
    ydl_opts = {
        "quiet": True,
        "no_warnings": True,
        "skip_download": True,
        "noplaylist": True,
        "geo_bypass": True,
        "age_limit": 0,

        # 🔥 TO JEST KLUCZ
        "extractor_args": {
            "youtube": {
##                "player_client": ["android"]
                "player_client": ["android", "web"]
            }
        },
    }

    try:

        with YoutubeDL({
            "quiet": True,
            "skip_download": True,
            "extract_flat": True,
            "geo_bypass": True,
            "noplaylist": True,
            "extractor_args": {
                "youtube": {
                    "player_client": ["android", "web"]
                }
            }
        }) as ydl:

            mode = detect_type(query)

            if mode == "search":

                data = ydl.extract_info(
                    f"ytsearch10:{query}",
                    download=False,
                    extract_flat=True,
                )

            for e in data.get("entries", []):
                if not e.get("thumbnail") and "id" in e:
                    e["thumbnail"] = f"https://i.ytimg.com/vi/{e['id']}/hqdefault.jpg"

            if mode == "video":
                info = ydl.extract_info(query, download=False)
                data = {"entries": [info]}

            elif mode == "playlist":
                data = ydl.extract_info(query, download=False)



    except Exception as e:
        log(f"ERROR: {e}")

    return None

# ============================================================
# 🔎 WYSZUKIWANIE  #

# ============================================================
def search(initial_query=None):
    # 🔥 spróbuj pobrać ostatnie zapytanie
    last_query = win.getProperty("yt_fake_last_query")

    # jeśli wracamy z playera → użyj starego zapytania
    if not initial_query and last_query:
        show_results(last_query)
        return

    kb = xbmc.Keyboard(initial_query or "", "Szukaj w YouTube")
    kb.doModal()

    if not kb.isConfirmed():
        return

    query = kb.getText().strip()

    if not query:
        return

    # 🔥 zapisz zapytanie
    win.setProperty("yt_fake_last_query", query)

    show_results(query)
def detect_type(q):
    q = q.strip()

    # playlist
    if "list=" in q or "youtube.com/playlist" in q:
        return "playlist"

    # video URL
    if "watch?v=" in q or "youtu.be/" in q:
        return "video"

    # video ID (11 znaków)
    if re.fullmatch(r"[a-zA-Z0-9_-]{11}", q):
        return "video"

    return "search"
# ============================================================
# 📋 LISTA WYNIKÓW
# ============================================================
def show_results(query):
    win.setProperty("yt_fake_last_query", query)

    cache_key = f"yt_cache_{query}"
    cached = get_cache(cache_key)

    mode = detect_type(query)

    # ======================================================
    # 🔎 SEARCH / DATA
    # ======================================================
    if cached:
        log("CACHE HIT")
        data = cached
    else:
        log("CACHE MISS")

        with YoutubeDL({
            "quiet": True,
            "skip_download": True,
            "extract_flat": True,   # 🔥 tylko SEARCH
            "noplaylist": True,
            "geo_bypass": True,
            "extractor_args": {
                "youtube": {
                    "player_client": ["android", "web"]
                }
            }
        }) as ydl:

            if mode == "search":
                data = ydl.extract_info(f"ytsearch10:{query}", download=False)

            elif mode == "video":
                info = ydl.extract_info(query, download=False)
                data = {"entries": [info]}

            elif mode == "playlist":
                data = ydl.extract_info(query, download=False)

        set_cache(cache_key, data)

    # ======================================================
    # 📋 LISTA
    # ======================================================
    for entry in data.get("entries", []):
        title = entry.get("title")
        video_id = entry.get("id")
        url = entry.get("webpage_url") or f"https://www.youtube.com/watch?v={video_id}"

        thumb = (
            entry.get("thumbnail")
            or (entry.get("thumbnails")[0]["url"] if entry.get("thumbnails") else None)
            or ""
        )

        desc = entry.get("description") or entry.get("title") or ""

        li = xbmcgui.ListItem(label=title)
        li.setArt({"thumb": thumb})
        li.setProperty("IsPlayable", "true")
        li.setInfo("video", {"plot": desc})

        play_url = (
            base_url
            + "?action=play"
            + "&url=" + urllib.parse.quote_plus(url)
            + "&q=" + urllib.parse.quote_plus(query)
        )

        xbmcplugin.addDirectoryItem(handle, play_url, li, False)

    xbmcplugin.endOfDirectory(handle, cacheToDisc=True)
    win.setProperty("yt_session", "1")

def get_best_youtube_stream(video_url):

    ydl_opts = {
        "quiet": True,
        "no_warnings": True,
        "skip_download": True,
        "noplaylist": True,
        "geo_bypass": True,
        "extract_flat": False,   # 🔥 KLUCZ
        "extractor_args": {
            "youtube": {
                "player_client": ["android", "web"]
            }
        },
    }

    try:
        with YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(video_url, download=False)

            if "entries" in info:
                info = info["entries"][0]

            # HLS first
            for f in reversed(info.get("formats", [])):
                if f.get("url") and "m3u8" in f.get("url"):
                    return f["url"]

            # best quality
            best = max(
                (f for f in info.get("formats", [])
                 if f.get("vcodec") != "none"
                 and f.get("acodec") != "none"),
                key=lambda x: x.get("height", 0),
                default=None
            )

            if best:
                return best["url"]

            return info.get("url")

    except Exception as e:
        xbmc.log(f"[YT Fake] STREAM ERROR: {e}", xbmc.LOGWARNING)

    return None


# ===========================


# ======================================================
# ▶ PLAY
# ======================================================
def play(url):
    log(f"PLAY URL: {url}")

    stream_url = get_best_youtube_stream(url)

    if not stream_url:
        xbmcgui.Dialog().ok("Błąd", "Brak streamu")
        return

    log(f"STREAM: {stream_url}")

    li = xbmcgui.ListItem(path=stream_url)
    li.setProperty("IsPlayable", "true")

    if ".m3u8" in stream_url:
        li.setMimeType("application/vnd.apple.mpegurl")
        li.setContentLookup(False)

        try:
            from inputstreamhelper import Helper
            hls = Helper("hls")

            if hls.check_inputstream():
                li.setProperty("inputstream", hls.inputstream_addon)
                li.setProperty("inputstream.adaptive.manifest_type", "hls")
        except:
            pass

    xbmcplugin.setResolvedUrl(handle, True, li)

def show_root():

    li = xbmcgui.ListItem(label="Szukaj")
    xbmcplugin.addDirectoryItem(
        handle,
        sys.argv[0] + "?url=search",
        li,
        True
    )
    xbmcplugin.endOfDirectory(handle)
    win.clearProperty("yt_fake_last_query")
# ========================================================
# 🚀 START

if action == "play" and url:
    play(urllib.parse.unquote_plus(url))
elif url == "search":
    search(query_param)
elif query_param:
    show_results(query_param)
else:
    show_root()